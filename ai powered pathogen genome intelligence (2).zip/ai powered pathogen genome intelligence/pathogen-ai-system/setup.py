"""Setup configuration for pathogen-ai-system."""

from setuptools import setup, find_packages
from pathlib import Path

# Read requirements
requirements = []
req_file = Path(__file__).parent / "requirements.txt"
if req_file.exists():
    requirements = [
        line.strip()
        for line in req_file.read_text().splitlines()
        if line.strip() and not line.startswith("#")
    ]

setup(
    name="pathogen-ai-system",
    version="0.1.0",
    description="AI-Powered Pathogen Genome Intelligence – classify and analyse pathogen genomes using machine learning",
    author="Srinu",
    python_requires=">=3.10",
    packages=find_packages(where="."),
    package_dir={"": "."},
    py_modules=[
        "src.genomic_ai_model",
        "src.bioinformatics_tools",
        "src.mcp_server",
        "src.train_model",
        "src.model_persistence",
    ],
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "pathogen-train=src.train_model:main",
            "pathogen-server=src.mcp_server:start_server",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)
