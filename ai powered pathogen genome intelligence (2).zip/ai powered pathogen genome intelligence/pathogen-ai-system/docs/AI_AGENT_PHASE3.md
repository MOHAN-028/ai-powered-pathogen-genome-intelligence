# Phase 3: Intelligent AI Agent & Solution Builder — Architecture & Documentation

## Overview

**Phase 3 — Intelligent AI Agent and Solution Builder** elevates the Pathogen Genome Intelligence Sandbox with multi-provider LLM reasoning, a specialized **Computational Solution Builder**, multi-hypothesis **Novel Sequence Differential Diagnostics**, and strict **Evidence Grounding & Anti-Hallucination Verification**.

The AI Agent can operate completely offline via the zero-hallucination **Deterministic Fallback Engine**, or interface seamlessly with external APIs (**OpenAI**, **Google Gemini**) and local models (**Ollama / LLaMA3 / Mistral**) without breaking grounded fidelity or defensive biosecurity constraints.

---

## 1. System Architecture & Request Lifecycle

```text
User Question (/agent or POST /agent/ask)
                    ↓
┌─────────────────────────────────────────────────────────┐
│ 1. Safety Router (SafetyRouter)                         │
│    ├─ Prompt Injection / Jailbreak Filter               │
│    └─ Dual-Use Biosecurity Hazard Evaluation            │
└───────────────────────────┬─────────────────────────────┘
                            │
               [If Unsafe / Injection] ──> Structured Policy Refusal + Safe Alternatives
                            │
               [If Allowed] │
                            ▼
┌─────────────────────────────────────────────────────────┐
│ 2. Context Retrieval & Authorization                    │
│    ├─ Multi-User Authorization Check                    │
│    ├─ Database Fetch (SQLite platform_db.sqlite)        │
│    └─ Structured Context Extraction (ContextBuilder)    │
└───────────────────────────┬─────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────┐
│ 3. Intent Classifier (IntentClassifier)                 │
│    ├─ SOLUTION_BUILDING                                 │
│    ├─ NOVELTY_ASSESSMENT                                │
│    ├─ ANALYSIS_INTERPRETATION                           │
│    ├─ BIOINFORMATICS_CONCEPT                            │
│    ├─ PIPELINE_CAPABILITIES                             │
│    └─ SAFETY_INQUIRY                                    │
└───────────────────────────┬─────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────┐
│ 4. LLM Provider Layer (LLMProvider Abstraction)         │
│    ├─ DeterministicFallbackProvider (Default / Offline) │
│    ├─ LocalOllamaLLMProvider (Ollama / Local LLaMA3)    │
│    ├─ OpenAILLMProvider (GPT-4o / Azure / OpenAI REST)  │
│    ├─ GeminiLLMProvider (Gemini 1.5 Flash / Pro)        │
│    └─ MockLLMProvider (Unit Testing)                    │
│    * Auto-fallback to Deterministic on API/network error│
└───────────────────────────┬─────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────┐
│ 5. Response Validator (ResponseValidator)               │
│    ├─ Post-Generation Biosecurity Scan                  │
│    ├─ Anti-Hallucination Metric Cross-Check             │
│    ├─ Accession ID Fabrication Detection                │
│    ├─ Novel Pathogen Safe-Claim Guard                   │
│    ├─ Non-Clinical Medical Disclaimer Attachment        │
│    └─ Section Extraction (Answer/Evidence/Uncertainty)  │
└───────────────────────────┬─────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────┐
│ 6. Immutable Audit Logger (AuditLogger)                 │
│    └─ Append-only logging with SHA-256 integrity hash   │
└───────────────────────────┬─────────────────────────────┘
                            │
                            ▼
     Structured AgentAskResponse (JSON + Verified Grounding)
```

---

## 2. Pluggable LLM Provider Abstraction Layer

The platform provides a modular `LLMProvider` interface (`app/agent/llm_provider.py`) configurable via the `LLM_PROVIDER` environment variable:

| Provider Key | Class | Backend / Protocol | Offline Capable? |
| :--- | :--- | :--- | :--- |
| `deterministic` | `DeterministicFallbackProvider` | Built-in rule & knowledge engine | **Yes (100% offline)** |
| `ollama` | `LocalOllamaLLMProvider` | Local Ollama REST (`http://localhost:11434`) | **Yes (local model)** |
| `openai` | `OpenAILLMProvider` | OpenAI / Azure OpenAI Chat Completions | No (cloud API) |
| `gemini` | `GeminiLLMProvider` | Google Gemini `generateContent` API | No (cloud API) |
| `mock` | `MockLLMProvider` | Synthetic canned test double | **Yes** |

### Resilience & Auto-Fallback Protocol
If an external cloud or local Ollama provider encounters a timeout, network failure, missing API key, or invalid JSON payload, it **automatically and silently cascades to `DeterministicFallbackProvider`**, guaranteeing zero downtime and uninterrupted user experience.

### Injected Grounding System Prompt
All external and local LLM providers receive a mandatory grounding system prompt:
```text
GROUNDING RULES (never violate):
1. Never invent, fabricate, or estimate numeric scores (similarity, confidence, novelty, 
   GC content, coverage, identity percentage, QC metrics) not in the supplied Analysis Context.
2. Never claim that a sequence IS definitively a new, novel, or engineered pathogen.
3. Never cite database accession IDs not present in the supplied context.
4. Never provide pathogen engineering, synthesis, virulence enhancement, or gain-of-function protocols.
5. Never make clinical medical diagnoses, treatment recommendations, or patient prognoses.
```

---

## 3. Computational Solution Builder

When users inquire about designing or engineering bioinformatics pipelines (e.g., *"How can I create a solution for this problem?"*), the `SolutionBuilder` (`app/agent/solution_builder.py`) produces end-to-end computational architectures across **10 sequential lifecycle stages**:

```text
┌─────────────────────────────────────────────────────────────────┐
│ 1. Problem Definition (Public-Health Surveillance & Biosafety)  │
└────────────────────────────────┬────────────────────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. Secure Data Ingestion (FASTA / FASTQ / PDF / API / Auth/TLS) │
└────────────────────────────────┬────────────────────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. Quality Control (Read Length, GC%, Ambiguity 'N' Filtering)  │
└────────────────────────────────┬────────────────────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. Feature Extraction (k-mer Tokenization, Embedding Vectors)   │
└────────────────────────────────┬────────────────────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ 5. Similarity Analysis (Global/Local Alignment & Ref Index)     │
└────────────────────────────────┬────────────────────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ 6. Novelty Detection (Divergence Scoring vs Reference Catalog)  │
└────────────────────────────────┬────────────────────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ 7. Classification (Taxonomic & Lineage Supervised ML Models)    │
└────────────────────────────────┬────────────────────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ 8. Uncertainty Assessment (Confidence Margins & Limitations)    │
└────────────────────────────────┬────────────────────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ 9. Expert Review (Human-in-the-Loop Sign-off & Governance)      │
└────────────────────────────────┬────────────────────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ 10. Research / Public-Health Surveillance Report Generation     │
└─────────────────────────────────────────────────────────────────┘
```

### Core Implementation Pillars Covered
1. **Software Architecture & APIs:** FastAPI REST & Model Context Protocol (MCP) endpoints.
2. **Storage & Retrieval:** Thread-safe SQLite relational database & indexed reference catalogs.
3. **Machine Learning & Uncertainty:** $k$-mer sliding window tokenization, multinomial Bayes, distance-to-reference novelty scoring, and Platt-scaled calibration.
4. **Defense-in-Depth Security:** RBAC (`researcher`, `expert_reviewer`, `admin`), biosecurity routing, and SHA-256 audit logging.
5. **Testing & Benchmark Evaluation:** Automated pytest suites, precision/recall metrics, and out-of-distribution (OOD) tests.
6. **Explainability & Transparency:** Grounded sections, verifiable evidence citations, and confidence scoring.
7. **Deployment & Monitoring:** Containerized sandboxes with compute constraints and Prometheus observability.

---

## 4. Novel Sequence Multi-Hypothesis Differential Diagnostics

A critical safety rule of the platform is: **Never automatically claim that an unmapped sequence is a newly discovered or engineered pathogen.**

When similarity is low or novelty status is `possibly_novel`, the agent executes a structured 4-hypothesis differential assessment:

```text
                [ No Strong Reference Match Detected ]
                                  │
       ┌──────────────────────────┼──────────────────────────┐
       ▼                          ▼                          ▼
 [ Hypothesis A ]           [ Hypothesis B ]           [ Hypothesis C ]
 Poor Quality / Read        Reference Database Gap     Natural Biological
 Truncation / High Ns       (Uncatalogued Strain)      Divergence / Drift
       │                          │                          │
       └──────────────────────────┼──────────────────────────┘
                                  ▼
                            [ Hypothesis D ]
                      Insufficient Sequencing Depth
                                  │
                                  ▼
                   [ Deep Computational Re-search ]
                                  │
                                  ▼
                   [ Human Expert Review Sign-off ]
```

### Distinction Safeguard Notice
Every novelty response includes an explicit biosecurity disclaimer:
> *"A lack of a database match indicates unmapped sequence data, NOT confirmed creation or discovery of an engineered or harmful pathogen. All divergent findings must be routed through expert bioinformatician review."*

---

## 5. Structured Response Format & Verification

Every agent response is parsed and structured into 5 standard markdown sections:

```markdown
### Answer
[Direct, grounded answer to the user's question]

### Evidence
- [Exact metric citations from the analysis context or bioinformatics standard]

### Interpretation
[Scientific explanation of the findings without speculative claims]

### Uncertainty
[Epistemic bounds, database limitations, and read-length constraints]

### Recommended Safe Next Steps
1. [Safe computational or diagnostic next steps]
```

### Response Validation & Grounding Checks (`app/agent/validator.py`)
- **Metric Cross-Check:** Verifies all numeric figures match the actual analysis report context.
- **Accession ID Check:** Blocks fabricated accession IDs not present in the reference context.
- **Hazard Interception:** Post-generation regex scanning blocks any hazardous lab protocol leaks.
- **Clinical Disclaimer:** Automatically attaches non-clinical disclaimers to medical inquiries.
- **Grounding Confidence Score:** Computes a factual fidelity score ($0.0 - 1.0$).

---

## 6. Test Suite & Verification Matrix

The platform includes **142 automated tests** across 7 test suites, achieving **100% pass rate**:

| Test Suite | File | Tests | Status |
| :--- | :--- | :---: | :---: |
| **Phase 1: Agent Foundation** | [`tests/test_agent_foundation.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_agent_foundation.py) | 17 | ✅ PASS |
| **Phase 2: Analysis Integration** | [`tests/test_agent_phase2.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_agent_phase2.py) | 10 | ✅ PASS |
| **Phase 3: Intelligent Agent & Solution Builder** | [`tests/test_agent_phase3.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_agent_phase3.py) | 61 | ✅ PASS |
| **Bioinformatics Core Algorithms** | [`tests/test_bioinformatics.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_bioinformatics.py) | 14 | ✅ PASS |
| **Machine Learning & Embeddings** | [`tests/test_genomic_model.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_genomic_model.py) | 16 | ✅ PASS |
| **FastAPI / MCP Server Endpoints** | [`tests/test_mcp_server.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_mcp_server.py) | 10 | ✅ PASS |
| **Pipeline & Sandbox Workflow** | [`tests/test_phase2_pipeline.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_phase2_pipeline.py) | 7 | ✅ PASS |
| **Platform Services & Security** | [`tests/test_phase3_platform.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_phase3_platform.py) | 7 | ✅ PASS |
| **Total Test Suite** | **All Modules** | **142** | **✅ 100% PASS** |

---

## 7. Interactive Agent Interface & API Reference

### Live Endpoints
- **Agent Chat Web Interface:** `GET /agent` (`http://127.0.0.1:8000/agent`)
- **Main Analysis Dashboard:** `GET /` (`http://127.0.0.1:8000`)
- **Agent Ask API:** `POST /agent/ask`
- **Interactive OpenAPI Documentation:** `GET /docs` (`http://127.0.0.1:8000/docs`)

### Example Solution Builder Request
```bash
curl -X POST "http://127.0.0.1:8000/agent/ask" \
     -H "Content-Type: application/json" \
     -d '{"question": "How can I create a computational solution for novel sequence analysis?"}'
```

### Example Grounded Analysis Explanation Request
```bash
curl -X POST "http://127.0.0.1:8000/agent/ask" \
     -H "Content-Type: application/json" \
     -d '{
       "question": "What does the novelty score mean and why is confidence low?",
       "analysis_id": "analysis_123"
     }'
```
