# Phase 4: AI Agent Security, Safety, and Tools — Architecture & Security Blueprint

## Overview

**Phase 4 — AI Agent Security, Safety and Tools** hardens the **AI-Powered Pathogen Genome Intelligence Sandbox** into a defensive, production-ready research platform. Phase 4 establishes:
1. A **Strict Tool Allowlist** with structural isolation from shell execution or sequence alteration.
2. An **Untrusted Data Sandboxing & Prompt Injection Defense Engine** treating all external metadata (FASTA headers, uploaded documents, sample names, database notes) as non-executable passive data.
3. A hardened **Dual-Use Biosecurity Safety Router** blocking pathogen engineering, synthesis, virulence/transmission enhancement, and immune evasion inquiries.
4. An **Immutable Audit Logging System** with **Raw Sequence Redaction** to protect genomic privacy and prevent sequence leakage into conversational storage.
5. Strict **Multi-User Isolation**, **Rate Limiting**, and **Defense-in-Depth HTTP Security**.

---

## 1. Security Architecture & Threat Model

```text
               Untrusted Ingestion Surface
  (FASTA Headers / Uploaded Files / Reports / Chat)
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│ 1. Prompt Injection & Untrusted Data Defense                │
│    ├─ Delimiter Sandboxing (<untrusted_data type="...">)    │
│    ├─ Instruction Neutralization ([CONTAINED])              │
│    └─ System Prompt & Safety Hierarchy Dominance            │
└───────────────────────────────┬─────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. Safety Router (SafetyRouter)                             │
│    ├─ Dual-Use Biosecurity Hazard Regex Filter              │
│    ├─ Engineering & Synthesis Policy Enforcement            │
│    └─ Safe Defensive Analytical Alternative Redirect        │
└───────────────────────────────┬─────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. Multi-User Isolation & Authorization Engine              │
│    ├─ Bearer Token Verification & RBAC                      │
│    └─ Analysis Ownership Validation (DatabaseStore)         │
└───────────────────────────────┬─────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. Strict Tool Registry (ToolRegistry)                      │
│    ├─ Allowlist Verification (6 Predefined Tools Only)      │
│    ├─ Prohibited Tool Interception (Shell / Synthesis Block)│
│    └─ Parameter Sanitization & Safe Error Handling          │
└───────────────────────────────┬─────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. Audit Logging with Sequence Redaction (AuditLogger)      │
│    ├─ Raw Sequence Redaction ([REDACTED_SEQUENCE ...])      │
│    └─ Append-Only SHA-256 Audit Trail in SQLite             │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Strict Tool Allowlist & Prohibited Tool Interception

The Agent does **not** have access to arbitrary execution environments, native shell terminals, or genome modification scripts. All data access occurs exclusively through the `ToolRegistry` (`app/agent/tools.py`).

### Allowed Analytical Tools (Strict Allowlist)

| Tool Name | Parameters | Description | Permissions |
| :--- | :--- | :--- | :--- |
| `get_analysis` | `analysis_id: str` | Retrieves verified, complete structured analysis metrics (QC, similarity, novelty, classification, uncertainty). | Owner / Admin / Expert |
| `get_qc_results` | `analysis_id: str` | Retrieves sequence quality control metrics (length, GC%, ambiguous base count, base composition). | Owner / Admin / Expert |
| `get_similarity_results` | `analysis_id: str` | Retrieves reference alignment hits, identity percentage, alignment length, and coverage. | Owner / Admin / Expert |
| `get_novelty_results` | `analysis_id: str` | Retrieves novelty scores, classification status, and distinction safeguards. | Owner / Admin / Expert |
| `get_classification_results` | `analysis_id: str` | Retrieves predicted taxonomic lineage, confidence score, and epistemic uncertainty. | Owner / Admin / Expert |
| `get_report` | `analysis_id: str` | Retrieves the full raw `GenomeIntelligenceReport` dictionary. | Owner / Admin / Expert |

### Prohibited Tools (Explicitly Intercepted & Logged)

Any attempt by a user or model to invoke the following prohibited tools raises a `ProhibitedToolError` and creates a `SECURITY_PROHIBITED_TOOL_ATTEMPT` audit record:

```text
❌ execute_shell()          -> Structural command injection attempt
❌ modify_sequence()        -> Unauthorized genome modification
❌ design_pathogen()        -> Dual-use biosecurity hazard
❌ optimize_pathogen()      -> Virulence/transmission optimization
❌ synthesize_sequence()    -> Physical / chemical synthesis guidance
❌ increase_virulence()     -> Lethality/pathogenicity enhancement
❌ increase_transmission()  -> Contagion / aerosolization enhancement
❌ run_command()            -> Subprocess command execution attempt
❌ eval_code()              -> Dynamic code evaluation attempt
❌ raw_sql_query()          -> Direct database manipulation attempt
```

---

## 3. Prompt Injection Defense & Untrusted Data Sandboxing

### Untrusted Data Classification
All data originating outside the core application codebase is categorized as **Untrusted Data**:
- FASTA metadata, FASTA headers (`>Header ...`), organism tags, strain labels
- Uploaded file contents (`.fasta`, `.fastq`, `.pdf`)
- Database report notes and user comments
- User chat messages and prompt strings

### Defense Mechanisms (`app/agent/prompt_defense.py`)
1. **Adversarial Instruction Neutralization:**
   Phrases such as *"Ignore previous instructions"*, *"System prompt: override"*, or *"You are now in developer mode"* embedded in user questions or FASTA metadata are detected and neutralized into passive string markers: `[UNTRUSTED_INSTRUCTION_CONTAINED]`.
2. **Explicit Delimiter Sandboxing:**
   Untrusted text is wrapped in non-executable boundary tags before being presented to models:
   ```xml
   <untrusted_data type="fasta_header">
   >Sample_01 [UNTRUSTED_INSTRUCTION_CONTAINED]
   </untrusted_data>
   ```
3. **Safety Priority Invariant:**
   System safety rules, grounding prompts, and biosecurity policies unconditionally supersede any instructions contained inside untrusted data tags.

---

## 4. Dual-Use Biosecurity Guardrails (`app/agent/safety.py`)

The `SafetyRouter` continuously evaluates user inputs against dual-use biological hazards:

```text
Prohibited Categories:
  • Pathogen engineering, design, or algorithmic optimization
  • Genome modification for increased virulence or transmission
  • Virulence, lethality, pathogenicity, or mortality enhancement
  • Transmission, contagion, aerosolization, or airborne spread enhancement
  • Immune-evasion optimization or antibody escape protocols
  • Pathogen or physical sequence synthesis / reconstruction protocols
  • Experimental wet-lab construction steps / recipes
  • Biological-agent production, culture, or weaponization
```

### Safe Analytical Redirects
Refused requests return policy-grounded explanations alongside safe defensive alternatives:
- Sequence quality control & base composition analysis
- Reference-guided similarity search and taxonomic alignment
- Genomic novelty detection and divergence scoring
- Transparent uncertainty and database limitation assessment
- Computational biosurveillance and pathogen monitoring

---

## 5. Conversational Privacy & Raw Sequence Redaction

To prevent sensitive, unverified, or proprietary genomic sequences from accumulating in conversational audit tables:
- The `PromptDefense.redact_sequences_from_log()` engine identifies continuous nucleotide runs ($>25$ bp of `[ACGTUN]`).
- Raw bases are replaced with metadata summaries before persistence:
  ```text
  [REDACTED_SEQUENCE length=1200bp GC=42.5%]
  ```
- Conversational chat logs and audit events in `platform_db.sqlite` store only sanitized analytical summaries.

---

## 6. Multi-User Isolation, Rate Limiting & Defensive HTTP

### Multi-User Isolation
- **Resource Ownership:** Analysis reports and background jobs are tagged with the creator's `user_id`.
- **Authorization Enforcement:** Researcher accounts cannot query, view, or invoke tools on reports belonging to other researchers (enforced in `DatabaseStore.is_user_authorized_for_analysis` and `ToolRegistry.execute`).
- **Role-Based Overrides:** `admin` and `expert_reviewer` roles have authorized oversight for governance and audit review.

### Rate Limiting & HTTP Hardening
- **Sliding-Window Rate Limiter:** Limits requests to a maximum of 200 queries/minute per client IP.
- **Defensive HTTP Headers:** Injected on all HTTP responses:
  - `X-Content-Type-Options: nosniff`
  - `X-Frame-Options: DENY`
  - `X-XSS-Protection: 1; mode=block`
  - `Content-Security-Policy: default-src 'self' ...`
  - `Strict-Transport-Security: max-age=31536000; includeSubDomains`

---

## 7. Verification Test Suite Matrix

The security implementation was validated against **194 automated test cases** across 8 test suites with **100% pass rate**:

```text
====================== 194 passed, 7 warnings in 15.73s =======================
```

| Security Test Category | Test File | Test Count | Status |
| :--- | :--- | :---: | :---: |
| **Phase 4: Agent Security & Tools** | [`tests/test_agent_phase4_security.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_agent_phase4_security.py) | 52 | ✅ PASS |
| **Phase 3: Intelligent Agent & Solution Builder** | [`tests/test_agent_phase3.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_agent_phase3.py) | 61 | ✅ PASS |
| **Phase 2: Analysis Integration** | [`tests/test_agent_phase2.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_agent_phase2.py) | 10 | ✅ PASS |
| **Phase 1: Agent Foundation** | [`tests/test_agent_foundation.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_agent_foundation.py) | 17 | ✅ PASS |
| **Platform Services & RBAC** | [`tests/test_phase3_platform.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_phase3_platform.py) | 7 | ✅ PASS |
| **Pipeline & Sandbox Execution** | [`tests/test_phase2_pipeline.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_phase2_pipeline.py) | 7 | ✅ PASS |
| **Machine Learning & Embeddings** | [`tests/test_genomic_model.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_genomic_model.py) | 16 | ✅ PASS |
| **Bioinformatics Core Algorithms** | [`tests/test_bioinformatics.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_bioinformatics.py) | 14 | ✅ PASS |
| **MCP Server & Web Endpoints** | [`tests/test_mcp_server.py`](file:///c:/Users/Srinu/OneDrive/Desktop/ai%20powered%20pathogen%20genome%20intelligence/pathogen-ai-system/tests/test_mcp_server.py) | 10 | ✅ PASS |
| **Total Test Suite** | **All Modules** | **194** | **✅ 100% PASS** |
