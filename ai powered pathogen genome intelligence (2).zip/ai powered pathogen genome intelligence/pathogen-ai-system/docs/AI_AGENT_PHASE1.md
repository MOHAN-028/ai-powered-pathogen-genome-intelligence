# Phase 1: AI Agent Foundation — Architecture & Documentation

## Overview

The **AI Agent Foundation** establishes the secure, defensive AI infrastructure for the **AI-Powered Pathogen Genome Intelligence Sandbox**. It serves domain-specific genomic intelligence, explains quality control and novelty concepts, and answers pipeline and bioinformatics inquiries while strictly enforcing defensive biosecurity guardrails.

---

## 1. System Architecture & Request Lifecycle

```text
User / Web Browser (/agent)
            ↓
    Agent API (POST /agent/ask)
            ↓
    Safety Router (SafetyRouter)  ──[If Hazard / Injection Detected]──> Safety Refusal + Safe Alternatives
            ↓ (If Allowed)
    Intent Classifier (IntentClassifier)
            ↓
    Agent Service (AgentService)
            ↓
    LLM Provider (DeterministicFallbackProvider / OpenAILLMProvider)
            ↓
    Response Validator (ResponseValidator)
            ↓
    Audit Logger (AuditLogger → SQLite platform_db.sqlite)
            ↓
    Structured JSON Response (AgentAskResponse)
```

---

## 2. Reusable Services

### `SafetyRouter` (`app/agent/safety.py`)
- **Dual-Use Hazard Detection:** Inspects incoming questions against forbidden categories including:
  - Pathogen engineering & design
  - Genome modification & manipulation
  - Virulence / lethality enhancement
  - Transmission / airborne spread enhancement
  - Immune-evasion & antibody escape optimization
  - Pathogen synthesis & chemical assembly protocols
  - Bioweapons and gain-of-function experiments
- **Prompt Injection Defense:** Neutralizes system prompt override patterns (`"ignore all previous instructions"`, `"jailbreak"`, `"developer mode"`).
- **Safe Analytical Alternatives:** When a request is refused, provides constructive defensive bioinformatics research directions.

### `IntentClassifier` (`app/agent/intent.py`)
Categorizes user queries into discrete intent domains:
- `GENERAL_INFORMATION`: Overview of novelty scoring, quality control, divergence vs. discovery.
- `PIPELINE_CAPABILITIES`: FASTA, FASTQ, PDF upload processing, async job workers, REST endpoints.
- `BIOINFORMATICS_CONCEPT`: Open Reading Frames (ORFs), GC content, sliding-window profiles, k-mers.
- `SAFETY_INQUIRY`: Biosecurity controls, guardrails, non-clinical medical disclaimers.
- `SYSTEM_GUIDANCE`: Platform navigation, expert review workflow, audit log tracking.
- `UNSAFE_REQUEST`: Prohibited dual-use or gain-of-function biological requests.
- `OUT_OF_SCOPE`: Non-genomic queries.

### `LLMProvider` (`app/agent/llm_provider.py`)
- **`DeterministicFallbackProvider`:** Comprehensive, deterministic offline knowledge engine providing authoritative, scientifically grounded answers to genomic questions without requiring third-party API keys.
- **`OpenAILLMProvider`:** Optional cloud provider connecting to OpenAI or compatible endpoints.
- **`get_llm_provider()`:** Factory reading environment variables with graceful fallback to deterministic mode upon network or credential failure.

### `ResponseValidator` (`app/agent/validator.py`)
- **Post-Generation Safety Scan:** Verifies generated text to prevent model hallucinations from leaking actionable synthesis or engineering steps.
- **Disclaimer Enforcement:** Appends non-clinical research disclaimers to diagnostic or therapeutic inquiries.

### `AgentService` (`app/agent/service.py`)
- Main orchestrator coordinating input validation, safety filtering, intent routing, response generation, validation, and audit recording.

### `AuditLogger` (`app/security/audit.py`)
- Records every query, classified intent, safety status, IP address, and timestamp into the SQLite database (`data/platform_db.sqlite`).

---

## 3. Environment-Based Configuration

Configure external LLM providers via environment variables:

```env
# LLM Configuration (Optional - Defaults to deterministic offline engine)
LLM_PROVIDER=deterministic   # Options: 'deterministic', 'openai', 'gemini', 'mock'
LLM_API_KEY=                 # API Key for cloud provider (Never hard-coded)
LLM_MODEL=gpt-4o-mini        # Model identifier
```

*Note: If no API key is provided, the platform operates in 100% offline deterministic mode.*

---

## 4. API Reference

### 1. Ask Agent Endpoint

```http
POST /agent/ask
Content-Type: application/json
Authorization: Bearer <optional_token>
```

#### Request Payload:
```json
{
  "question": "What is novelty detection?"
}
```

#### Allowed Response:
```json
{
  "answer": "🔬 **Novelty Detection in Genome Intelligence**\n\nNovelty detection evaluates how divergent a query sequence is relative to all known reference genomes in the curated database...",
  "intent": "GENERAL_INFORMATION",
  "safety_status": "allowed",
  "safe_alternatives": null,
  "confidence": 0.85,
  "timestamp": "2026-08-20T17:40:00.000000Z"
}
```

#### Refused Response (Unsafe Biological Request):
```json
{
  "answer": "🛡️ **Defensive Biosecurity Safety Refusal**\n\nI cannot fulfill this request. The Pathogen Genome Intelligence Sandbox operates strictly as a defensive, analytical platform.\n**Reason:** Request violates biosecurity policy regarding virulence enhancement...",
  "intent": "UNSAFE_REQUEST",
  "safety_status": "refused",
  "safe_alternatives": [
    "Sequence quality control & composition analysis (GC content, ambiguity checks)",
    "Reference-guided similarity search and taxonomic alignment",
    "Novelty detection and genomic divergence scoring",
    "Taxonomic and functional classification",
    "Transparent uncertainty and limitation assessment",
    "Computational biosurveillance and pathogen monitoring"
  ],
  "confidence": 1.0,
  "timestamp": "2026-08-20T17:40:00.000000Z"
}
```

### 2. Agent UI Route

```http
GET /agent
```
Renders the standalone interactive Glassmorphic chat interface with real-time intent chips, safety status indicators, and suggested prompts.

---

## 5. Security & Biosecurity Guardrails

| Risk Vector | Mitigation Strategy | Policy Response |
| :--- | :--- | :--- |
| **Pathogen Engineering** | SafetyRouter Regex + Keyword matching | Immediate refusal + safe defensive alternatives |
| **Synthesis Protocols** | Dual-use protocol blocking | Immediate refusal |
| **Virulence/Transmission Enhancement** | Gain-of-function keyword blocking | Immediate refusal |
| **Prompt Injection / Jailbreaks** | Adversarial pattern matching | Immediate refusal (`UNSAFE_REQUEST`) |
| **Excessive Request Flooding** | `SimpleRateLimiter` (200 req/min per IP) | HTTP 429 Too Many Requests |
| **Audit Traceability** | `AuditLogger` records all events in SQLite | Immutable audit trail with IP & user metadata |

---

## 6. Verification and Testing

Execute the test suite:

```powershell
# Run Agent Foundation specific test suite
python -m pytest tests/test_agent_foundation.py -v

# Run the complete test suite (71 tests passing)
python -m pytest tests/ -v
```
