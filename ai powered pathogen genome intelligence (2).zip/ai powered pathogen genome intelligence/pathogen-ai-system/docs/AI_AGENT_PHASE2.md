# Phase 2: Genome Analysis Integration — Architecture & Documentation

## Overview

**Phase 2 — Genome Analysis Integration** establishes direct, grounded connectivity between the **AI Agent** and the **Genome Intelligence Pipeline**. The AI Agent can retrieve authorized sequence analysis reports from the persistent SQLite database, extract verified metrics using a zero-hallucination **Structured Context Builder**, enforce strict **multi-user isolation**, and provide scientifically precise explanations of quality control, confidence levels, similarity hits, genomic novelty, and analysis limitations.

---

## 1. System Architecture & Request Lifecycle

```text
User / Web Browser (/agent)
            ↓
    Agent API (POST /agent/ask)
            ↓
    Safety Router (SafetyRouter)  ──[If Hazard / Injection]──> Safety Refusal + Safe Alternatives
            ↓ (If Safe)
    Analysis ID Resolution
            ↓
    Authorization Verification (DatabaseStore.is_user_authorized_for_analysis)
            ↓ ──[If Unauthorized]──> 403 Forbidden
            ↓ ──[If Not Found]───> 404 Not Found
    Fetch Report JSON (SQLite platform_db.sqlite)
            ↓
┌───────────────────────────────────────────────┐
│ Analysis Context Builder                      │
│ ├─ Quality Control (GC%, length, ambiguity)   │
│ ├─ Similarity (Top hit, identity, coverage)   │
│ ├─ Novelty (Divergence score, status, notice) │
│ ├─ Classification (Taxon, ML confidence)      │
│ ├─ Confidence & Uncertainty (Limitations)     │
│ └─ Warnings & Non-Clinical Disclaimer         │
└───────────────────────────────────────────────┘
            ↓
    Grounded Response Generator (DeterministicFallbackProvider / External LLM)
            ↓
    Response Validator (ResponseValidator)
            ↓
    Audit Logger (AuditLogger → SQLite platform_db.sqlite)
            ↓
    Structured JSON Response (AgentAskResponse)
```

---

## 2. Structured Context Builder

The `AnalysisContextBuilder` (`app/agent/context_builder.py`) maps a validated `GenomeIntelligenceReport` into a standardized diagnostic context dictionary without inventing or assuming missing values:

```json
{
  "analysis_id": "test_phase2_01",
  "sample_id": "sample_p2",
  "quality_control": {
    "quality_passed": true,
    "num_records": 1,
    "total_length": 1200,
    "gc_content": 0.425,
    "ambiguous_bases": 0,
    "ambiguous_percentage": 0.0,
    "duplicate_records_count": 0,
    "base_composition": {
      "A": 350,
      "T": 340,
      "G": 260,
      "C": 250,
      "N": 0,
      "other": 0
    },
    "warnings": []
  },
  "similarity": {
    "database_version": "demo-ref-v1.0",
    "database_status": "active",
    "max_similarity": 0.985,
    "top_hit": {
      "reference_id": "NC_045512.2",
      "taxon_name": "Severe acute respiratory syndrome coronavirus 2",
      "similarity_score": 0.985,
      "alignment_length": 1200,
      "identity_percentage": 98.5,
      "coverage_percentage": 100.0,
      "confidence": 0.98,
      "notes": "High identity match to SARS-CoV-2 reference"
    },
    "num_hits": 1
  },
  "novelty": {
    "status": "known_or_closely_related",
    "novelty_score": 0.015,
    "rationale": "Query aligns with 98.5% identity to reference NC_045512.2.",
    "distinction_notice": "A lack of a database match indicates unmapped sequence data, NOT confirmed creation or discovery of a new pathogen."
  },
  "classification": {
    "classification": "Severe acute respiratory syndrome coronavirus 2",
    "confidence": 0.98,
    "evidence": ["Reference NC_045512.2 match (98.5% identity)", "k-mer distribution match"],
    "database_version": "demo-ref-v1.0"
  },
  "confidence": {
    "score": 0.98,
    "summary": "High confidence due to 98.5% identity across 100% query length."
  },
  "uncertainty": {
    "score": 0.02,
    "limitations": [
      "Analysis based on short fragment (~1200 bp)",
      "Database limited to reference collection"
    ],
    "evidence_sources": [
      "Reference database demo-ref-v1.0",
      "Global pairwise alignment"
    ],
    "reason_for_alert": null,
    "medical_disclaimer": "This platform provides research sequence analysis only. It does NOT diagnose clinical infection or determine medical treatment."
  },
  "ai_explanation": {
    "finding": "Sequence exhibits strong homology with SARS-CoV-2.",
    "interpretation": "Consistent with known Coronaviridae lineage.",
    "recommended_next_step": "Perform phylogenetic tree placement."
  },
  "warnings": []
}
```

---

## 3. Multi-User Isolation & Authorization

The system strictly enforces ownership and role-based access control (RBAC):

1. **Owner Access:** The user who generated an analysis can query and discuss it (`200 OK`).
2. **Unauthorized Cross-User Access:** A regular researcher (`researcher2`) attempting to query another user's analysis (`researcher1`) is blocked with `403 Forbidden` (`"Access denied: You are not authorized to view analysis report '...'"`).
3. **Role-Based Global Access:** Users with `admin` or `expert_reviewer` roles (`admin1`, `expert1`) have authorized global read access for auditing and peer review.
4. **Missing Reports:** Querying a non-existent `analysis_id` returns `404 Not Found`.
5. **Security Logging:** Every unauthorized access attempt triggers an `UNAUTHORIZED_ANALYSIS_ACCESS_ATTEMPT` audit event logged in SQLite.

---

## 4. Grounded Explanation Capabilities

When an `analysis_id` is attached, the Agent answers core analytical questions with strict fidelity:

| User Question | Grounded Agent Response Behavior |
| :--- | :--- |
| **"What does the QC result mean?"** | Details overall pass/warning status, total length, GC percentage, ambiguous base counts/percentage, base composition (A, T, G, C, N), and duplicate warnings. |
| **"Why is the confidence score low/high?"** | Explains confidence % vs. uncertainty %, reference alignment coverage, sequence divergence factors, and documented limitations. |
| **"What does the similarity result mean?"** | Analyzes top reference accession, taxon name, normalized similarity score, identity %, query coverage %, and database status. |
| **"Why is classification uncertain?"** | Breaks down taxonomic evidence, distance to reference genomes, k-mer frequency support, and model confidence margins. |
| **"What does the novelty result indicate?"** | Explains novelty status (`known_or_closely_related` vs. `possibly_novel`), novelty score, divergence rationale, and enforces the distinction safeguard (unmapped ≠ engineered). |
| **"What limitations exist?"** | Enumerates specific limitations in the report, non-clinical medical disclaimers, and recommended follow-up steps. |
| **Unavailable / Missing Evidence** | Explicitly states: *"The available analysis does not contain enough evidence to determine this."* |

---

## 5. API Reference

### `POST /agent/ask`

#### Request Payload (Grounded Mode):
```json
{
  "question": "Why is the confidence score high for this sample?",
  "analysis_id": "test_phase2_01"
}
```

#### Response:
```json
{
  "answer": "⚖️ **Confidence & Uncertainty Assessment for Sample 'sample_p2'**\n\n- **Confidence Score:** 98.0%\n- **Uncertainty Score:** 2.0%\n- **Confidence Summary:** High confidence due to 98.5% identity across 100% query length.\n- **Evidence Sources:** Reference database demo-ref-v1.0; Global pairwise alignment\n- **Identified Limitations:** Analysis based on short fragment (~1200 bp); Database limited to reference collection\n\n**Explanation:** The confidence score is determined by sequence alignment depth and reference homology. High alignment identity against the reference database supports high confidence.",
  "intent": "ANALYSIS_INTERPRETATION",
  "safety_status": "allowed",
  "analysis_id": "test_phase2_01",
  "analysis_context": {
    "quality_control": { ... },
    "similarity": { ... },
    "novelty": { ... },
    "classification": { ... },
    "confidence": { ... },
    "uncertainty": { ... },
    "warnings": []
  },
  "safe_alternatives": null,
  "confidence": 0.95,
  "timestamp": "2026-08-20T17:50:00.000000Z"
}
```

---

## 6. Frontend Chat UI Enhancements (`/agent`)

- **Analysis Attachment Bar:** Allows users to paste an Analysis ID and attach it directly to the chat session.
- **Live Active Analysis Card:** Displays Sample ID, Analysis ID badge, Classification pill, Novelty status pill, and QC status badge.
- **Dynamic Contextual Buttons:** Instant one-click questions for QC interpretation, confidence breakdown, similarity explanation, novelty meaning, and analysis limitations.
- **URL Parameter Support:** Direct deep linking via `http://localhost:8000/agent?analysis_id=<ID>`.

---

## 7. Verification & Test Suite

Run the Phase 2 test suite:
```powershell
python -m pytest tests/test_agent_phase2.py -v
```

Run the complete project test suite:
```powershell
python -m pytest tests/ -v
```
**Results: 81 tests passing (0 failures).**
