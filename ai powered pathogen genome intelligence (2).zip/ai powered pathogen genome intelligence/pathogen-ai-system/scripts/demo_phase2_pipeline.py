"""
scripts/demo_phase2_pipeline.py
================================
Demonstration script for the complete Phase 2 AI-Assisted Genome Intelligence Pipeline:
  Upload -> QC -> Similarity -> Novelty -> Classification -> Uncertainty -> Report
"""

import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.bioinformatics_tools import SequenceRecord
from app.services.pipeline import GenomeIntelligencePipeline
from app.analysis.report import render_html_report


def main():
    print("=" * 75)
    print("  AI-POWERED PATHOGEN GENOME INTELLIGENCE — PHASE 2 PIPELINE DEMO")
    print("=" * 75)
    print()

    # 1. Prepare non-operational, safe demonstration sequences
    demo_records = [
        SequenceRecord(
            id="DEMO-SEQ-001",
            description="[label=Escherichia_coli] Safe K-12 non-pathogenic laboratory strain",
            sequence="ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAGGTAACGGTGCGGGCTGA" * 5,
        ),
        SequenceRecord(
            id="DEMO-SEQ-002",
            description="Divergent synthetic research sequence",
            sequence="CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC" * 5,
        ),
    ]

    # 2. Instantiate pipeline
    pipeline = GenomeIntelligencePipeline()

    for idx, rec in enumerate(demo_records, 1):
        print(f"--- [RUN #{idx}] Analyzing Sequence: '{rec.id}' ---")
        report = pipeline.run([rec], sample_id=rec.id)

        print(f"Analysis ID:               {report.analysis_id}")
        print(f"Timestamp:                 {report.timestamp}")
        print(f"Records / Total Length:    {report.sequence_statistics.num_records} / {report.sequence_statistics.total_length} bp")
        print(f"GC Content / Ambiguous:    {report.sequence_statistics.gc_content * 100:.1f}% GC | {report.sequence_statistics.ambiguous_percentage:.1f}% Ns")
        print(f"Max Reference Similarity:  {report.similarity.max_similarity * 100:.1f}%")
        print(f"Novelty Assessment:        {report.novelty.status.upper()} (score: {report.novelty.novelty_score})")
        print(f"Classification / Conf:     {report.classification.classification} ({report.classification.confidence * 100:.1f}%)")
        print(f"Analytical Uncertainty:    {report.risk_and_uncertainty.uncertainty * 100:.1f}%")
        print(f"Expert Review Status:      {report.expert_review_status}")
        print()
        print("AI Explanation:")
        print(f"  Finding:    {report.ai_explanation.finding}")
        print(f"  Interpret:  {report.ai_explanation.interpretation}")
        print(f"  Next Step:  {report.ai_explanation.recommended_next_step}")
        print()
        print("Safety & Disclaimer Notice:")
        print(f"  {report.novelty.distinction_notice}")
        print(f"  {report.risk_and_uncertainty.medical_disclaimer}")
        print("-" * 75)
        print()

    # Render sample HTML report to results/sample_report.html
    sample_rpt = pipeline.get_report(report.analysis_id)
    if sample_rpt:
        html_content = render_html_report(sample_rpt)
        out_path = Path("results/sample_report.html")
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(html_content, encoding="utf-8")
        print(f"[SUCCESS] Rendered HTML Research Intelligence Report saved to: {out_path.resolve()}")

    print()
    print("[SUCCESS] PHASE 2 DEMONSTRATION COMPLETE.")



if __name__ == "__main__":
    main()
