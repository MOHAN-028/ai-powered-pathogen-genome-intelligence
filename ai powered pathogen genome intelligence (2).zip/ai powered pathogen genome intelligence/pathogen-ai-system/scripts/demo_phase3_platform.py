"""
scripts/demo_phase3_platform.py
================================
Demonstration script for Phase 3 Research Platform:
  Demo 1: Known-like sequence -> Similarity -> Classification -> Report
  Demo 2: Unusual sequence -> Low similarity -> Novelty alert -> Uncertainty warning -> Expert review
"""

import sys
import time
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.bioinformatics_tools import SequenceRecord
from app.db.database import DatabaseStore
from app.queue.job_queue import JobQueueWorker
from app.services.pipeline import GenomeIntelligencePipeline
from app.assistant.ai_assistant import ReportExplanationAssistant
from app.review.expert_review import ExpertReviewManager


def main():
    print("=" * 80)
    print("  AI-POWERED PATHOGEN GENOME INTELLIGENCE — PHASE 3 RESEARCH PLATFORM DEMO")
    print("=" * 80)
    print()

    db = DatabaseStore("data/platform_db.sqlite")
    pipeline = GenomeIntelligencePipeline()
    worker = JobQueueWorker(db_store=db, pipeline=pipeline, num_workers=2)
    worker.start()
    review_mgr = ExpertReviewManager(db)
    assistant = ReportExplanationAssistant()

    # -----------------------------------------------------------------------
    # DEMO 1: Known-like Sequence Workflow
    # -----------------------------------------------------------------------
    print(">>> DEMO 1: KNOWN-LIKE SEQUENCE WORKFLOW <<<")
    seq_known = "ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAGGTAACGGTGCGGGCTGA" * 5
    rec_known = SequenceRecord(id="DEMO-KNOWN-01", description="Safe E. coli K-12 reference match", sequence=seq_known)

    print("[1/4] Submitting job to asynchronous sandbox worker...")
    job_known = worker.submit_job([rec_known], sample_id="DEMO-KNOWN-01")
    print(f"      Job ID: {job_known.job_id} | Status: {job_known.status}")

    print("[2/4] Waiting for job completion...")
    for _ in range(10):
        time.sleep(0.3)
        updated_job = db.get_job(job_known.job_id)
        if updated_job and updated_job.status == "completed":
            print(f"      Job Completed! Analysis ID: {updated_job.analysis_id}")
            break

    db_res1 = db.get_analysis_result(updated_job.analysis_id)
    if db_res1:
        from app.models.schemas import GenomeIntelligenceReport
        import json
        report1 = GenomeIntelligenceReport(**json.loads(db_res1.report_json))
        print(f"[3/4] Similarity Detected: {report1.similarity.max_similarity * 100:.1f}% max similarity")
        print(f"      Classification:    {report1.classification.classification} ({report1.classification.confidence * 100:.1f}% conf)")
        print(f"[4/4] Report Generated:   Analysis ID {report1.analysis_id}")
        print(f"      Finding: {report1.ai_explanation.finding}")

    print("-" * 80)
    print()

    # -----------------------------------------------------------------------
    # DEMO 2: Unusual Demonstration Sequence & Expert Review Workflow
    # -----------------------------------------------------------------------
    print(">>> DEMO 2: UNUSUAL DEMONSTRATION SEQUENCE & EXPERT REVIEW WORKFLOW <<<")
    seq_unusual = "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC" * 5
    rec_unusual = SequenceRecord(id="DEMO-UNUSUAL-02", description="Unusual divergent research sequence", sequence=seq_unusual)

    print("[1/5] Running defensive analysis pipeline...")
    report2 = pipeline.run([rec_unusual], sample_id="DEMO-UNUSUAL-02")
    db_res2 = db.get_analysis_result(report2.analysis_id)

    print(f"[2/5] Low Similarity Detected: {report2.similarity.max_similarity * 100:.1f}% max match")
    print(f"[3/5] Novelty Alert Triggered:  {report2.novelty.status.upper()} (score: {report2.novelty.novelty_score})")
    print(f"[4/5] Uncertainty Warning:     {report2.risk_and_uncertainty.uncertainty * 100:.1f}% analytical uncertainty")

    # Q&A Assistant query
    qa = assistant.answer_question(report2, "Why is this sequence considered unusual?")
    print(f"      AI Assistant Q&A: {qa['answer']}")

    # Expert Review Submission
    print("[5/5] Human Expert Review Workflow:")
    rev_report = review_mgr.submit_review(
        analysis_id=report2.analysis_id,
        reviewer_id="dr_pathology_expert",
        decision="approved",
        notes="Reviewed divergent sequence. Unmapped coverage verified. Approved for reference expansion.",
    )
    print(f"      Expert Decision: APPROVED | Updated Review Status: {rev_report.expert_review_status}")

    print("-" * 80)
    print()
    print("[SUCCESS] PHASE 3 DEMONSTRATION COMPLETE.")
    worker.stop()


if __name__ == "__main__":
    main()
