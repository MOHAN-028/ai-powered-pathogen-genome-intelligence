"""
test_phase2_pipeline.py
========================
Unit and integration tests for Phase 2 Defensive Genome Intelligence Pipeline.
"""

import pytest
from src.bioinformatics_tools import SequenceRecord
from app.models.schemas import GenomeIntelligenceReport
from app.analysis.qc import run_qc
from app.analysis.similarity import LocalReferenceDatabase, UnavailableReferenceDatabase, analyze_similarity
from app.analysis.novelty import detect_novelty
from app.analysis.classification import classify_sequence
from app.analysis.uncertainty import evaluate_uncertainty
from app.analysis.report import render_html_report
from app.services.pipeline import GenomeIntelligencePipeline


@pytest.fixture
def sample_reference_db():
    refs = [
        SequenceRecord(id="REF-EC-01", description="[label=Escherichia_coli] K-12", sequence="ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAGGTAACGGTGCGGGCTGA" * 5),
        SequenceRecord(id="REF-SE-02", description="[label=Salmonella_enterica] LT2", sequence="ATGTTTCAACCTCCTGCCGATATCACCACCATTACCACCACCATCACCATTACCACAGGTAACGGT" * 5),
    ]
    return LocalReferenceDatabase(refs)


def test_1_known_reference_like_input(sample_reference_db):
    """Test pipeline response to sequence closely matching a reference strain."""
    pipeline = GenomeIntelligencePipeline(reference_db=sample_reference_db)
    seq_match = "ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAGGTAACGGTGCGGGCTGA" * 5
    rec = SequenceRecord(id="query_ecoli", description="query", sequence=seq_match)

    report = pipeline.run([rec], sample_id="test_ecoli_sample")
    assert isinstance(report, GenomeIntelligenceReport)
    assert report.novelty.status == "known_or_closely_related"
    assert report.similarity.max_similarity > 0.90
    assert report.classification.classification == "Escherichia_coli"
    assert report.risk_and_uncertainty.confidence > 0.80


def test_2_low_similarity_input(sample_reference_db):
    """Test sequence with low similarity to reference database."""
    pipeline = GenomeIntelligencePipeline(reference_db=sample_reference_db)
    seq_divergent = "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC" * 5
    rec = SequenceRecord(id="query_div", description="query", sequence=seq_divergent)

    report = pipeline.run([rec], sample_id="test_divergent")
    assert report.novelty.status in ("insufficient_evidence", "possibly_novel")
    assert report.similarity.max_similarity < 0.50
    assert "No database match" in report.novelty.distinction_notice or "Safety Protocol" in report.novelty.distinction_notice



def test_3_malformed_sequence():
    """Test handling of sequences containing high ambiguous/malformed characters."""
    records = [SequenceRecord(id="malformed", description="desc", sequence="NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN")]
    qc_res = run_qc(records)
    assert qc_res.ambiguous_percentage == 100.0
    assert len(qc_res.warnings) > 0


def test_4_empty_database():
    """Test behavior when reference database is empty."""
    empty_db = LocalReferenceDatabase([])
    pipeline = GenomeIntelligencePipeline(reference_db=empty_db)
    rec = SequenceRecord(id="q1", description="desc", sequence="ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAG")

    report = pipeline.run([rec], sample_id="test_empty_db")
    assert report.similarity.database_status == "empty"
    assert report.novelty.status == "insufficient_evidence"
    assert "No reference database matches" in report.novelty.rationale


def test_5_unavailable_database():
    """Test behavior when reference database is offline/unavailable."""
    unavail_db = UnavailableReferenceDatabase()
    pipeline = GenomeIntelligencePipeline(reference_db=unavail_db)
    rec = SequenceRecord(id="q1", description="desc", sequence="ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAG")

    report = pipeline.run([rec], sample_id="test_unavail_db")
    assert report.similarity.database_status == "unavailable"
    assert report.novelty.status == "insufficient_evidence"


def test_6_uncertain_classification():
    """Test transparent uncertainty scoring when classification confidence is low."""
    qc_res = run_qc([SequenceRecord(id="q", description="", sequence="ATCGNNNNNNNNNNNNNNNN")])
    unavail_db = UnavailableReferenceDatabase()
    sim_res = analyze_similarity("q", "ATCGNNNNNNNNNNNNNNNN", unavail_db)
    nov_res = detect_novelty(sim_res)

    class_res = classify_sequence("ATCGNNNNNNNNNNNNNNNN", sim_res)
    unc_res = evaluate_uncertainty(qc_res, sim_res, nov_res, class_res)

    assert unc_res.uncertainty > 0.50
    assert "Non-clinical" in unc_res.medical_disclaimer or "clinical" in unc_res.medical_disclaimer


def test_7_report_generation(sample_reference_db):
    """Test generation of JSON schema report and HTML report rendering."""
    pipeline = GenomeIntelligencePipeline(reference_db=sample_reference_db)
    rec = SequenceRecord(id="query_rpt", description="", sequence="ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAGGTAACGGTGCGGGCTGA" * 2)

    report = pipeline.run([rec], sample_id="rpt_sample_01")
    assert report.analysis_id is not None
    assert report.ai_explanation.finding is not None

    html = render_html_report(report)
    assert "<!DOCTYPE html>" in html
    assert report.sample_id in html
    assert "GENOME INTELLIGENCE REPORT" in html
