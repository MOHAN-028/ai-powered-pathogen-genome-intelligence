"""
test_bioinformatics.py
======================
Unit tests for src.bioinformatics_tools.
"""

import io
import pytest

from src.bioinformatics_tools import (
    parse_fasta,
    compute_gc_content,
    base_composition,
    sequence_statistics,
    find_orfs,
    align_sequences,
    SequenceRecord,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SAMPLE_FASTA = """\
>seq1 Test sequence 1
ATCGATCGATCGATCG
>seq2 Test sequence 2
GCGCGCGCGCGCGCGC
>seq3 Low GC sequence
AAAAAAATTTTTTTT
"""

SAMPLE_FASTA_WITH_ORF = """\
>orf_test ORF detection test
ATGAAAGCGATTATTGGTCTGGGTGCTTATGATTATGACTCCTCGATTGATGATGATCGCGATCAATCACGATCAATCAGGATCAGCAATCGATCAGCAAGCGATCAGCAATCGTAA
"""


# ---------------------------------------------------------------------------
# Tests: Parsing
# ---------------------------------------------------------------------------

class TestParseFasta:
    def test_parse_from_string(self):
        records = parse_fasta(io.StringIO(SAMPLE_FASTA))
        assert len(records) == 3
        assert records[0].id == "seq1"
        assert records[0].sequence == "ATCGATCGATCGATCG"

    def test_record_length(self):
        records = parse_fasta(io.StringIO(SAMPLE_FASTA))
        assert records[0].length == 16
        assert records[2].length == 15

    def test_empty_input(self):
        records = parse_fasta(io.StringIO(""))
        assert records == []


# ---------------------------------------------------------------------------
# Tests: GC content
# ---------------------------------------------------------------------------

class TestGCContent:
    def test_pure_gc(self):
        gc = compute_gc_content("GCGCGCGC")
        assert abs(gc - 1.0) < 0.01

    def test_pure_at(self):
        gc = compute_gc_content("ATATATATAT")
        assert abs(gc - 0.0) < 0.01

    def test_mixed(self):
        gc = compute_gc_content("ATCG")
        assert abs(gc - 0.5) < 0.01

    def test_case_insensitive(self):
        gc = compute_gc_content("atcg")
        assert abs(gc - 0.5) < 0.01


# ---------------------------------------------------------------------------
# Tests: Base composition
# ---------------------------------------------------------------------------

class TestBaseComposition:
    def test_counts(self):
        comp = base_composition("AATTTGGGCCCC")
        assert comp["A"] == 2
        assert comp["T"] == 3
        assert comp["G"] == 3
        assert comp["C"] == 4
        assert comp["N"] == 0

    def test_with_n(self):
        comp = base_composition("ATCGN")
        assert comp["N"] == 1


# ---------------------------------------------------------------------------
# Tests: Sequence statistics
# ---------------------------------------------------------------------------

class TestSequenceStatistics:
    def test_basic_stats(self):
        rec = SequenceRecord(id="test", description="test seq", sequence="ATCGATCG")
        stats = sequence_statistics(rec)
        assert stats.id == "test"
        assert stats.length == 8
        assert abs(stats.gc_content - 0.5) < 0.01
        assert stats.avg_quality is None


# ---------------------------------------------------------------------------
# Tests: ORF finding
# ---------------------------------------------------------------------------

class TestFindORFs:
    def test_finds_orf(self):
        records = parse_fasta(io.StringIO(SAMPLE_FASTA_WITH_ORF))
        orfs = find_orfs(records[0].sequence, min_length=30)
        assert len(orfs) >= 1
        assert orfs[0].strand == "+"
        assert orfs[0].nucleotide_seq.startswith("ATG")

    def test_no_orf_in_short_seq(self):
        orfs = find_orfs("ATCGATCG", min_length=100)
        assert len(orfs) == 0


# ---------------------------------------------------------------------------
# Tests: Alignment
# ---------------------------------------------------------------------------

class TestAlignment:
    def test_identical_sequences(self):
        a = SequenceRecord(id="a", description="", sequence="ATCGATCG")
        b = SequenceRecord(id="b", description="", sequence="ATCGATCG")
        result = align_sequences(a, b)
        assert result.identity == 1.0

    def test_different_sequences(self):
        a = SequenceRecord(id="a", description="", sequence="AAAA")
        b = SequenceRecord(id="b", description="", sequence="TTTT")
        result = align_sequences(a, b)
        assert result.identity < 0.5
