"""
test_genomic_model.py
=====================
Unit tests for src.genomic_ai_model.
"""

import pytest
import numpy as np

from src.genomic_ai_model import (
    kmer_tokenize,
    sequences_to_kmer_corpus,
    PathogenClassifier,
    GenomeEmbedder,
)


# ---------------------------------------------------------------------------
# Synthetic data helpers
# ---------------------------------------------------------------------------

def _make_synthetic_data(n_per_class: int = 20):
    """Generate synthetic labelled sequences for two classes.

    Class A: AT-rich sequences.
    Class B: GC-rich sequences.
    """
    import random
    random.seed(42)

    sequences = []
    labels = []

    for _ in range(n_per_class):
        # AT-rich
        seq_a = "".join(random.choices("AATT", k=300))
        sequences.append(seq_a)
        labels.append("AT_rich")

        # GC-rich
        seq_b = "".join(random.choices("GGCC", k=300))
        sequences.append(seq_b)
        labels.append("GC_rich")

    return sequences, labels


# ---------------------------------------------------------------------------
# Tests: K-mer tokeniser
# ---------------------------------------------------------------------------

class TestKmerTokenize:
    def test_basic(self):
        result = kmer_tokenize("ATCGATCG", k=4)
        assert result == ["ATCG", "TCGA", "CGAT", "GATC", "ATCG"]

    def test_k_equals_length(self):
        result = kmer_tokenize("ATCG", k=4)
        assert result == ["ATCG"]

    def test_k_greater_than_length(self):
        result = kmer_tokenize("AT", k=4)
        assert result == []

    def test_strips_n(self):
        result = kmer_tokenize("ANTCG", k=4)
        # N is removed, so "ATCG" → ["ATCG"]
        assert result == ["ATCG"]

    def test_case_insensitive(self):
        result = kmer_tokenize("atcgatcg", k=4)
        assert result[0] == "ATCG"


class TestSequencesToKmerCorpus:
    def test_returns_strings(self):
        corpus = sequences_to_kmer_corpus(["ATCGATCG", "GCGCGCGC"], k=4)
        assert len(corpus) == 2
        assert isinstance(corpus[0], str)
        assert "ATCG" in corpus[0]


# ---------------------------------------------------------------------------
# Tests: PathogenClassifier
# ---------------------------------------------------------------------------

class TestPathogenClassifier:
    @pytest.fixture
    def trained_classifier(self):
        seqs, labels = _make_synthetic_data(20)
        clf = PathogenClassifier(k=4, model_type="logistic", max_features=1000)
        clf.fit(seqs, labels)
        return clf, seqs, labels

    def test_fit_returns_metrics(self):
        seqs, labels = _make_synthetic_data(20)
        clf = PathogenClassifier(k=4)
        result = clf.fit(seqs, labels)
        assert "accuracy" in result
        assert result["accuracy"] > 0.5

    def test_predict_returns_correct_type(self, trained_classifier):
        clf, seqs, _ = trained_classifier
        result = clf.predict(seqs[0])
        assert result.label in ["AT_rich", "GC_rich"]
        assert 0.0 <= result.confidence <= 1.0

    def test_predict_at_rich(self, trained_classifier):
        clf, _, _ = trained_classifier
        at_seq = "A" * 100 + "T" * 100 + "A" * 100
        result = clf.predict(at_seq)
        assert result.label == "AT_rich"

    def test_predict_gc_rich(self, trained_classifier):
        clf, _, _ = trained_classifier
        gc_seq = "G" * 100 + "C" * 100 + "G" * 100
        result = clf.predict(gc_seq)
        assert result.label == "GC_rich"

    def test_predict_unfitted_raises(self):
        clf = PathogenClassifier()
        with pytest.raises(RuntimeError, match="not been trained"):
            clf.predict("ATCGATCG")

    def test_classes_property(self, trained_classifier):
        clf, _, _ = trained_classifier
        assert set(clf.classes) == {"AT_rich", "GC_rich"}

    def test_train_eval(self):
        seqs, labels = _make_synthetic_data(30)
        clf = PathogenClassifier(k=4)
        metrics = clf.train_eval(seqs, labels, test_size=0.3)
        assert "accuracy" in metrics
        assert "train_size" in metrics
        assert "test_size" in metrics


# ---------------------------------------------------------------------------
# Tests: GenomeEmbedder
# ---------------------------------------------------------------------------

class TestGenomeEmbedder:
    def test_fit_transform_shape(self):
        seqs, _ = _make_synthetic_data(10)
        embedder = GenomeEmbedder(k=4, n_components=8, max_features=500)
        embeddings = embedder.fit_transform(seqs)
        assert isinstance(embeddings, np.ndarray)
        assert embeddings.shape == (len(seqs), 8)

    def test_transform_unfitted_raises(self):
        embedder = GenomeEmbedder()
        with pytest.raises(RuntimeError, match="not fitted"):
            embedder.transform(["ATCG" * 50])

    def test_similar_sequences_cluster(self):
        """AT-rich embeddings should be closer to each other than to GC-rich."""
        import random
        random.seed(42)
        at_seqs = ["".join(random.choices("AATT", k=200)) for _ in range(10)]
        gc_seqs = ["".join(random.choices("GGCC", k=200)) for _ in range(10)]

        embedder = GenomeEmbedder(k=4, n_components=8, max_features=500)
        all_embeddings = embedder.fit_transform(at_seqs + gc_seqs)

        at_emb = all_embeddings[:10]
        gc_emb = all_embeddings[10:]

        at_centroid = at_emb.mean(axis=0)
        gc_centroid = gc_emb.mean(axis=0)

        # Centroids should be different
        dist = np.linalg.norm(at_centroid - gc_centroid)
        assert dist > 0.1
