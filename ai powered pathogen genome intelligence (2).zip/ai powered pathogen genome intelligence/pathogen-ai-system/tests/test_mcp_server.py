"""
test_mcp_server.py
==================
Unit tests for the FastAPI MCP server endpoints using FastAPI TestClient.
"""

import pytest
from fastapi.testclient import TestClient
from src.mcp_server import app

client = TestClient(app)


def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"


def test_list_models():
    response = client.get("/models")
    assert response.status_code == 200
    data = response.json()
    assert "models" in data
    assert "count" in data


def test_predict_endpoint():
    # Sequence must be at least 10 nucleotides
    payload = {
        "sequence": "ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAG",
        "top_features": 5,
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "label" in data
    assert "confidence" in data
    assert "top_features" in data
    assert len(data["top_features"]) <= 5


def test_predict_invalid_nucleotide():
    payload = {
        "sequence": "ATGAAACGCATTAGCACCACCATTACCACCAXZQATCACCATTACCACAG",
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 422


def test_analyze_fasta_upload():
    fasta_content = (
        ">seq1 [label=Escherichia_coli]\n"
        "ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAGGTAACGGTGCGG\n"
    )
    files = {"file": ("test.fasta", fasta_content, "text/plain")}
    response = client.post("/analyze", files=files)
    assert response.status_code == 200
    data = response.json()
    assert "analysis_id" in data
    assert data["sample_id"] == "test.fasta"
    assert "sequence_statistics" in data
    assert "similarity" in data
    assert "novelty" in data
    assert "classification" in data
    assert "ai_explanation" in data

    # Test GET /analysis/{id}
    analysis_id = data["analysis_id"]
    get_res = client.get(f"/analysis/{analysis_id}")
    assert get_res.status_code == 200
    assert get_res.json()["analysis_id"] == analysis_id

    # Test GET /analysis/{id}/report HTML
    html_res = client.get(f"/analysis/{analysis_id}/report")
    assert html_res.status_code == 200
    assert "GENOME INTELLIGENCE REPORT" in html_res.text


def test_dashboard_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    assert "PATHOGEN GENOME INTELLIGENCE" in response.text


def test_orfs_endpoint():
    payload = {
        "sequence": "ATGAAAGCGATTATTGGTCTGGGTGCTTATGATTATGACTCCTCGATTGATGATGATCGCGATCAATCACGATCAATCAGGATCAGCAATCGATCAGCAAGCGATCAGCAATCGTAA",
        "min_length": 30
    }
    response = client.post("/orfs", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "orfs" in data
    assert len(data["orfs"]) >= 1


def test_align_endpoint():
    payload = {
        "sequence_a": "ATCGATCGATCGATCG",
        "sequence_b": "ATCGATCGAGCGATCG"
    }
    response = client.post("/align", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "score" in data
    assert "identity" in data
    assert data["identity"] > 0.8


def test_gc_profile_endpoint():
    payload = {
        "sequence": "ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAGGTAACGGTGCGGGCTGA",
        "window_size": 10
    }
    response = client.post("/gc-profile", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["window_size"] == 10
    assert len(data["profile"]) > 0


def test_embeddings_endpoint():
    response = client.get("/embeddings")
    assert response.status_code in (200, 404)


