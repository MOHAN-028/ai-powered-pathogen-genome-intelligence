"""
mcp_server.py
=============
FastAPI server that exposes the Pathogen Genome Intelligence system over
HTTP. Designed to run inside the Docker sandbox or locally via uvicorn.

Endpoints
---------
- ``GET  /``         – Interactive Glassmorphic Web Dashboard UI.
- ``POST /analyze``  – upload a FASTA/FASTQ/PDF file → classification + stats.
- ``POST /predict``  – submit a raw sequence string → classification.
- ``POST /orfs``     – locate Open Reading Frames across 6 reading frames.
- ``POST /align``    – perform global pairwise sequence alignment.
- ``POST /gc-profile``– calculate sliding-window GC content profile curve.
- ``GET  /embeddings``– retrieve genome embedding coordinates for visualization.
- ``GET  /health``   – health-check.
- ``GET  /models``   – list available saved models.
"""

from __future__ import annotations

import io
import re
import json
import logging
from pathlib import Path
from typing import Literal, Optional

import numpy as np
from PyPDF2 import PdfReader
from fastapi import FastAPI, File, Header, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, Field

from src.bioinformatics_tools import (
    SequenceRecord,
    align_sequences,
    compute_gc_content,
    find_orfs,
    parse_fasta,
    parse_fastq,
    sequence_statistics,
)
from src.genomic_ai_model import PathogenClassifier
from src.model_persistence import list_models, load_model

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="[MCP-SERVER] %(message)s")

# ---------------------------------------------------------------------------
# App & config
# ---------------------------------------------------------------------------

app = FastAPI(
    title="Pathogen Genome Intelligence API",
    description="Classify and analyse pathogen genomes with AI",
    version="0.2.0",
)

# Paths
_DEFAULT_MODEL_DIR = Path("models/saved_models")
_STATIC_DIR = Path(__file__).parent / "static"
_classifier: Optional[PathogenClassifier] = None


def _get_classifier() -> PathogenClassifier:
    """Lazy-load the default classifier on first request."""
    global _classifier
    if _classifier is not None:
        return _classifier

    model_path = _DEFAULT_MODEL_DIR / "pathogen_classifier.joblib"
    if model_path.exists():
        model, _meta = load_model(model_path)
        _classifier = model
        logger.info("Default classifier loaded from %s", model_path)
        return _classifier

    raise HTTPException(
        status_code=503,
        detail=(
            "No trained model found. Train one first with: "
            "python -m src.train_model"
        ),
    )


# ---------------------------------------------------------------------------
# Request / response schemas
# ---------------------------------------------------------------------------

class PredictRequest(BaseModel):
    """Raw sequence submission for classification."""
    sequence: str = Field(..., min_length=10, description="Nucleotide sequence (ATCG)")
    top_features: int = Field(10, ge=0, le=50, description="Number of top k-mer features to return")


class PredictResponse(BaseModel):
    label: str
    confidence: float
    top_features: list[dict]


class AnalyzeResponse(BaseModel):
    filename: str
    num_sequences: int
    predictions: list[dict]
    statistics: list[dict]


class ORFRequest(BaseModel):
    sequence: str = Field(..., min_length=10, description="Nucleotide sequence")
    min_length: int = Field(30, ge=10, description="Minimum ORF nucleotide length")


class ORFResponse(BaseModel):
    orfs: list[dict]


class AlignRequest(BaseModel):
    sequence_a: str = Field(..., min_length=3, description="First sequence")
    sequence_b: str = Field(..., min_length=3, description="Second sequence")


class AlignResponse(BaseModel):
    score: float
    identity: float
    aligned_a: str
    aligned_b: str


class GCProfileRequest(BaseModel):
    sequence: str = Field(..., min_length=5, description="Nucleotide sequence")
    window_size: int = Field(10, ge=3, le=500, description="Sliding window size in bp")


class GCProfileResponse(BaseModel):
    window_size: int
    profile: list[float]


class PDFUploadResponse(BaseModel):
    """Response from the PDF extraction preview endpoint."""
    filename: str
    page_count: int
    extraction_status: str  # 'sequences_found' | 'text_only' | 'encrypted' | 'empty'
    sequences_found: int
    sequence_ids: list[str]
    text_preview: str
    message: str


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def get_dashboard():
    """Serve the interactive Glassmorphic Web Dashboard UI."""
    html_file = _STATIC_DIR / "dashboard.html"
    if html_file.exists():
        return HTMLResponse(content=html_file.read_text(encoding="utf-8"))
    return HTMLResponse(
        content="<h1>Pathogen Genome Intelligence Dashboard</h1><p>Dashboard file not found.</p>"
    )


@app.get("/health")
async def health_check():
    """Return service health status."""
    return {"status": "ok", "service": "pathogen-genome-intelligence"}


@app.get("/models")
async def get_models():
    """List all saved models."""
    models = list_models(_DEFAULT_MODEL_DIR)
    return {"models": models, "count": len(models)}


@app.post("/predict", response_model=PredictResponse)
async def predict_sequence(req: PredictRequest):
    """Classify a single raw nucleotide sequence."""
    classifier = _get_classifier()

    # Basic validation: check for non-nucleotide characters
    clean = req.sequence.upper().replace("N", "")
    invalid = set(clean) - {"A", "T", "G", "C"}
    if invalid:
        raise HTTPException(
            status_code=422,
            detail=f"Invalid nucleotide characters: {invalid}",
        )

    result = classifier.predict(req.sequence, top_n_features=req.top_features)
    return PredictResponse(
        label=result.label,
        confidence=result.confidence,
        top_features=[
            {"kmer": k, "weight": round(w, 6)} for k, w in result.top_features
        ],
    )


from app.db.database import DatabaseStore
from app.db.models import DBAnalysisResult, DBJob
from app.queue.job_queue import JobQueueWorker
from app.security.auth import create_demo_users
from app.security.audit import AuditLogger, SimpleRateLimiter, get_security_headers
from app.assistant.ai_assistant import ReportExplanationAssistant
from app.review.expert_review import ExpertReviewManager
from app.services.pipeline import GenomeIntelligencePipeline
from app.models.schemas import GenomeIntelligenceReport
from app.agent import AgentAskRequest, AgentAskResponse, AgentService

# Global Phase 3 & Agent singletons
_db_store = DatabaseStore("data/platform_db.sqlite")
create_demo_users(_db_store)
_audit_logger = AuditLogger(_db_store)
_rate_limiter = SimpleRateLimiter(max_requests=200, window_seconds=60)
_review_manager = ExpertReviewManager(_db_store)
_assistant = ReportExplanationAssistant()
_agent_service = AgentService(audit_logger=_audit_logger, db_store=_db_store)

_pipeline: Optional[GenomeIntelligencePipeline] = None

def _get_pipeline() -> GenomeIntelligencePipeline:
    global _pipeline
    if _pipeline is not None:
        return _pipeline
    
    clf = None
    try:
        clf = _get_classifier()
    except Exception:
        pass

    _pipeline = GenomeIntelligencePipeline(ml_classifier=clf)
    return _pipeline

_worker: Optional[JobQueueWorker] = None

def _get_worker() -> JobQueueWorker:
    global _worker
    if _worker is not None:
        return _worker
    pipeline = _get_pipeline()
    _worker = JobQueueWorker(db_store=_db_store, pipeline=pipeline, num_workers=2)
    _worker.start()
    return _worker


class AnalysisRequest(BaseModel):
    sequence: Optional[str] = Field(None, description="Nucleotide sequence")
    sample_id: Optional[str] = Field(None, description="Sample identifier")
    async_mode: bool = Field(False, description="If True, submit as asynchronous background job")


class ReviewSubmission(BaseModel):
    reviewer_id: str = Field("expert_01", description="Reviewer user ID")
    decision: Literal["approved", "rejected", "reanalysis_requested"] = Field(..., description="Review decision")
    notes: str = Field(..., min_length=3, description="Review notes")


class AssistantQuestionRequest(BaseModel):
    question: str = Field(..., min_length=3, description="Question about the analysis report")


# ---------------------------------------------------------------------------
# Phase 3 Probes & Platform Endpoints
# ---------------------------------------------------------------------------

@app.get("/ready")
async def readiness_check():
    """Return readiness status for load balancers."""
    worker = _get_worker()
    return {
        "status": "ready",
        "database": "connected",
        "worker_pool": "active",
        "timestamp": json.dumps(list_models(_DEFAULT_MODEL_DIR)),
    }


@app.get("/platform/stats")
async def get_platform_stats():
    """Return aggregated platform metrics for the web dashboard."""
    stats = _db_store.get_platform_stats()
    return stats


# ---------------------------------------------------------------------------
# AI Agent Endpoints (Phase 1 Foundation)
# ---------------------------------------------------------------------------

@app.get("/agent", response_class=HTMLResponse)
async def get_agent_page():
    """Serve the dedicated AI Agent Chat UI."""
    html_file = _STATIC_DIR / "agent.html"
    if not html_file.exists():
        return HTMLResponse("<h3>Agent UI not found</h3>", status_code=404)
    return HTMLResponse(html_file.read_text(encoding="utf-8"))


@app.post("/agent/ask", response_model=AgentAskResponse)
async def ask_agent(
    req: AgentAskRequest,
    request: Request,
    authorization: Optional[str] = Header(None),
):
    """Ask the AI Agent genomic intelligence, pipeline capability, or biosafety questions."""
    client_ip = request.client.host if request.client else "127.0.0.1"

    # Rate limiting check
    if not _rate_limiter.is_allowed(client_ip):
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded (maximum 200 requests per minute). Please slow down.",
        )

    # User identification / auth extraction
    user_id = "anonymous"
    if authorization and authorization.startswith("Bearer "):
        token = authorization[7:].strip()
        db_user = _db_store.get_user_by_username(token)
        if db_user:
            user_id = db_user.user_id
        else:
            user_id = token

    response = _agent_service.ask(request=req, user_id=user_id, client_ip=client_ip)
    return response


# ---------------------------------------------------------------------------
# Analysis & Asynchronous Jobs Endpoints
# ---------------------------------------------------------------------------

@app.post("/analyze", response_model=None)
async def analyze_input(
    request: Request,
    authorization: Optional[str] = Header(None),
):
    """Run full Phase 2/3 Genome Intelligence pipeline synchronously or asynchronously.
    
    Accepts direct JSON payloads (e.g. `{"sequence": "...", "async_mode": false}`)
    or multipart file uploads (.fasta, .fastq, .pdf).
    """
    records: list[SequenceRecord] = []
    sample_id = None
    async_mode = False

    user_id = "anonymous"
    if authorization and authorization.startswith("Bearer "):
        token = authorization[7:].strip()
        db_user = _db_store.get_user_by_username(token)
        if db_user:
            user_id = db_user.user_id
        else:
            user_id = token

    content_type = request.headers.get("content-type", "")

    if "application/json" in content_type:
        try:
            body = await request.json()
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid JSON body.")
        seq_text = body.get("sequence")
        sample_id = body.get("sample_id") or "query_seq_01"
        async_mode = bool(body.get("async_mode", False))
        if seq_text:
            records.append(SequenceRecord(id=sample_id, description=sample_id, sequence=seq_text))
    else:
        # Form or multipart/form-data
        try:
            form = await request.form()
        except Exception:
            form = {}

        file = form.get("file") if hasattr(form, "get") else None
        seq_field = form.get("sequence") if hasattr(form, "get") else None
        sample_id_field = form.get("sample_id") if hasattr(form, "get") else None
        async_field = form.get("async_mode") if hasattr(form, "get") else False
        async_mode = str(async_field).lower() in ("true", "1", "yes")

        if file and hasattr(file, "filename") and file.filename:
            sample_id = file.filename
            lower_name = file.filename.lower()
            contents = await file.read()

            if lower_name.endswith(".pdf"):
                # ── PDF document path ──
                try:
                    reader = PdfReader(io.BytesIO(contents))
                    if reader.is_encrypted:
                        raise HTTPException(
                            status_code=422,
                            detail="The uploaded PDF is encrypted/password-protected. Please provide an unencrypted PDF.",
                        )
                    full_text = "\n".join(page.extract_text() or "" for page in reader.pages)
                except HTTPException:
                    raise
                except Exception as exc:
                    raise HTTPException(status_code=422, detail=f"Could not parse PDF: {exc}")

                fasta_blocks = re.findall(r"(>[^\n]+\n[A-Za-z\n]+)", full_text)
                if fasta_blocks:
                    fasta_str = "\n".join(fasta_blocks)
                    records = parse_fasta(io.StringIO(fasta_str))
                else:
                    raw_seqs = re.findall(r"[ACGTUacgtu]{20,}", full_text)
                    if raw_seqs:
                        for idx, seq in enumerate(raw_seqs):
                            records.append(
                                SequenceRecord(
                                    id=f"{sample_id}_seq{idx+1}",
                                    description=f"Extracted from PDF (nucleotide string {idx+1})",
                                    sequence=seq,
                                )
                            )
                    else:
                        records.append(
                            SequenceRecord(
                                id=sample_id,
                                description="PDF text content (no nucleotide sequences found)",
                                sequence=(full_text[:500].strip() or "N" * 30),
                            )
                        )
            elif lower_name.endswith((".fastq", ".fq")):
                text = contents.decode("utf-8", errors="replace")
                records = parse_fastq(io.StringIO(text))
            else:
                text = contents.decode("utf-8", errors="replace")
                records = parse_fasta(io.StringIO(text))
        elif seq_field:
            sample_id = str(sample_id_field) if sample_id_field else "query_seq_01"
            records.append(SequenceRecord(id=sample_id, description=sample_id, sequence=str(seq_field)))

    if not records:
        raise HTTPException(
            status_code=400,
            detail="Must provide sequence in JSON payload or upload a FASTA/FASTQ/PDF file.",
        )

    # Log audit event
    _audit_logger.log(user_id=user_id, action="ANALYZE_SEQUENCE", resource=sample_id or "query_seq")

    if async_mode:
        worker = _get_worker()
        job = worker.submit_job(records=records, sample_id=sample_id or "async_query", user_id=user_id)
        return {
            "mode": "async",
            "job_id": job.job_id,
            "status": job.status,
            "message": "Analysis job submitted to background sandbox worker queue.",
        }

    # Synchronous processing
    pipeline = _get_pipeline()
    report = pipeline.run(records, sample_id=sample_id or "query_seq")
    # Save in DB as well
    _db_store.save_analysis_result(
        DBAnalysisResult(
            analysis_id=report.analysis_id,
            job_id="sync",
            sample_id=sample_id or "query_seq",
            report_json=report.model_dump_json(indent=2),
            user_id=user_id,
        )
    )
    return report


@app.post("/jobs")
async def create_job(req: AnalysisRequest):
    """Submit an asynchronous sequence analysis job."""
    if not req.sequence:
        raise HTTPException(status_code=400, detail="Sequence is required.")
    
    rec = SequenceRecord(id=req.sample_id or "job_seq", description="", sequence=req.sequence)
    worker = _get_worker()
    job = worker.submit_job(records=[rec], sample_id=req.sample_id or "job_seq")
    _audit_logger.log(user_id="anonymous", action="CREATE_JOB", resource=job.job_id)
    return job


@app.get("/jobs")
async def list_jobs():
    """List recent background analysis jobs."""
    return _db_store.list_jobs(limit=50)


@app.get("/jobs/{job_id}")
async def get_job_status(job_id: str):
    """Get status and progress of a specific job."""
    job = _db_store.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job ID '{job_id}' not found.")
    return job


@app.post("/jobs/{job_id}/cancel")
async def cancel_job(job_id: str):
    """Cancel a running or queued background job."""
    worker = _get_worker()
    success = worker.cancel_job(job_id)
    if not success:
        raise HTTPException(status_code=400, detail=f"Cannot cancel job '{job_id}' (already finished or invalid).")
    _audit_logger.log(user_id="anonymous", action="CANCEL_JOB", resource=job_id)
    return {"message": f"Job '{job_id}' cancelled successfully."}


@app.get("/analysis/{analysis_id}")
async def get_analysis_by_id(analysis_id: str):
    """Retrieve machine-readable JSON analysis report by ID."""
    # Check DB store first
    db_res = _db_store.get_analysis_result(analysis_id)
    if db_res:
        return JSONResponse(content=json.loads(db_res.report_json))

    # Check pipeline in-memory store
    pipeline = _get_pipeline()
    report = pipeline.get_report(analysis_id)
    if not report:
        raise HTTPException(status_code=404, detail=f"Analysis ID '{analysis_id}' not found.")
    return report


@app.get("/analysis/{analysis_id}/report", response_class=HTMLResponse)
async def get_analysis_html_report(analysis_id: str):
    """Retrieve rendered HTML research report by ID."""
    db_res = _db_store.get_analysis_result(analysis_id)
    if db_res:
        report = GenomeIntelligenceReport(**json.loads(db_res.report_json))
        from app.analysis.report import render_html_report
        return HTMLResponse(content=render_html_report(report))

    pipeline = _get_pipeline()
    html = pipeline.get_report_html(analysis_id)
    if not html:
        raise HTTPException(status_code=404, detail=f"Analysis ID '{analysis_id}' not found.")
    return HTMLResponse(content=html)


@app.post("/analysis/{analysis_id}/review")
async def submit_expert_review(analysis_id: str, req: ReviewSubmission):
    """Submit human expert review decision for an analysis report."""
    report = _review_manager.submit_review(
        analysis_id=analysis_id,
        reviewer_id=req.reviewer_id,
        decision=req.decision,
        notes=req.notes,
    )
    if not report:
        raise HTTPException(status_code=404, detail=f"Analysis ID '{analysis_id}' not found.")

    _audit_logger.log(
        user_id=req.reviewer_id,
        action="EXPERT_REVIEW_SUBMITTED",
        resource=analysis_id,
        details=f"Decision: {req.decision}",
    )
    return report


@app.post("/analysis/{analysis_id}/assistant")
async def ask_report_assistant(analysis_id: str, req: AssistantQuestionRequest):
    """Ask the report-grounded AI Explanation Assistant a question."""
    db_res = _db_store.get_analysis_result(analysis_id)
    if db_res:
        report = GenomeIntelligenceReport(**json.loads(db_res.report_json))
    else:
        pipeline = _get_pipeline()
        report = pipeline.get_report(analysis_id)

    if not report:
        raise HTTPException(status_code=404, detail=f"Analysis ID '{analysis_id}' not found.")

    ans = _assistant.answer_question(report, req.question)
    _audit_logger.log(user_id="anonymous", action="AI_ASSISTANT_QUERY", resource=analysis_id)
    return ans


# ---------------------------------------------------------------------------
# PDF Upload Preview Endpoint
# ---------------------------------------------------------------------------

@app.post("/upload-pdf", response_model=PDFUploadResponse)
async def upload_pdf_preview(file: UploadFile = File(...)):
    """Extract and preview sequences from an uploaded PDF without running the full pipeline.

    Returns page count, extraction status, detected sequence count, sequence IDs,
    and a text preview. Use this to inspect a PDF before submitting to /analyze.
    """
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=422, detail="Only .pdf files are accepted by this endpoint.")

    contents = await file.read()

    try:
        reader = PdfReader(io.BytesIO(contents))
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Could not open PDF: {exc}")

    if reader.is_encrypted:
        return PDFUploadResponse(
            filename=file.filename,
            page_count=0,
            extraction_status="encrypted",
            sequences_found=0,
            sequence_ids=[],
            text_preview="",
            message="PDF is encrypted. Please provide an unencrypted file.",
        )

    page_count = len(reader.pages)
    full_text = "\n".join(page.extract_text() or "" for page in reader.pages)

    if not full_text.strip():
        return PDFUploadResponse(
            filename=file.filename,
            page_count=page_count,
            extraction_status="empty",
            sequences_found=0,
            sequence_ids=[],
            text_preview="",
            message="No text could be extracted from this PDF (may be image-based/scanned).",
        )

    text_preview = full_text[:600].strip()

    # Try FASTA blocks first
    fasta_blocks = re.findall(r"(>[^\n]+\n[A-Za-z\n]+)", full_text)
    if fasta_blocks:
        fasta_str = "\n".join(fasta_blocks)
        parsed = parse_fasta(io.StringIO(fasta_str))
        seq_ids = [r.id for r in parsed]
        return PDFUploadResponse(
            filename=file.filename,
            page_count=page_count,
            extraction_status="sequences_found",
            sequences_found=len(parsed),
            sequence_ids=seq_ids,
            text_preview=text_preview,
            message=f"Found {len(parsed)} FASTA sequence(s) embedded in the PDF.",
        )

    # Fallback: nucleotide strings
    raw_seqs = re.findall(r"[ACGTUacgtu]{20,}", full_text)
    if raw_seqs:
        seq_ids = [f"{file.filename}_seq{i+1}" for i in range(len(raw_seqs))]
        return PDFUploadResponse(
            filename=file.filename,
            page_count=page_count,
            extraction_status="sequences_found",
            sequences_found=len(raw_seqs),
            sequence_ids=seq_ids,
            text_preview=text_preview,
            message=f"Found {len(raw_seqs)} nucleotide string(s) in the PDF (no FASTA headers).",
        )

    # Text only
    return PDFUploadResponse(
        filename=file.filename,
        page_count=page_count,
        extraction_status="text_only",
        sequences_found=0,
        sequence_ids=[],
        text_preview=text_preview,
        message="No nucleotide sequences detected. PDF contains only text — submitting to pipeline will use raw text context.",
    )


# ---------------------------------------------------------------------------
# Bioinformatics utility endpoints (/orfs, /align, /gc-profile, /embeddings)
# ---------------------------------------------------------------------------

@app.post("/orfs", response_model=ORFResponse)
async def locate_orfs(req: ORFRequest):
    """Locate Open Reading Frames across 6 reading frames in a nucleotide sequence."""
    orfs = find_orfs(req.sequence, min_length=req.min_length)
    return ORFResponse(
        orfs=[
            {
                "start": o.start,
                "end": o.end,
                "strand": o.strand,
                "frame": o.frame,
                "length": len(o.nucleotide_seq),
                "protein": o.protein_seq,
            }
            for o in orfs
        ]
    )


@app.post("/align", response_model=AlignResponse)
async def pairwise_align(req: AlignRequest):
    """Perform global pairwise alignment between two nucleotide sequences."""
    rec_a = SequenceRecord(id="seq_a", description="", sequence=req.sequence_a)
    rec_b = SequenceRecord(id="seq_b", description="", sequence=req.sequence_b)
    result = align_sequences(rec_a, rec_b)
    return AlignResponse(
        score=result.score,
        identity=round(result.identity, 6),
        aligned_a=result.aligned_a,
        aligned_b=result.aligned_b,
    )


@app.post("/gc-profile", response_model=GCProfileResponse)
async def gc_content_profile(req: GCProfileRequest):
    """Calculate sliding-window GC content profile across a sequence."""
    seq = req.sequence.upper()
    w = req.window_size
    profile: list[float] = []
    for i in range(0, len(seq) - w + 1):
        window = seq[i : i + w]
        gc = sum(1 for b in window if b in "GC") / w
        profile.append(round(gc, 4))
    return GCProfileResponse(window_size=w, profile=profile)


@app.get("/embeddings")
async def get_embeddings():
    """Return genome embedding coordinates for visualisation (if available)."""
    embeddings_path = _DEFAULT_MODEL_DIR / "genome_embeddings.npy"
    if not embeddings_path.exists():
        return JSONResponse(
            status_code=404,
            content={"detail": "No embeddings file found. Run embedding generation first."},
        )
    coords = np.load(str(embeddings_path)).tolist()
    return {"embeddings": coords, "count": len(coords)}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def start_server():
    """Launch the server via uvicorn (used by console_scripts entry point)."""
    import uvicorn

    uvicorn.run(
        "src.mcp_server:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info",
    )


if __name__ == "__main__":
    start_server()



