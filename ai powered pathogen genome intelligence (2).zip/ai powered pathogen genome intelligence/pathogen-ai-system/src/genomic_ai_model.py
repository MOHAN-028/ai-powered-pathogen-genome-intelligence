"""
genomic_ai_model.py
===================
Machine-learning pipeline for classifying and embedding pathogen genomes.

Strategy
--------
1. **K-mer tokenisation** – slide a window of size *k* across each DNA
   sequence to produce overlapping k-mer "words".
2. **TF-IDF vectorisation** – convert the k-mer vocabulary into numerical
   feature vectors via scikit-learn's TfidfVectorizer.
3. **Classification** – train a Logistic Regression (fast, interpretable)
   or Random Forest classifier to predict pathogen species / type.
4. **Embedding** – produce fixed-length numerical vectors for every genome
   that can be used for similarity search or clustering.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Literal, Optional

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.decomposition import TruncatedSVD

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# K-mer tokeniser
# ---------------------------------------------------------------------------

def kmer_tokenize(sequence: str, k: int = 6) -> list[str]:
    """Convert a DNA sequence into overlapping k-mers.

    >>> kmer_tokenize("ATCGATCG", k=4)
    ['ATCG', 'TCGA', 'CGAT', 'GATC', 'ATCG']
    """
    seq = sequence.upper().replace("N", "")
    return [seq[i : i + k] for i in range(len(seq) - k + 1)]


def sequences_to_kmer_corpus(sequences: list[str], k: int = 6) -> list[str]:
    """Transform a list of DNA sequences into a k-mer "corpus".

    Each sequence becomes a single space-joined string of its k-mers,
    compatible with scikit-learn text vectorisers.
    """
    return [" ".join(kmer_tokenize(seq, k=k)) for seq in sequences]


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------

@dataclass
class PredictionResult:
    """Container for a single classification prediction."""
    label: str
    confidence: float
    top_features: list[tuple[str, float]] = field(default_factory=list)


class PathogenClassifier:
    """K-mer → TF-IDF → classifier pipeline for pathogen genomes.

    Parameters
    ----------
    k : int
        K-mer size (default 6).
    model_type : str
        ``"logistic"`` for LogisticRegression or ``"rf"`` for
        RandomForestClassifier.
    max_features : int
        Maximum vocabulary size for TF-IDF.
    """

    def __init__(
        self,
        k: int = 6,
        model_type: Literal["logistic", "rf"] = "logistic",
        max_features: int = 10_000,
    ) -> None:
        self.k = k
        self.model_type = model_type
        self.max_features = max_features

        self._vectorizer = TfidfVectorizer(
            analyzer="word",
            max_features=max_features,
            sublinear_tf=True,
        )

        if model_type == "rf":
            self._classifier = RandomForestClassifier(
                n_estimators=200,
                max_depth=None,
                n_jobs=-1,
                random_state=42,
            )
        else:
            self._classifier = LogisticRegression(
                max_iter=1000,
                C=1.0,
                solver="lbfgs",
                random_state=42,
            )

        self._is_fitted = False
        self._classes: list[str] = []

    # -- Training -----------------------------------------------------------

    def fit(self, sequences: list[str], labels: list[str]) -> dict:
        """Train the classifier on *sequences* / *labels*.

        Returns a dict with ``accuracy`` and ``classification_report``.
        """
        corpus = sequences_to_kmer_corpus(sequences, k=self.k)
        X = self._vectorizer.fit_transform(corpus)
        self._classifier.fit(X, labels)
        self._is_fitted = True
        self._classes = list(self._classifier.classes_)

        # Evaluate on training data (quick sanity check)
        preds = self._classifier.predict(X)
        acc = accuracy_score(labels, preds)
        report = classification_report(labels, preds, zero_division=0)
        logger.info("Training accuracy: %.4f", acc)
        return {"accuracy": acc, "classification_report": report}

    def train_eval(
        self,
        sequences: list[str],
        labels: list[str],
        test_size: float = 0.2,
    ) -> dict:
        """Split data, train, and evaluate. Returns metrics dict."""
        from collections import Counter
        label_counts = Counter(labels)
        n_classes = len(label_counts)
        min_class_count = min(label_counts.values())
        test_count = int(len(sequences) * test_size)

        use_stratify = labels if (min_class_count >= 2 and test_count >= n_classes) else None

        X_train, X_test, y_train, y_test = train_test_split(
            sequences, labels, test_size=test_size, random_state=42, stratify=use_stratify,
        )
        corpus_train = sequences_to_kmer_corpus(X_train, k=self.k)
        corpus_test = sequences_to_kmer_corpus(X_test, k=self.k)

        X_tr = self._vectorizer.fit_transform(corpus_train)
        X_te = self._vectorizer.transform(corpus_test)

        self._classifier.fit(X_tr, y_train)
        self._is_fitted = True
        self._classes = list(self._classifier.classes_)

        preds = self._classifier.predict(X_te)
        acc = accuracy_score(y_test, preds)
        report = classification_report(y_test, preds, zero_division=0)
        logger.info("Test accuracy: %.4f", acc)
        return {
            "accuracy": acc,
            "classification_report": report,
            "train_size": len(X_train),
            "test_size": len(X_test),
        }

    # -- Prediction ---------------------------------------------------------

    def predict(self, sequence: str, top_n_features: int = 10) -> PredictionResult:
        """Classify a single sequence and return a PredictionResult."""
        self._check_fitted()
        corpus = sequences_to_kmer_corpus([sequence], k=self.k)
        X = self._vectorizer.transform(corpus)

        label = self._classifier.predict(X)[0]
        proba = self._classifier.predict_proba(X)[0]
        confidence = float(proba.max())

        # Top contributing k-mers (for Logistic Regression only)
        top_features: list[tuple[str, float]] = []
        if hasattr(self._classifier, "coef_"):
            class_idx = list(self._classifier.classes_).index(label)
            # Binary classifiers store only one row in coef_
            if self._classifier.coef_.shape[0] == 1:
                coef_idx = 0
            else:
                coef_idx = class_idx
            coefs = self._classifier.coef_[coef_idx]
            feature_names = self._vectorizer.get_feature_names_out()
            nonzero = X.toarray()[0] > 0
            active_indices = np.where(nonzero)[0]
            scored = [
                (feature_names[i], float(coefs[i]))
                for i in active_indices
            ]
            scored.sort(key=lambda x: abs(x[1]), reverse=True)
            top_features = scored[:top_n_features]

        return PredictionResult(
            label=label,
            confidence=confidence,
            top_features=top_features,
        )

    def predict_batch(self, sequences: list[str]) -> list[PredictionResult]:
        """Classify multiple sequences."""
        return [self.predict(seq) for seq in sequences]

    # -- Internals ----------------------------------------------------------

    def _check_fitted(self):
        if not self._is_fitted:
            raise RuntimeError("Model has not been trained yet. Call fit() first.")

    @property
    def classes(self) -> list[str]:
        return self._classes


# ---------------------------------------------------------------------------
# Genome embedder
# ---------------------------------------------------------------------------

class GenomeEmbedder:
    """Produce fixed-length numerical embeddings for genome sequences.

    Uses TF-IDF k-mer vectors reduced to *n_components* dimensions via
    Truncated SVD (latent semantic analysis).

    Parameters
    ----------
    k : int
        K-mer size.
    n_components : int
        Embedding dimensionality.
    max_features : int
        TF-IDF vocabulary cap.
    """

    def __init__(
        self,
        k: int = 6,
        n_components: int = 64,
        max_features: int = 10_000,
    ) -> None:
        self.k = k
        self.n_components = n_components
        self._vectorizer = TfidfVectorizer(
            analyzer="word",
            max_features=max_features,
            sublinear_tf=True,
        )
        self._svd = TruncatedSVD(n_components=n_components, random_state=42)
        self._is_fitted = False

    def fit(self, sequences: list[str]) -> "GenomeEmbedder":
        """Fit the vectoriser and SVD on *sequences*."""
        corpus = sequences_to_kmer_corpus(sequences, k=self.k)
        X = self._vectorizer.fit_transform(corpus)
        self._svd.fit(X)
        self._is_fitted = True
        explained = self._svd.explained_variance_ratio_.sum()
        logger.info(
            "Embedder fitted – %d components explain %.1f%% variance",
            self.n_components,
            explained * 100,
        )
        return self

    def transform(self, sequences: list[str]) -> np.ndarray:
        """Return (n_sequences, n_components) embedding matrix."""
        if not self._is_fitted:
            raise RuntimeError("Embedder not fitted. Call fit() first.")
        corpus = sequences_to_kmer_corpus(sequences, k=self.k)
        X = self._vectorizer.transform(corpus)
        return self._svd.transform(X)

    def fit_transform(self, sequences: list[str]) -> np.ndarray:
        """Fit and transform in one step."""
        self.fit(sequences)
        return self.transform(sequences)
