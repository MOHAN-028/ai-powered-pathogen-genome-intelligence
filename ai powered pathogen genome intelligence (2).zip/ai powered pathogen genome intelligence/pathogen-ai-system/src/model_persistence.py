"""
model_persistence.py
====================
Save, load, and list trained models with metadata (timestamp, accuracy,
parameters).  Uses ``joblib`` for serialisation and stores a companion
JSON metadata file alongside each model.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import joblib

logger = logging.getLogger(__name__)

DEFAULT_MODELS_DIR = Path(__file__).resolve().parent.parent / "models" / "saved_models"


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------

@dataclass
class ModelMetadata:
    """Companion metadata persisted alongside a saved model."""
    model_name: str
    version: str
    saved_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    accuracy: Optional[float] = None
    parameters: dict[str, Any] = field(default_factory=dict)
    description: str = ""
    training_samples: Optional[int] = None


# ---------------------------------------------------------------------------
# Save / Load / List
# ---------------------------------------------------------------------------

def save_model(
    model: Any,
    name: str,
    *,
    version: str = "1.0",
    accuracy: Optional[float] = None,
    parameters: Optional[dict] = None,
    description: str = "",
    training_samples: Optional[int] = None,
    directory: Path | str = DEFAULT_MODELS_DIR,
) -> Path:
    """Serialise *model* to disk and write a metadata sidecar.

    Parameters
    ----------
    model : Any
        The model (or pipeline) object to persist.
    name : str
        Logical model name (used as the file stem).
    version : str
        Human-readable version string.
    accuracy : float | None
        Optional accuracy metric to record.
    parameters : dict | None
        Optional dict of hyper-parameters / config to record.
    description : str
        Free-text description.
    training_samples : int | None
        Number of training samples used.
    directory : Path | str
        Target directory.  Created if it does not exist.

    Returns
    -------
    Path
        The path to the saved ``.joblib`` file.
    """
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)

    model_path = directory / f"{name}.joblib"
    meta_path = directory / f"{name}.meta.json"

    # Persist model
    joblib.dump(model, model_path)
    logger.info("Model saved → %s", model_path)

    # Persist metadata
    meta = ModelMetadata(
        model_name=name,
        version=version,
        accuracy=accuracy,
        parameters=parameters or {},
        description=description,
        training_samples=training_samples,
    )
    meta_path.write_text(json.dumps(asdict(meta), indent=2))
    logger.info("Metadata saved → %s", meta_path)

    return model_path


def load_model(path: str | Path) -> tuple[Any, Optional[ModelMetadata]]:
    """Deserialise a model and its metadata sidecar (if present).

    Parameters
    ----------
    path : str | Path
        Path to the ``.joblib`` file.

    Returns
    -------
    tuple[model, ModelMetadata | None]
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Model file not found: {path}")

    model = joblib.load(path)
    logger.info("Model loaded ← %s", path)

    # Try to load sidecar metadata
    meta_path = path.with_suffix("").with_suffix(".meta.json")
    if not meta_path.exists():
        # Also try <stem>.meta.json pattern
        meta_path = path.parent / f"{path.stem}.meta.json"

    metadata: Optional[ModelMetadata] = None
    if meta_path.exists():
        raw = json.loads(meta_path.read_text())
        metadata = ModelMetadata(**raw)
        logger.info("Metadata loaded ← %s", meta_path)

    return model, metadata


def list_models(directory: Path | str = DEFAULT_MODELS_DIR) -> list[dict]:
    """List all saved models in *directory* with their metadata.

    Returns
    -------
    list[dict]
        Each dict contains ``"file"``, ``"size_bytes"``, and any metadata
        fields.
    """
    directory = Path(directory)
    if not directory.exists():
        return []

    entries: list[dict] = []
    for model_file in sorted(directory.glob("*.joblib")):
        entry: dict = {
            "file": str(model_file),
            "size_bytes": model_file.stat().st_size,
        }
        meta_path = model_file.parent / f"{model_file.stem}.meta.json"
        if meta_path.exists():
            entry["metadata"] = json.loads(meta_path.read_text())
        entries.append(entry)

    logger.info("Found %d saved model(s) in %s", len(entries), directory)
    return entries
