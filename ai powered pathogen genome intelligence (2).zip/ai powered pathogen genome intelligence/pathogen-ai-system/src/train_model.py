"""
train_model.py
==============
CLI script for training the PathogenClassifier on FASTA data, evaluating
it, persisting the model, and generating genome embeddings.

Usage
-----
    python -m src.train_model                       # defaults
    python -m src.train_model --data data/my.fasta   # custom input
    python -m src.train_model --model-type rf         # Random Forest
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np

from src.bioinformatics_tools import parse_fasta, sequence_statistics
from src.genomic_ai_model import PathogenClassifier, GenomeEmbedder
from src.model_persistence import save_model

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="[PATHOGEN-TRAIN] %(levelname)s  %(message)s",
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_labelled_fasta(path: Path) -> tuple[list[str], list[str]]:
    """Parse FASTA where the description line contains a label.

    Expected format per record:
        >seq_id  [label=Escherichia_coli]  optional description …

    If no ``[label=…]`` tag is found, the first word of the description
    (after the id) is used as the label.
    """
    records = parse_fasta(path)
    sequences: list[str] = []
    labels: list[str] = []

    for rec in records:
        seq = rec.sequence
        if not seq:
            continue
        # Try to extract [label=…]
        desc = rec.description
        label = None
        if "[label=" in desc:
            start = desc.index("[label=") + len("[label=")
            end = desc.index("]", start)
            label = desc[start:end]
        else:
            # Fallback: use the second word (first word is the id)
            parts = desc.split()
            label = parts[1] if len(parts) > 1 else "unknown"

        sequences.append(seq)
        labels.append(label)

    return sequences, labels


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        description="Train the Pathogen Genome Classifier",
    )
    parser.add_argument(
        "--data",
        type=Path,
        default=Path("data/sample_pathogen_sequences.fasta"),
        help="Path to labelled FASTA file",
    )
    parser.add_argument(
        "--model-name",
        default="pathogen_classifier",
        help="Name for the saved model",
    )
    parser.add_argument(
        "--model-type",
        choices=["logistic", "rf"],
        default="logistic",
        help="Classifier type",
    )
    parser.add_argument(
        "--k",
        type=int,
        default=6,
        help="K-mer size",
    )
    parser.add_argument(
        "--embed-dim",
        type=int,
        default=64,
        help="Embedding dimensionality",
    )
    parser.add_argument(
        "--test-size",
        type=float,
        default=0.2,
        help="Fraction of data for testing",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("models/saved_models"),
        help="Directory to save the model",
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=Path("results"),
        help="Directory to save embeddings and metrics",
    )

    args = parser.parse_args(argv)

    # -- 1. Load data -------------------------------------------------------
    if not args.data.exists():
        logger.error("Data file not found: %s", args.data)
        sys.exit(1)

    logger.info("Loading data from %s …", args.data)
    sequences, labels = _load_labelled_fasta(args.data)
    logger.info("Loaded %d sequences with %d unique labels", len(sequences), len(set(labels)))

    if len(sequences) < 5:
        logger.warning("Very few samples (%d) – evaluation may be unreliable", len(sequences))

    # -- 2. Train classifier ------------------------------------------------
    logger.info("Training %s classifier (k=%d) …", args.model_type, args.k)
    classifier = PathogenClassifier(
        k=args.k,
        model_type=args.model_type,
        max_features=10_000,
    )

    # If we have enough data, do a train/test split; otherwise just fit
    if len(sequences) >= 10 and len(set(labels)) >= 2:
        # Ensure each class has at least 2 samples for stratification
        from collections import Counter
        label_counts = Counter(labels)
        min_count = min(label_counts.values())
        if min_count >= 2:
            metrics = classifier.train_eval(sequences, labels, test_size=args.test_size)
        else:
            metrics = classifier.fit(sequences, labels)
    else:
        metrics = classifier.fit(sequences, labels)

    logger.info("Metrics:\n%s", json.dumps({k: v for k, v in metrics.items() if k != "classification_report"}, indent=2))
    if "classification_report" in metrics:
        logger.info("Classification Report:\n%s", metrics["classification_report"])

    # -- 3. Save model ------------------------------------------------------
    args.output_dir.mkdir(parents=True, exist_ok=True)
    model_path = save_model(
        model=classifier,
        name=args.model_name,
        accuracy=metrics.get("accuracy"),
        parameters={"k": args.k, "model_type": args.model_type},
        description=f"Pathogen classifier trained on {len(sequences)} sequences",
        training_samples=len(sequences),
        directory=args.output_dir,
    )
    logger.info("Model saved to %s", model_path)

    # -- 4. Generate embeddings ---------------------------------------------
    logger.info("Generating %d-dim embeddings …", args.embed_dim)
    embed_dim = min(args.embed_dim, len(sequences) - 1, 10_000)
    if embed_dim < 2:
        logger.warning("Not enough sequences for meaningful embeddings, skipping.")
    else:
        embedder = GenomeEmbedder(k=args.k, n_components=embed_dim)
        embeddings = embedder.fit_transform(sequences)

        args.results_dir.mkdir(parents=True, exist_ok=True)
        embed_path = args.results_dir / "embeddings.npy"
        np.save(embed_path, embeddings)
        logger.info("Embeddings saved to %s  (shape=%s)", embed_path, embeddings.shape)

        # Save embedder
        save_model(
            model=embedder,
            name="genome_embedder",
            parameters={"k": args.k, "n_components": embed_dim},
            description="Genome embedder for pathogen sequences",
            directory=args.output_dir,
        )

    # -- 5. Save analysis results -------------------------------------------
    results_path = args.results_dir / "analysis_results.json"
    analysis = {
        "model_name": args.model_name,
        "model_type": args.model_type,
        "k": args.k,
        "num_sequences": len(sequences),
        "num_classes": len(set(labels)),
        "classes": sorted(set(labels)),
        "accuracy": metrics.get("accuracy"),
    }
    results_path.write_text(json.dumps(analysis, indent=2))
    logger.info("Analysis results saved to %s", results_path)

    logger.info("✅ Training complete!")


if __name__ == "__main__":
    main()
