"""
bioinformatics_tools.py
=======================
Utility functions for parsing, validating, and analysing pathogen genome
sequences.  Wraps BioPython and standard bioinformatics operations.
"""

from __future__ import annotations

import io
import logging
import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator, Optional

from Bio import SeqIO
from Bio.Align import PairwiseAligner
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.SeqUtils import gc_fraction

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class SequenceRecord:
    """Lightweight representation of a parsed sequence."""
    id: str
    description: str
    sequence: str
    quality_scores: Optional[list[int]] = None

    @property
    def length(self) -> int:
        return len(self.sequence)


@dataclass
class SequenceStatistics:
    """Summary statistics for a single sequence."""
    id: str
    length: int
    gc_content: float
    base_composition: dict[str, int]
    avg_quality: Optional[float] = None


@dataclass
class ORF:
    """An Open Reading Frame found within a sequence."""
    start: int
    end: int
    strand: str  # '+' or '-'
    frame: int
    nucleotide_seq: str
    protein_seq: str


@dataclass
class AlignmentResult:
    """Result of a pairwise sequence alignment."""
    seq_a_id: str
    seq_b_id: str
    score: float
    aligned_a: str
    aligned_b: str
    identity: float  # fraction of identical positions


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------

def parse_fasta(source: str | Path | io.IOBase) -> list[SequenceRecord]:
    """Parse a FASTA file or string into a list of SequenceRecords.

    Parameters
    ----------
    source : str | Path | io.IOBase
        A file path, a raw FASTA string, or a file-like object.

    Returns
    -------
    list[SequenceRecord]
    """
    handle = _open_source(source, fmt_hint="fasta")
    records: list[SequenceRecord] = []
    for rec in SeqIO.parse(handle, "fasta"):
        records.append(
            SequenceRecord(
                id=rec.id,
                description=rec.description,
                sequence=str(rec.seq),
            )
        )
    logger.info("Parsed %d FASTA records", len(records))
    return records


def parse_fastq(source: str | Path | io.IOBase) -> list[SequenceRecord]:
    """Parse a FASTQ file or string into SequenceRecords (with quality).

    Parameters
    ----------
    source : str | Path | io.IOBase

    Returns
    -------
    list[SequenceRecord]
    """
    handle = _open_source(source, fmt_hint="fastq")
    records: list[SequenceRecord] = []
    for rec in SeqIO.parse(handle, "fastq"):
        records.append(
            SequenceRecord(
                id=rec.id,
                description=rec.description,
                sequence=str(rec.seq),
                quality_scores=rec.letter_annotations.get("phred_quality"),
            )
        )
    logger.info("Parsed %d FASTQ records", len(records))
    return records


def _open_source(source, *, fmt_hint: str):
    """Return a file-like handle for *source*."""
    if isinstance(source, io.IOBase):
        return source
    path = Path(source)
    if path.is_file():
        return open(path, "r")
    # Treat as raw string content
    return io.StringIO(source)


# ---------------------------------------------------------------------------
# Analysis helpers
# ---------------------------------------------------------------------------

def compute_gc_content(sequence: str) -> float:
    """Return GC fraction (0.0 – 1.0) for a nucleotide sequence."""
    seq_obj = Seq(sequence.upper())
    return gc_fraction(seq_obj)


def base_composition(sequence: str) -> dict[str, int]:
    """Count occurrences of each nucleotide base."""
    seq = sequence.upper()
    return {
        "A": seq.count("A"),
        "T": seq.count("T"),
        "G": seq.count("G"),
        "C": seq.count("C"),
        "N": seq.count("N"),
        "other": len(seq) - sum(seq.count(b) for b in "ATGCN"),
    }


def sequence_statistics(record: SequenceRecord) -> SequenceStatistics:
    """Compute summary statistics for a single SequenceRecord."""
    avg_q = None
    if record.quality_scores:
        avg_q = sum(record.quality_scores) / len(record.quality_scores)
    return SequenceStatistics(
        id=record.id,
        length=record.length,
        gc_content=compute_gc_content(record.sequence),
        base_composition=base_composition(record.sequence),
        avg_quality=avg_q,
    )


# ---------------------------------------------------------------------------
# ORF finding
# ---------------------------------------------------------------------------

_START_CODON = "ATG"
_STOP_CODONS = {"TAA", "TAG", "TGA"}


def find_orfs(
    sequence: str,
    min_length: int = 100,
    both_strands: bool = True,
) -> list[ORF]:
    """Locate Open Reading Frames in *sequence*.

    Parameters
    ----------
    sequence : str
        Nucleotide sequence (upper-case assumed internally).
    min_length : int
        Minimum nucleotide length of an ORF to report.
    both_strands : bool
        If True, also search the reverse complement.

    Returns
    -------
    list[ORF]
    """
    seq_upper = sequence.upper()
    orfs: list[ORF] = []

    for strand_label, strand_seq in _strands(seq_upper, both_strands):
        for frame in range(3):
            i = frame
            while i + 3 <= len(strand_seq):
                codon = strand_seq[i : i + 3]
                if codon == _START_CODON:
                    # Walk forward looking for a stop
                    for j in range(i + 3, len(strand_seq) - 2, 3):
                        stop = strand_seq[j : j + 3]
                        if stop in _STOP_CODONS:
                            orf_seq = strand_seq[i : j + 3]
                            if len(orf_seq) >= min_length:
                                protein = str(Seq(orf_seq).translate(to_stop=True))
                                orfs.append(
                                    ORF(
                                        start=i,
                                        end=j + 3,
                                        strand=strand_label,
                                        frame=frame,
                                        nucleotide_seq=orf_seq,
                                        protein_seq=protein,
                                    )
                                )
                            i = j + 3  # skip past this ORF
                            break
                    else:
                        i += 3
                        continue
                    continue
                i += 3

    logger.info("Found %d ORFs (min_length=%d)", len(orfs), min_length)
    return orfs


def _strands(seq: str, both: bool):
    """Yield (label, sequence) pairs for one or both strands."""
    yield ("+", seq)
    if both:
        yield ("-", str(Seq(seq).reverse_complement()))


# ---------------------------------------------------------------------------
# BLAST wrapper
# ---------------------------------------------------------------------------

def run_blast(
    query_path: str | Path,
    db_path: str | Path,
    program: str = "blastn",
    evalue: float = 1e-5,
    max_hits: int = 10,
    outfmt: int = 6,
) -> str:
    """Execute a local BLAST search and return raw output.

    Requires BLAST+ to be installed and on PATH (provided by the Docker
    sandbox).

    Parameters
    ----------
    query_path : str | Path
        Path to the query FASTA file.
    db_path : str | Path
        Path to the BLAST database.
    program : str
        BLAST program to run (blastn, blastp, blastx, etc.).
    evalue : float
        E-value threshold.
    max_hits : int
        Maximum number of target sequences.
    outfmt : int
        Output format (6 = tabular).

    Returns
    -------
    str
        Raw BLAST output.
    """
    cmd = [
        program,
        "-query", str(query_path),
        "-db", str(db_path),
        "-evalue", str(evalue),
        "-max_target_seqs", str(max_hits),
        "-outfmt", str(outfmt),
    ]
    logger.info("Running BLAST: %s", " ".join(cmd))
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=300, check=True,
        )
        return result.stdout
    except FileNotFoundError:
        logger.error("%s not found on PATH. Is BLAST+ installed?", program)
        raise
    except subprocess.CalledProcessError as exc:
        logger.error("BLAST failed: %s", exc.stderr)
        raise


# ---------------------------------------------------------------------------
# Pairwise alignment
# ---------------------------------------------------------------------------

def align_sequences(
    seq_a: SequenceRecord,
    seq_b: SequenceRecord,
    match: int = 2,
    mismatch: int = -1,
    gap_open: int = -5,
    gap_extend: int = -0.5,
) -> AlignmentResult:
    """Perform global pairwise alignment between two sequences.

    Uses BioPython's ``Bio.Align.PairwiseAligner``.

    Returns
    -------
    AlignmentResult
    """
    aligner = PairwiseAligner()
    aligner.mode = "global"
    aligner.match_score = match
    aligner.mismatch_score = mismatch
    aligner.open_gap_score = gap_open
    aligner.extend_gap_score = gap_extend

    alignments = aligner.align(seq_a.sequence, seq_b.sequence)

    if not alignments:
        return AlignmentResult(
            seq_a_id=seq_a.id,
            seq_b_id=seq_b.id,
            score=0.0,
            aligned_a="",
            aligned_b="",
            identity=0.0,
        )

    aln = alignments[0]
    score = float(aln.score)

    # Extract aligned strings from the alignment
    aligned_a = str(aln[0])
    aligned_b = str(aln[1])
    identical = sum(a == b for a, b in zip(aligned_a, aligned_b))
    identity = identical / max(len(aligned_a), 1)

    return AlignmentResult(
        seq_a_id=seq_a.id,
        seq_b_id=seq_b.id,
        score=score,
        aligned_a=aligned_a,
        aligned_b=aligned_b,
        identity=identity,
    )
