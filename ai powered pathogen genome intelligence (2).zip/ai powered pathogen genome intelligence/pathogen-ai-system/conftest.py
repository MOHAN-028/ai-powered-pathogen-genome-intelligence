"""
conftest.py
===========
Pytest configuration: ensures the project root is on sys.path so that both
`from app.*` and `from src.*` imports resolve without requiring `pip install -e .`.
"""
import sys
from pathlib import Path

# Add the project root (directory containing this file) to sys.path
PROJECT_ROOT = Path(__file__).parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
