"""
app/agent/tools.py
==================
Phase 4: Strict Tool Allowlist and Secure Tool Execution Engine.

Allowed Tools:
  - get_analysis(analysis_id, user_id)
  - get_qc_results(analysis_id, user_id)
  - get_similarity_results(analysis_id, user_id)
  - get_novelty_results(analysis_id, user_id)
  - get_classification_results(analysis_id, user_id)
  - get_report(analysis_id, user_id)

Prohibited Tools (explicitly blocked and audited):
  - execute_shell()
  - modify_sequence()
  - design_pathogen()
  - optimize_pathogen()
  - synthesize_sequence()
  - increase_virulence()
  - increase_transmission()

Security Guarantees:
  1. Strict Allowlist: Only predefined, non-modifying analytical tools can execute.
  2. Authorization Enforcement: Multi-user isolation checked on every tool call.
  3. No Shell / Arbitrary DB: Arbitrary command execution is structurally impossible.
  4. Audit Logging: Every tool execution and blocked abuse attempt is recorded.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set
from pydantic import BaseModel, Field

from app.agent.context_builder import AnalysisContextBuilder
from app.db.database import DatabaseStore
from app.models.schemas import GenomeIntelligenceReport
from app.security.audit import AuditLogger


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class ToolSecurityError(Exception):
    """Base exception for tool execution security violations."""
    pass


class ProhibitedToolError(ToolSecurityError):
    """Raised when an attempt is made to invoke a prohibited/hazardous tool."""
    pass


class ToolNotFoundError(ToolSecurityError):
    """Raised when an unallowlisted or unknown tool is requested."""
    pass


class ToolAuthorizationError(ToolSecurityError):
    """Raised when the user is not authorized to access the requested resource."""
    pass


class ToolParameterError(ToolSecurityError):
    """Raised when tool parameters are invalid or malformed."""
    pass


# ---------------------------------------------------------------------------
# Tool Metadata & Definitions
# ---------------------------------------------------------------------------

class ToolDefinition(BaseModel):
    """Metadata schema describing an allowed agent tool."""
    name: str = Field(..., description="Unique tool identifier")
    description: str = Field(..., description="Human and model readable tool description")
    parameters: Dict[str, Any] = Field(default_factory=dict, description="JSON schema of accepted parameters")
    is_safe: bool = Field(default=True, description="Safety certification flag")


@dataclass
class ToolExecutionResult:
    """Outcome of a tool execution."""
    success: bool
    tool_name: str
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    audit_event_id: Optional[str] = None


# ---------------------------------------------------------------------------
# Prohibited & Allowed Tool Constants
# ---------------------------------------------------------------------------

_PROHIBITED_TOOLS: Set[str] = {
    "execute_shell",
    "modify_sequence",
    "design_pathogen",
    "optimize_pathogen",
    "synthesize_sequence",
    "increase_virulence",
    "increase_transmission",
    "run_command",
    "eval_code",
    "raw_sql_query",
    "delete_database",
    "alter_reference",
}


# ---------------------------------------------------------------------------
# Tool Implementations
# ---------------------------------------------------------------------------

def _fetch_authorized_report(
    analysis_id: str,
    user_id: str,
    db_store: DatabaseStore,
) -> GenomeIntelligenceReport:
    """Fetch and deserialize report with strict authorization check."""
    clean_id = analysis_id.strip()
    if not clean_id:
        raise ToolParameterError("analysis_id cannot be empty.")

    db_result = db_store.get_analysis_result(clean_id)
    if not db_result:
        raise ToolParameterError(f"Analysis ID '{clean_id}' not found.")

    if not db_store.is_user_authorized_for_analysis(user_id=user_id, analysis_id=clean_id):
        raise ToolAuthorizationError(
            f"Access denied: User '{user_id}' is not authorized to view analysis '{clean_id}'."
        )

    try:
        report_dict = json.loads(db_result.report_json)
        return GenomeIntelligenceReport(**report_dict)
    except Exception as exc:
        raise ToolSecurityError(f"Failed to parse report data: {exc}")


def _tool_get_analysis(analysis_id: str, user_id: str, db_store: DatabaseStore) -> Dict[str, Any]:
    """Retrieve the complete structured analysis context for a sample."""
    report = _fetch_authorized_report(analysis_id, user_id, db_store)
    return AnalysisContextBuilder.build_context(report)


def _tool_get_qc_results(analysis_id: str, user_id: str, db_store: DatabaseStore) -> Dict[str, Any]:
    """Retrieve only quality control statistics for a sample."""
    report = _fetch_authorized_report(analysis_id, user_id, db_store)
    ctx = AnalysisContextBuilder.build_context(report)
    return {
        "analysis_id": analysis_id,
        "sample_id": report.sample_id,
        "quality_control": ctx["quality_control"],
    }


def _tool_get_similarity_results(analysis_id: str, user_id: str, db_store: DatabaseStore) -> Dict[str, Any]:
    """Retrieve only similarity analysis and reference hits for a sample."""
    report = _fetch_authorized_report(analysis_id, user_id, db_store)
    ctx = AnalysisContextBuilder.build_context(report)
    return {
        "analysis_id": analysis_id,
        "sample_id": report.sample_id,
        "similarity": ctx["similarity"],
    }


def _tool_get_novelty_results(analysis_id: str, user_id: str, db_store: DatabaseStore) -> Dict[str, Any]:
    """Retrieve only novelty detection and divergence metrics for a sample."""
    report = _fetch_authorized_report(analysis_id, user_id, db_store)
    ctx = AnalysisContextBuilder.build_context(report)
    return {
        "analysis_id": analysis_id,
        "sample_id": report.sample_id,
        "novelty": ctx["novelty"],
    }


def _tool_get_classification_results(analysis_id: str, user_id: str, db_store: DatabaseStore) -> Dict[str, Any]:
    """Retrieve only taxonomic classification and confidence metrics for a sample."""
    report = _fetch_authorized_report(analysis_id, user_id, db_store)
    ctx = AnalysisContextBuilder.build_context(report)
    return {
        "analysis_id": analysis_id,
        "sample_id": report.sample_id,
        "classification": ctx["classification"],
        "confidence": ctx["confidence"],
        "uncertainty": ctx["uncertainty"],
    }


def _tool_get_report(analysis_id: str, user_id: str, db_store: DatabaseStore) -> Dict[str, Any]:
    """Retrieve the full raw report dictionary with all metadata."""
    report = _fetch_authorized_report(analysis_id, user_id, db_store)
    return report.model_dump()


# ---------------------------------------------------------------------------
# Tool Registry
# ---------------------------------------------------------------------------

class ToolRegistry:
    """Strict tool registry enforcing tool allowlisting, authorization, and audit logging."""

    def __init__(
        self,
        db_store: Optional[DatabaseStore] = None,
        audit_logger: Optional[AuditLogger] = None,
    ) -> None:
        self.db_store = db_store
        self.audit_logger = audit_logger

        self._allowed_tools: Dict[str, Callable[..., Dict[str, Any]]] = {
            "get_analysis": _tool_get_analysis,
            "get_qc_results": _tool_get_qc_results,
            "get_similarity_results": _tool_get_similarity_results,
            "get_novelty_results": _tool_get_novelty_results,
            "get_classification_results": _tool_get_classification_results,
            "get_report": _tool_get_report,
        }

        self._definitions: Dict[str, ToolDefinition] = {
            "get_analysis": ToolDefinition(
                name="get_analysis",
                description="Retrieve verified, structured analysis report metrics (QC, similarity, novelty, classification, uncertainty).",
                parameters={
                    "type": "object",
                    "properties": {
                        "analysis_id": {"type": "string", "description": "The unique analysis ID to look up."}
                    },
                    "required": ["analysis_id"],
                },
            ),
            "get_qc_results": ToolDefinition(
                name="get_qc_results",
                description="Retrieve quality control metrics (sequence length, GC content, ambiguous bases, base composition).",
                parameters={
                    "type": "object",
                    "properties": {
                        "analysis_id": {"type": "string", "description": "The unique analysis ID."}
                    },
                    "required": ["analysis_id"],
                },
            ),
            "get_similarity_results": ToolDefinition(
                name="get_similarity_results",
                description="Retrieve reference similarity matches, top hit accessions, identity percentage, and alignment coverage.",
                parameters={
                    "type": "object",
                    "properties": {
                        "analysis_id": {"type": "string", "description": "The unique analysis ID."}
                    },
                    "required": ["analysis_id"],
                },
            ),
            "get_novelty_results": ToolDefinition(
                name="get_novelty_results",
                description="Retrieve genomic novelty classification, divergence scores, and distinction notices.",
                parameters={
                    "type": "object",
                    "properties": {
                        "analysis_id": {"type": "string", "description": "The unique analysis ID."}
                    },
                    "required": ["analysis_id"],
                },
            ),
            "get_classification_results": ToolDefinition(
                name="get_classification_results",
                description="Retrieve predicted taxon classification, model confidence, and epistemic uncertainty.",
                parameters={
                    "type": "object",
                    "properties": {
                        "analysis_id": {"type": "string", "description": "The unique analysis ID."}
                    },
                    "required": ["analysis_id"],
                },
            ),
            "get_report": ToolDefinition(
                name="get_report",
                description="Retrieve the complete raw GenomeIntelligenceReport dictionary.",
                parameters={
                    "type": "object",
                    "properties": {
                        "analysis_id": {"type": "string", "description": "The unique analysis ID."}
                    },
                    "required": ["analysis_id"],
                },
            ),
        }

    # ------------------------------------------------------------------
    # Introspection & Schemas
    # ------------------------------------------------------------------

    @property
    def allowed_tool_names(self) -> List[str]:
        """Return the list of all strictly allowlisted tool names."""
        return list(self._allowed_tools.keys())

    @property
    def prohibited_tool_names(self) -> List[str]:
        """Return the list of explicitly prohibited hazardous tools."""
        return list(_PROHIBITED_TOOLS)

    def get_tool_definitions(self) -> List[Dict[str, Any]]:
        """Return JSON-schema definitions for all allowlisted tools."""
        return [t.model_dump() for t in self._definitions.values()]

    def is_tool_allowed(self, tool_name: str) -> bool:
        """Check if a tool name is on the strict allowlist."""
        return tool_name in self._allowed_tools

    def is_tool_prohibited(self, tool_name: str) -> bool:
        """Check if a tool name is in the prohibited/hazardous set."""
        return tool_name in _PROHIBITED_TOOLS

    # ------------------------------------------------------------------
    # Secure Execution
    # ------------------------------------------------------------------

    def execute(
        self,
        tool_name: str,
        parameters: Dict[str, Any],
        user_id: str = "anonymous",
        client_ip: str = "127.0.0.1",
    ) -> ToolExecutionResult:
        """Execute a tool with strict allowlist, parameter sanitization, authorization, and audit logging.

        Raises:
            ProhibitedToolError: If an attempt is made to call a hazardous tool.
            ToolNotFoundError: If the tool is not on the allowlist.
            ToolAuthorizationError: If the user lacks permissions for the analysis.
            ToolParameterError: If required parameters are missing or invalid.
        """
        clean_name = tool_name.strip().lower()

        # 1. Prohibited Tool Interception
        if clean_name in _PROHIBITED_TOOLS:
            if self.audit_logger:
                self.audit_logger.log(
                    user_id=user_id,
                    action="SECURITY_PROHIBITED_TOOL_ATTEMPT",
                    resource=clean_name,
                    ip_address=client_ip,
                    details=json.dumps({
                        "tool_name": clean_name,
                        "parameters": {k: str(v)[:100] for k, v in parameters.items()},
                        "reason": "Attempted invocation of strictly prohibited hazardous tool.",
                    }),
                )
            raise ProhibitedToolError(
                f"Security Violation: Invocation of '{clean_name}' is strictly prohibited. "
                "The sandbox does not permit sequence modification, pathogen design, synthesis, "
                "virulence enhancement, or arbitrary shell execution."
            )

        # 2. Allowlist Enforcement
        if clean_name not in self._allowed_tools:
            if self.audit_logger:
                self.audit_logger.log(
                    user_id=user_id,
                    action="SECURITY_UNAUTHORIZED_TOOL_ATTEMPT",
                    resource=clean_name,
                    ip_address=client_ip,
                    details=json.dumps({"tool_name": clean_name}),
                )
            raise ToolNotFoundError(
                f"Tool '{clean_name}' is not recognized or not on the strict allowlist. "
                f"Available tools: {', '.join(self.allowed_tool_names)}."
            )

        # 3. Database Store Check
        if not self.db_store:
            raise ToolSecurityError("DatabaseStore is not configured on ToolRegistry.")

        # 4. Parameter Validation
        analysis_id = parameters.get("analysis_id")
        if not analysis_id or not isinstance(analysis_id, str):
            raise ToolParameterError("Missing required parameter 'analysis_id' (must be a non-empty string).")

        # 5. Tool Execution
        tool_func = self._allowed_tools[clean_name]
        try:
            result_data = tool_func(analysis_id=analysis_id, user_id=user_id, db_store=self.db_store)
            
            # Audit log success
            if self.audit_logger:
                self.audit_logger.log(
                    user_id=user_id,
                    action="AGENT_TOOL_EXECUTION",
                    resource=f"{clean_name}:{analysis_id}",
                    ip_address=client_ip,
                    details=json.dumps({
                        "tool_name": clean_name,
                        "analysis_id": analysis_id,
                        "status": "success",
                    }),
                )

            return ToolExecutionResult(
                success=True,
                tool_name=clean_name,
                data=result_data,
                error=None,
            )

        except ToolSecurityError:
            # Re-raise security errors (authorization, parameter, etc.)
            raise
        except Exception as exc:
            if self.audit_logger:
                self.audit_logger.log(
                    user_id=user_id,
                    action="AGENT_TOOL_ERROR",
                    resource=f"{clean_name}:{analysis_id}",
                    ip_address=client_ip,
                    details=json.dumps({"tool_name": clean_name, "error": str(exc)}),
                )
            return ToolExecutionResult(
                success=False,
                tool_name=clean_name,
                data=None,
                error=f"Internal tool execution error: {exc}",
            )
