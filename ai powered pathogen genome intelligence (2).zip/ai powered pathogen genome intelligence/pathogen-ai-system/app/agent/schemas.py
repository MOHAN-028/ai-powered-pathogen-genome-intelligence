"""
app/agent/schemas.py
====================
Pydantic schemas and data models for AI Agent Phases 1, 2, and 3.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, field_validator


class AgentIntent(str, Enum):
    GENERAL_INFORMATION = "GENERAL_INFORMATION"
    PIPELINE_CAPABILITIES = "PIPELINE_CAPABILITIES"
    BIOINFORMATICS_CONCEPT = "BIOINFORMATICS_CONCEPT"
    SAFETY_INQUIRY = "SAFETY_INQUIRY"
    SYSTEM_GUIDANCE = "SYSTEM_GUIDANCE"
    ANALYSIS_INTERPRETATION = "ANALYSIS_INTERPRETATION"
    SOLUTION_BUILDING = "SOLUTION_BUILDING"
    NOVELTY_ASSESSMENT = "NOVELTY_ASSESSMENT"
    VACCINE_TARGET_DISCOVERY = "VACCINE_TARGET_DISCOVERY"
    PATHOGEN_CHARACTERISTICS = "PATHOGEN_CHARACTERISTICS"
    UNSAFE_REQUEST = "UNSAFE_REQUEST"
    OUT_OF_SCOPE = "OUT_OF_SCOPE"


class SafetyStatus(str, Enum):
    ALLOWED = "allowed"
    REFUSED = "refused"
    FLAGGED = "flagged"


class AgentAskRequest(BaseModel):
    """Request payload for POST /agent/ask."""
    question: str = Field(..., min_length=1, max_length=2000, description="User question or inquiry")
    analysis_id: Optional[str] = Field(None, description="Optional Analysis ID to ground responses in specific analysis report")

    @field_validator("question")
    @classmethod
    def validate_non_empty_question(cls, v: str) -> str:
        stripped = v.strip()
        if not stripped:
            raise ValueError("Question cannot be empty or solely whitespace.")
        return stripped


class SafetyCheckResult(BaseModel):
    """Result of evaluating a query against biosecurity and injection guardrails."""
    is_safe: bool
    safety_status: SafetyStatus
    reason: Optional[str] = None
    matched_hazard: Optional[str] = None
    safe_alternatives: List[str] = Field(default_factory=list)


class IntentResult(BaseModel):
    """Result of intent classification."""
    intent: AgentIntent
    confidence: float = Field(..., ge=0.0, le=1.0)
    matched_keywords: List[str] = Field(default_factory=list)


class AgentAskResponse(BaseModel):
    """Structured response from POST /agent/ask with evidence grounding."""
    answer: str = Field(..., description="Agent response or refusal message")
    intent: AgentIntent = Field(..., description="Classified intent category")
    safety_status: SafetyStatus = Field(..., description="Safety evaluation status ('allowed' | 'refused' | 'flagged')")
    analysis_id: Optional[str] = Field(default=None, description="Active analysis ID if query was grounded in a report")
    analysis_context: Optional[Dict[str, Any]] = Field(default=None, description="Structured analysis context extracted from report")
    sections: Optional[Dict[str, str]] = Field(default=None, description="Structured sections: Answer, Evidence, Interpretation, Uncertainty, Next Steps")
    evidence_grounding_verified: bool = Field(default=True, description="True if answer is verified against supplied context")
    safe_alternatives: Optional[List[str]] = Field(
        default=None,
        description="Defensive research alternatives when a request is refused or out-of-scope"
    )
    confidence: float = Field(default=1.0, ge=0.0, le=1.0, description="Response confidence score")
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
