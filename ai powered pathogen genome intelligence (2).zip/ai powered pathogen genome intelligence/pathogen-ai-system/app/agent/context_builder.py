"""
app/agent/context_builder.py
============================
Structured Analysis Context Builder for Phase 2 Genome Analysis Integration.
Extracts grounded, factual metrics from GenomeIntelligenceReport without inventing values.
"""

from __future__ import annotations

from typing import Any, Dict, Optional
from app.models.schemas import GenomeIntelligenceReport


class AnalysisContextBuilder:
    """Extracts and structures verified analysis evidence into standard context for the AI Agent."""

    @staticmethod
    def build_context(report: GenomeIntelligenceReport) -> Dict[str, Any]:
        """Convert GenomeIntelligenceReport into a structured context dictionary.

        Follows strict fidelity rules:
        - Never invents missing values.
        - Preserves exact scores, labels, and evidence citations.
        """
        top_hit_data: Optional[Dict[str, Any]] = None
        if report.similarity.top_hit:
            top_hit = report.similarity.top_hit
            top_hit_data = {
                "reference_id": top_hit.reference_id,
                "taxon_name": top_hit.taxon_name,
                "similarity_score": round(top_hit.similarity_score, 4),
                "alignment_length": top_hit.alignment_length,
                "identity_percentage": round(top_hit.identity_percentage, 2),
                "coverage_percentage": round(top_hit.coverage_percentage, 2),
                "confidence": round(top_hit.confidence, 4),
                "notes": top_hit.notes,
            }

        return {
          "analysis_id": report.analysis_id,
          "sample_id": report.sample_id,
          "quality_control": {
              "quality_passed": report.sequence_statistics.quality_passed,
              "num_records": report.sequence_statistics.num_records,
              "total_length": report.sequence_statistics.total_length,
              "gc_content": round(report.sequence_statistics.gc_content, 4),
              "ambiguous_bases": report.sequence_statistics.ambiguous_bases,
              "ambiguous_percentage": round(report.sequence_statistics.ambiguous_percentage, 2),
              "duplicate_records_count": report.sequence_statistics.duplicate_records_count,
              "base_composition": {
                  "A": report.sequence_statistics.base_composition.A,
                  "T": report.sequence_statistics.base_composition.T,
                  "G": report.sequence_statistics.base_composition.G,
                  "C": report.sequence_statistics.base_composition.C,
                  "N": report.sequence_statistics.base_composition.N,
                  "other": report.sequence_statistics.base_composition.other,
              },
              "warnings": report.sequence_statistics.warnings,
          },
          "similarity": {
              "database_version": report.similarity.database_version,
              "database_status": report.similarity.database_status,
              "max_similarity": round(report.similarity.max_similarity, 4),
              "top_hit": top_hit_data,
              "num_hits": len(report.similarity.all_hits),
          },
          "novelty": {
              "status": report.novelty.status,
              "novelty_score": round(report.novelty.novelty_score, 4),
              "rationale": report.novelty.rationale,
              "distinction_notice": report.novelty.distinction_notice,
          },
          "classification": {
              "classification": report.classification.classification,
              "confidence": round(report.classification.confidence, 4),
              "evidence": report.classification.evidence,
              "database_version": report.classification.database_version,
          },
          "confidence": {
              "score": round(report.risk_and_uncertainty.confidence, 4),
              "summary": report.ai_explanation.confidence_summary,
          },
          "uncertainty": {
              "score": round(report.risk_and_uncertainty.uncertainty, 4),
              "limitations": report.risk_and_uncertainty.limitations,
              "evidence_sources": report.risk_and_uncertainty.evidence_sources,
              "reason_for_alert": report.risk_and_uncertainty.reason_for_alert,
              "medical_disclaimer": report.risk_and_uncertainty.medical_disclaimer,
          },
          "ai_explanation": {
              "finding": report.ai_explanation.finding,
              "interpretation": report.ai_explanation.interpretation,
              "recommended_next_step": report.ai_explanation.recommended_next_step,
          },
          "warnings": report.warnings,
        }
