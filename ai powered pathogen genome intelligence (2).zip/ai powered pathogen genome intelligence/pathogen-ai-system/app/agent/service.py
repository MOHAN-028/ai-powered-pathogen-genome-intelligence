"""
app/agent/service.py
====================
Main Agent Service coordinating the safety lifecycle, intent classification,
analysis report context extraction, authorization enforcement, and evidence-grounded response validation.
"""

from __future__ import annotations

import json
from typing import Optional
from fastapi import HTTPException
from app.agent.context_builder import AnalysisContextBuilder
from app.agent.intent import IntentClassifier
from app.agent.llm_provider import LLMProvider, get_llm_provider
from app.agent.prompt_defense import PromptDefense
from app.agent.safety import SafetyRouter
from app.agent.schemas import AgentAskRequest, AgentAskResponse, AgentIntent, SafetyStatus
from app.agent.tools import ToolExecutionResult, ToolRegistry
from app.agent.validator import ResponseValidator
from app.db.database import DatabaseStore
from app.models.schemas import GenomeIntelligenceReport
from app.security.audit import AuditLogger


class AgentService:
    """Core AI Agent orchestrator for the Pathogen Genome Intelligence Sandbox."""

    def __init__(
        self,
        safety_router: Optional[SafetyRouter] = None,
        intent_classifier: Optional[IntentClassifier] = None,
        llm_provider: Optional[LLMProvider] = None,
        response_validator: Optional[ResponseValidator] = None,
        audit_logger: Optional[AuditLogger] = None,
        db_store: Optional[DatabaseStore] = None,
        tool_registry: Optional[ToolRegistry] = None,
    ) -> None:
        self.safety_router = safety_router or SafetyRouter()
        self.intent_classifier = intent_classifier or IntentClassifier()
        self.llm_provider = llm_provider or get_llm_provider()
        self.response_validator = response_validator or ResponseValidator()
        self.audit_logger = audit_logger
        self.db_store = db_store
        self.tool_registry = tool_registry or ToolRegistry(db_store=db_store, audit_logger=audit_logger)

    def execute_tool(
        self,
        tool_name: str,
        parameters: Dict[str, Any],
        user_id: str = "anonymous",
        client_ip: str = "127.0.0.1",
    ) -> ToolExecutionResult:
        """Execute a tool via the strict ToolRegistry with authorization and audit logging."""
        return self.tool_registry.execute(
            tool_name=tool_name,
            parameters=parameters,
            user_id=user_id,
            client_ip=client_ip,
        )

    def ask(
        self,
        request: AgentAskRequest,
        user_id: str = "anonymous",
        client_ip: str = "127.0.0.1",
    ) -> AgentAskResponse:
        """Process user question through the complete Agent execution lifecycle.

        Lifecycle:
        1. Safety Evaluation (SafetyRouter) -> refuse if dual-use hazard / prompt injection
        2. Analysis Resolution & Authorization (if analysis_id is provided)
        3. Intent Classification (IntentClassifier)
        4. Response Generation (LLMProvider / SolutionBuilder with Analysis Context)
        5. Response Validation (ResponseValidator with grounding & anti-hallucination check)
        6. Audit Logging (AuditLogger)
        7. Return Structured AgentAskResponse with structured sections
        """
        question = request.question.strip()
        analysis_id = request.analysis_id.strip() if request.analysis_id else None

        # ── Step 1: Safety Evaluation ──
        safety_res = self.safety_router.evaluate(question)

        if not safety_res.is_safe:
            # Unsafe or prompt injection request -> build policy refusal
            intent = AgentIntent.UNSAFE_REQUEST
            answer = self.safety_router.build_refusal_response(safety_res)
            status = safety_res.safety_status

            # Validate refusal text
            validated_answer, final_status, sections, _ = self.response_validator.validate(
                answer, intent, status, analysis_context=None
            )

            # Audit log refusal
            if self.audit_logger:
                self.audit_logger.log(
                    user_id=user_id,
                    action="AI_AGENT_REFUSAL",
                    resource=analysis_id or "agent_ask",
                    ip_address=client_ip,
                    details=json.dumps({
                        "question": question[:200],
                        "analysis_id": analysis_id,
                        "matched_hazard": safety_res.matched_hazard,
                        "intent": intent.value,
                        "safety_status": final_status.value,
                    }),
                )

            return AgentAskResponse(
                answer=validated_answer,
                intent=intent,
                safety_status=final_status,
                analysis_id=analysis_id,
                analysis_context=None,
                sections=sections,
                evidence_grounding_verified=True,
                safe_alternatives=safety_res.safe_alternatives,
                confidence=1.0,
            )

        # ── Step 2: Analysis Resolution & Authorization ──
        analysis_context = None
        if analysis_id:
            if not self.db_store:
                raise HTTPException(status_code=500, detail="Database store is not configured on AgentService.")

            db_result = self.db_store.get_analysis_result(analysis_id)
            if not db_result:
                raise HTTPException(status_code=404, detail=f"Analysis ID '{analysis_id}' not found.")

            # Enforce multi-user authorization
            if not self.db_store.is_user_authorized_for_analysis(user_id=user_id, analysis_id=analysis_id):
                if self.audit_logger:
                    self.audit_logger.log(
                        user_id=user_id,
                        action="UNAUTHORIZED_ANALYSIS_ACCESS_ATTEMPT",
                        resource=analysis_id,
                        ip_address=client_ip,
                        details=json.dumps({
                            "question": question[:200],
                            "attempted_analysis_id": analysis_id,
                        }),
                    )
                raise HTTPException(
                    status_code=403,
                    detail=f"Access denied: You are not authorized to view analysis report '{analysis_id}'.",
                )

            # Deserialize report and build structured context
            try:
                report_data = json.loads(db_result.report_json)
                report = GenomeIntelligenceReport(**report_data)
                analysis_context = AnalysisContextBuilder.build_context(report)
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Failed to parse analysis report: {exc}")

        # ── Step 3: Intent Classification ──
        intent_res = self.intent_classifier.classify(question, is_safe=True)
        if analysis_context is not None and intent_res.intent not in (
            AgentIntent.SOLUTION_BUILDING, AgentIntent.SAFETY_INQUIRY
        ):
            intent = AgentIntent.ANALYSIS_INTERPRETATION
            confidence = 0.95
        else:
            intent = intent_res.intent
            confidence = intent_res.confidence

        # ── Step 4: Response Generation with Sandboxed Untrusted Context ──
        sandboxed_context = PromptDefense.sandbox_analysis_context(analysis_context)
        raw_answer = self.llm_provider.generate(
            prompt=question,
            intent=intent,
            analysis_context=sandboxed_context,
        )

        # ── Step 5: Response Validation & Anti-Hallucination Grounding ──
        validated_answer, final_status, sections, grounding_verified = self.response_validator.validate(
            raw_answer, intent, SafetyStatus.ALLOWED, analysis_context=analysis_context
        )

        # ── Step 6: Audit Logging ──
        if self.audit_logger:
            self.audit_logger.log(
                user_id=user_id,
                action="AI_AGENT_ANALYSIS_QUERY" if analysis_id else "AI_AGENT_QUERY",
                resource=analysis_id or "agent_ask",
                ip_address=client_ip,
                details=json.dumps({
                    "question": question[:200],
                    "analysis_id": analysis_id,
                    "intent": intent.value,
                    "confidence": confidence,
                    "safety_status": final_status.value,
                    "grounding_verified": grounding_verified,
                }),
            )

        # ── Step 7: Return Response ──
        return AgentAskResponse(
            answer=validated_answer,
            intent=intent,
            safety_status=final_status,
            analysis_id=analysis_id,
            analysis_context=analysis_context,
            sections=sections,
            evidence_grounding_verified=grounding_verified,
            safe_alternatives=None,
            confidence=confidence,
        )
