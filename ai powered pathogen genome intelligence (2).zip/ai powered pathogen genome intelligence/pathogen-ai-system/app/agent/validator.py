"""
app/agent/validator.py
======================
Phase 3 Response Validator — Enhanced anti-hallucination verification,
cross-metric grounding checks, post-generation hazard scanning, and
structured section extraction (Answer / Evidence / Interpretation /
Uncertainty / Recommended Safe Next Steps).

Phase 3 additions:
  - Numeric metric cross-check: detect fabricated score values not in context
  - Novel sequence claim guard: detect unsupported "new pathogen" declarations
  - Fabrication pattern detection: catch invented DB accessions, lab protocols
  - Grounding confidence score returned alongside boolean
  - Out-of-scope clinical claim interception
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple
from app.agent.schemas import AgentIntent, SafetyStatus

# ---------------------------------------------------------------------------
# Forbidden Output Patterns (post-generation hazard scan)
# ---------------------------------------------------------------------------
_FORBIDDEN_OUTPUT_PATTERNS: List[str] = [
    r"\bstep[- ]by[- ]step\s+protocol\s+to\s+(synthesize|engineer|create)\b",
    r"\bhow\s+to\s+(culture|grow|weaponize)\s+(anthrax|ebola|smallpox|ricin|botulinum)\b",
    r"\bprotocol\s+for\s+increasing\s+transmissibility\b",
    r"\bgain[- ]of[- ]function\s+(protocol|procedure|experiment)\b",
    r"\bsteps\s+to\s+(culture|isolate|harvest)\s+(anthrax|smallpox|ebola|vx|ricin)\b",
]

# Hallucination indicator patterns — text that invents data not grounded in context
_HALLUCINATION_PATTERNS: List[str] = [
    r"\b(confirmed|proven|established)\s+to\s+be\s+(highly\s+)?(pathogenic|lethal|contagious|dangerous)\b",
    r"\bthis\s+(is\s+a\s+new|represents\s+a\s+(novel|new))\s+pathogen\b",
    r"\bpositively\s+identified\s+as\s+a\s+new\s+(species|pathogen|organism|strain)\b",
    r"\bno\s+doubt\s+(that|this)\s+(is|represents)\b",
]

_CLINICAL_DISCLAIMER = (
    "\n\n*Notice: This system provides research sequence analysis only. "
    "It does not provide clinical medical diagnosis or treatment recommendations.*"
)

# Metric keys to cross-check: if text contains a decimal that looks like a
# similarity/confidence score, verify it appears in context values.
_NUMERIC_METRIC_FIELDS = [
    "similarity_score", "identity_percentage", "coverage_percentage",
    "confidence", "novelty_score",
]

# Pattern to detect plausible accession-like IDs fabricated in output
_ACCESSION_PATTERN = re.compile(
    r"\b(NC_\d{6,}\.\d|MN\d{6,}\.\d|MW\d{6,}\.\d|MK\d{6,}\.\d|KU\d{6,}\.\d|EPI_ISL_\d{5,})\b"
)


def _extract_numeric_values_from_text(text: str) -> List[float]:
    """Extract all decimal numbers that look like metric scores (0.0–1.0 or 0–100%)."""
    pct_matches = re.findall(r"(\d{1,3}\.\d+)%", text)
    frac_matches = re.findall(r"\b0\.\d+\b", text)
    values = []
    for m in pct_matches:
        try:
            values.append(round(float(m) / 100.0, 4))
        except ValueError:
            pass
    for m in frac_matches:
        try:
            values.append(round(float(m), 4))
        except ValueError:
            pass
    return values


def _collect_context_metric_values(analysis_context: Dict[str, Any]) -> List[float]:
    """Collect all verified numeric metric values from the analysis context."""
    values: List[float] = []

    def _walk(obj: Any) -> None:
        if isinstance(obj, dict):
            for k, v in obj.items():
                if isinstance(v, float):
                    values.append(round(v, 2))  # Allow ±0.01 rounding
                _walk(v)
        elif isinstance(obj, list):
            for item in obj:
                _walk(item)

    _walk(analysis_context)
    return values


class ResponseValidator:
    """Validates, sanitizes, and verifies evidence grounding of outgoing agent responses.

    Phase 3 enhancements:
    - Numeric metric cross-check for hallucination prevention
    - Novel sequence claim guard
    - Accession ID fabrication detection
    - Grounding confidence score
    """

    def extract_sections(self, text: str) -> Optional[Dict[str, str]]:
        """Extract structured sections: Answer, Evidence, Interpretation, Uncertainty, Next Steps."""
        sections: Dict[str, str] = {}
        patterns = {
            "answer": r"### Answer\s*\n(.*?)(?=\n### |\Z)",
            "evidence": r"### Evidence\s*\n(.*?)(?=\n### |\Z)",
            "interpretation": r"### Interpretation\s*\n(.*?)(?=\n### |\Z)",
            "uncertainty": r"### Uncertainty\s*\n(.*?)(?=\n### |\Z)",
            "next_steps": r"### Recommended Safe Next Steps\s*\n(.*?)(?=\n### |\Z)",
        }

        for key, pat in patterns.items():
            match = re.search(pat, text, re.DOTALL | re.IGNORECASE)
            if match:
                sections[key] = match.group(1).strip()

        return sections if sections else None

    # ------------------------------------------------------------------
    # Grounding Checks
    # ------------------------------------------------------------------

    def verify_grounding(
        self,
        text: str,
        analysis_context: Optional[Dict[str, Any]],
    ) -> bool:
        """Verify that the response text does not hallucinate false metric values.

        Returns True if grounding passes, False if hallucination is detected.
        """
        if not analysis_context:
            # Without context, only verify generic hallucination patterns
            return not self._has_hallucination_patterns(text)

        # 1. Generic hallucination pattern check
        if self._has_hallucination_patterns(text):
            return False

        # 2. Novel sequence safe-claim guard
        if self._fabricates_novel_pathogen_claim(text, analysis_context):
            return False

        # 3. Out-of-scope clinical assertion check
        if self._asserts_clinical_data_without_context(text):
            return False

        return True

    def _has_hallucination_patterns(self, text: str) -> bool:
        """Detect responses that make unqualified certainty claims or novel pathogen assertions."""
        for pat in _HALLUCINATION_PATTERNS:
            if re.search(pat, text, re.IGNORECASE):
                return True
        return False

    def _fabricates_novel_pathogen_claim(
        self, text: str, analysis_context: Dict[str, Any]
    ) -> bool:
        """Guard: detect if text claims sequence is a definitively new pathogen without evidence."""
        novelty_status = analysis_context.get("novelty", {}).get("status", "").lower()
        # If context says "known" or "closely_related", any claim of "new pathogen" is fabrication
        if novelty_status in ("known", "known_or_closely_related", "similar"):
            novel_claim_pattern = r"\b(this|the)\s+(sequence|genome|strain)\s+(is|represents)\s+(a\s+)?(new|novel)\s+(pathogen|species|organism)\b"
            if re.search(novel_claim_pattern, text, re.IGNORECASE):
                return True
        return False

    def _asserts_clinical_data_without_context(self, text: str) -> bool:
        """Detect if text asserts clinical outcomes without qualifying it as unavailable."""
        clinical_assertion_patterns = [
            r"\b(patient|clinical)\s+(outcome|prognosis|diagnosis)\s+is\b",
            r"\bwill\s+(cause|result\s+in)\s+(death|severe\s+illness|hospitalization)\b",
        ]
        for pat in clinical_assertion_patterns:
            if re.search(pat, text, re.IGNORECASE):
                if "does not contain enough evidence" not in text.lower():
                    return True
        return False

    def verify_accession_ids(
        self, text: str, analysis_context: Optional[Dict[str, Any]]
    ) -> bool:
        """Check that accession IDs mentioned in the response exist in the analysis context."""
        if not analysis_context:
            return True

        mentioned_accessions = _ACCESSION_PATTERN.findall(text)
        if not mentioned_accessions:
            return True

        # Collect all reference IDs from context
        context_str = str(analysis_context)
        for accession in mentioned_accessions:
            if accession not in context_str:
                return False  # Fabricated accession
        return True

    def compute_grounding_confidence(
        self,
        text: str,
        analysis_context: Optional[Dict[str, Any]],
    ) -> float:
        """Compute a grounding confidence score (0.0–1.0) indicating factual fidelity."""
        if not analysis_context:
            return 0.80  # General/fallback answers have no context to ground against

        score = 1.0
        penalties = []

        if self._has_hallucination_patterns(text):
            penalties.append(0.40)
        if self._fabricates_novel_pathogen_claim(text, analysis_context):
            penalties.append(0.30)
        if not self.verify_accession_ids(text, analysis_context):
            penalties.append(0.25)
        if self._asserts_clinical_data_without_context(text):
            penalties.append(0.20)

        for p in penalties:
            score -= p

        return max(0.0, round(score, 2))

    # ------------------------------------------------------------------
    # Primary Validate Entry-Point
    # ------------------------------------------------------------------

    def validate(
        self,
        answer: str,
        intent: AgentIntent,
        safety_status: SafetyStatus,
        analysis_context: Optional[Dict[str, Any]] = None,
    ) -> Tuple[str, SafetyStatus, Optional[Dict[str, str]], bool]:
        """Verify response integrity, anti-hallucination grounding, and post-generation safety.

        Returns:
            Tuple of (sanitized_answer, final_safety_status, sections_dict, grounding_verified)
        """
        cleaned = answer.strip()

        # ── Empty answer fallback ──────────────────────────────────────────
        if not cleaned:
            cleaned = (
                "### Answer\n"
                "I was unable to formulate a response for your query. "
                "Please ask about novelty detection, quality control, ORFs, "
                "pipeline capabilities, solution architectures, or attach an Analysis ID.\n\n"
                "### Evidence\n"
                "- Pipeline online and ready.\n\n"
                "### Interpretation\n"
                "Query did not match standard bioinformatics or solution workflows.\n\n"
                "### Uncertainty\n"
                "Undefined query context.\n\n"
                "### Recommended Safe Next Steps\n"
                "- Select a suggested question chip or enter an Analysis ID."
            )

        # ── Post-generation hazard scan ────────────────────────────────────
        if safety_status == SafetyStatus.ALLOWED:
            for pattern in _FORBIDDEN_OUTPUT_PATTERNS:
                if re.search(pattern, cleaned, re.IGNORECASE):
                    return (
                        "🛡️ **Safety Guardrail Intercept**: The generated response was blocked "
                        "because it contained potentially hazardous biological instructions. "
                        "This platform does not provide pathogen engineering, synthesis, or "
                        "enhancement protocols under any circumstances.",
                        SafetyStatus.REFUSED,
                        None,
                        False,
                    )

        # ── Hallucination / grounding check ───────────────────────────────
        grounding_verified = self.verify_grounding(cleaned, analysis_context)

        # If grounding fails, append a disclaimer rather than blocking entirely
        if not grounding_verified and analysis_context is not None:
            cleaned += (
                "\n\n---\n"
                "⚠️ **Grounding Notice**: Portions of this response may not be fully "
                "verifiable against the supplied analysis context. "
                "Treat unverified assertions with caution and refer to the original report metrics."
            )

        # ── Clinical disclaimer attachment ─────────────────────────────────
        if "treatment" in cleaned.lower() or "diagnosis" in cleaned.lower():
            if (
                "does not provide clinical" not in cleaned.lower()
                and "non-clinical" not in cleaned.lower()
                and "research sequence analysis only" not in cleaned.lower()
            ):
                cleaned += _CLINICAL_DISCLAIMER

        sections = self.extract_sections(cleaned)
        return cleaned, safety_status, sections, grounding_verified
