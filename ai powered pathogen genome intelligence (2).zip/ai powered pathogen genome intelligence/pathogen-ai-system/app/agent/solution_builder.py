"""
app/agent/solution_builder.py
=============================
Phase 3 Computational Solution Builder — generates safe, production-grade
genomic intelligence architectures, context-aware problem definitions, and
novelty interpretation guides.

Phase 3 additions:
  - Context-aware solution generation (reads active analysis metrics)
  - Expanded implementation pillars: Testing, Explainability, Monitoring
  - generate_novel_sequence_interpretation() — structured differential diagnostics
  - generate_problem_definition() — precise problem statement from context
"""

from __future__ import annotations

from typing import Any, Dict, Optional


class SolutionBuilder:
    """Generates computational solution architectures and bioinformatics system designs."""

    # ------------------------------------------------------------------
    # Solution Architecture
    # ------------------------------------------------------------------

    @classmethod
    def generate_solution_architecture(
        cls, query: str, context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Generate a complete 10-stage computational architecture.

        If an analysis context is provided, the problem definition block is
        customised with actual sample metrics (confidence, novelty, QC).
        """
        problem_block = cls.generate_problem_definition(context) if context else (
            "**Objective:** Design a secure, transparent, end-to-end pathogen genome "
            "intelligence platform for public-health biosurveillance."
        )

        return (
            "🛠️ **Computational Solution Architecture: Pathogen Genome Intelligence Platform**\n\n"
            f"### 1. Problem Definition\n{problem_block}\n\n"
            "### 2. End-to-End Pipeline Architecture Flow\n"
            "```text\n"
            "┌─────────────────────────────────────────────────────────────────┐\n"
            "│ 1. Problem Definition (Public-Health Surveillance & Biosafety)  │\n"
            "└────────────────────────────────┬────────────────────────────────┘\n"
            "                                 ▼\n"
            "┌─────────────────────────────────────────────────────────────────┐\n"
            "│ 2. Secure Data Ingestion (FASTA / FASTQ / PDF / API / Auth/TLS) │\n"
            "└────────────────────────────────┬────────────────────────────────┘\n"
            "                                 ▼\n"
            "┌─────────────────────────────────────────────────────────────────┐\n"
            "│ 3. Quality Control (Read Length, GC%, Ambiguity 'N' Filtering)  │\n"
            "└────────────────────────────────┬────────────────────────────────┘\n"
            "                                 ▼\n"
            "┌─────────────────────────────────────────────────────────────────┐\n"
            "│ 4. Feature Extraction (k-mer Tokenization, Embedding Vectors)   │\n"
            "└────────────────────────────────┬────────────────────────────────┘\n"
            "                                 ▼\n"
            "┌─────────────────────────────────────────────────────────────────┐\n"
            "│ 5. Similarity Analysis (Global/Local Alignment & Ref Index)     │\n"
            "└────────────────────────────────┬────────────────────────────────┘\n"
            "                                 ▼\n"
            "┌─────────────────────────────────────────────────────────────────┐\n"
            "│ 6. Novelty Detection (Divergence Scoring vs Reference Catalog)  │\n"
            "└────────────────────────────────┬────────────────────────────────┘\n"
            "                                 ▼\n"
            "┌─────────────────────────────────────────────────────────────────┐\n"
            "│ 7. Classification (Taxonomic & Lineage Supervised ML Models)    │\n"
            "└────────────────────────────────┬────────────────────────────────┘\n"
            "                                 ▼\n"
            "┌─────────────────────────────────────────────────────────────────┐\n"
            "│ 8. Uncertainty Assessment (Confidence Margins & Limitations)    │\n"
            "└────────────────────────────────┬────────────────────────────────┘\n"
            "                                 ▼\n"
            "┌─────────────────────────────────────────────────────────────────┐\n"
            "│ 9. Expert Review (Human-in-the-Loop Sign-off & Governance)      │\n"
            "└────────────────────────────────┬────────────────────────────────┘\n"
            "                                 ▼\n"
            "┌─────────────────────────────────────────────────────────────────┐\n"
            "│ 10. Research / Public-Health Surveillance Report Generation     │\n"
            "└─────────────────────────────────────────────────────────────────┘\n"
            "```\n\n"
            + cls._implementation_pillars()
        )

    @classmethod
    def _implementation_pillars(cls) -> str:
        return (
            "### 3. Core Implementation Pillars\n\n"
            "#### A. Software Architecture & APIs\n"
            "- **REST & MCP Server:** FastAPI backend exposing OpenAPI-compliant endpoints "
            "(`/analyze`, `/jobs`, `/agent/ask`).\n"
            "- **Asynchronous Queue:** Celery/Redis or SQLite background worker pool for "
            "long sequence alignments.\n"
            "- **Data Serialization:** Pydantic schemas validating all inputs/outputs with "
            "strict typing.\n\n"
            "#### B. Storage & Vector Retrieval\n"
            "- **Relational Database:** SQLite (or PostgreSQL) storing analysis metadata, "
            "audit trails, and expert reviews.\n"
            "- **Reference Catalog:** Indexed reference genomes with k-mer frequency lookup "
            "and pairwise alignment caches.\n\n"
            "#### C. Machine Learning & Uncertainty Quantification\n"
            "- **Feature Engineering:** k-mer sliding window tokenization (k=6 to k=9) "
            "with TF-IDF vectorization.\n"
            "- **Supervised Classifiers:** Calibrated multinomial Naive Bayes / Random Forest "
            "with class probability outputs.\n"
            "- **Novelty Scoring:** Normalized distance to nearest reference neighborhood. "
            "Flags sequences exceeding divergence thresholds for deeper analysis.\n"
            "- **Uncertainty Calibration:** Platt scaling or isotonic regression to reflect "
            "true epistemic uncertainty.\n\n"
            "#### D. Security & Biosecurity Governance\n"
            "- **Defense-in-Depth:** Input payload sanitization, regex guardrails, prompt "
            "injection filters.\n"
            "- **Biosecurity Router:** Strict policy refusal on dual-use gain-of-function "
            "or synthesis design inquiries.\n"
            "- **Role-Based Access Control (RBAC):** Distinct roles (`researcher`, "
            "`expert_reviewer`, `admin`) with multi-user report isolation.\n"
            "- **Immutable Audit Trail:** Append-only logging with SHA-256 integrity hashing.\n\n"
            "#### E. Testing & Evaluation\n"
            "- **Unit Tests:** pytest suites for every pipeline stage, agent intent classifier, "
            "safety router, and LLM provider response validator.\n"
            "- **Integration Tests:** End-to-end `/analyze` + `/agent/ask` flow with real "
            "reference sequences (NC_045512.2, NC_001802.1).\n"
            "- **Hallucination Prevention Tests:** Assert agent never fabricates scores, "
            "accessions, or clinical outcomes absent from grounded context.\n"
            "- **Benchmark Suites:** Precision / Recall / F1 on curated pathogen sequence sets.\n\n"
            "#### F. Explainability & Transparency\n"
            "- **Structured Responses:** Every AI answer sectioned into Answer / Evidence / "
            "Interpretation / Uncertainty / Recommended Safe Next Steps.\n"
            "- **Evidence Citations:** All scores cite exact pipeline module and database version.\n"
            "- **Grounding Verification:** ResponseValidator cross-checks every output metric "
            "against the supply analysis context.\n\n"
            "#### G. Deployment, Monitoring & Observability\n"
            "- **Sandbox Containerization:** Stateless Docker worker containers with constrained "
            "compute/memory limits.\n"
            "- **Telemetry & Metrics:** Prometheus instrumentation for latency, throughput, "
            "error rates, and model drift.\n"
            "- **LLM Provider Abstraction:** Configurable backend (Deterministic / OpenAI / "
            "Gemini / Ollama) via `LLM_PROVIDER` environment variable with automatic "
            "deterministic fallback."
        )

    # ------------------------------------------------------------------
    # Problem Definition (context-aware)
    # ------------------------------------------------------------------

    @classmethod
    def generate_problem_definition(
        cls, context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Generate a precise problem definition statement.

        If analysis context is provided, the statement reflects actual findings.
        """
        if not context:
            return (
                "**Objective:** Design a secure, transparent, end-to-end pathogen genome "
                "intelligence platform for public-health biosurveillance.\n"
                "**Scope:** Computational analysis of submitted genomic sequences against "
                "curated reference catalogs to classify, quantify uncertainty, and flag "
                "divergent sequences for human expert review."
            )

        sample_id = context.get("sample_id", "Unknown")
        qc = context.get("quality_control", {})
        sim = context.get("similarity", {})
        nov = context.get("novelty", {})
        conf = context.get("confidence", {})
        clf = context.get("classification", {})

        top_hit = sim.get("top_hit") or {}
        top_name = top_hit.get("taxon_name", clf.get("classification", "Unknown"))
        identity = top_hit.get("identity_percentage", 0.0)
        conf_score = conf.get("score", 0.0)
        nov_status = nov.get("status", "unknown")
        qc_passed = qc.get("quality_passed", True)

        return (
            f"**Active Sample:** `{sample_id}`\n"
            f"**Problem Statement:**\n"
            f"Sample `{sample_id}` has been computationally analysed against the reference catalog. "
            f"The sequence is classified as **{top_name}** with {identity:.1f}% identity "
            f"and overall confidence of {conf_score * 100:.1f}%. "
            f"Novelty status is **{nov_status.upper()}**; QC: **{'PASSED' if qc_passed else 'FAILED'}**.\n"
            "**Solution Goal:** Design a computational pipeline or improvement strategy to "
            "resolve remaining uncertainty, improve classification confidence, and establish "
            "robust public-health surveillance for sequences with similar divergence profiles."
        )

    # ------------------------------------------------------------------
    # Novelty Guidance
    # ------------------------------------------------------------------

    @classmethod
    def generate_novelty_guidance(
        cls, context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Generate structured reasoning distinguishing database gaps from biological novelty."""
        if context and "novelty" in context:
            nov = context["novelty"]
            sim = context.get("similarity", {})
            qc = context.get("quality_control", {})
            status = nov.get("status", "unknown")
            score = nov.get("novelty_score", 0.0)
            top_hit = sim.get("top_hit") or {}
            top_identity = top_hit.get("identity_percentage", 0.0)
            qc_passed = qc.get("quality_passed", True)

            return (
                f"🔬 **Novel Sequence & Divergence Assessment**\n\n"
                f"- **Novelty Status:** `{status.upper()}`\n"
                f"- **Novelty Score:** `{score:.4f}`\n"
                f"- **Top Reference Identity:** `{top_identity:.1f}%`\n"
                f"- **Quality Control Status:** `{'PASSED' if qc_passed else 'WARNING / FAILED'}`\n\n"
                "### Diagnostic Decision Logic:\n"
                "When a sequence exhibits low similarity or high novelty score, evaluate "
                "the following hierarchical causes:\n\n"
                "1. **Quality Limitations / Fragment Artifacts:**\n"
                f"   - Total length ({qc.get('total_length', 'N/A')} bp) or high ambiguous "
                f"bases ('N' count: {qc.get('ambiguous_bases', 0)}) can prevent effective "
                "alignment.\n"
                "2. **Reference Database Gap:**\n"
                "   - The reference database may lack specific wild-type or regional isolate "
                "representatives for this lineage.\n"
                "3. **Evolutionary / Biological Divergence:**\n"
                "   - Genuine genetic variation, recombination, or hypervariable region shifts.\n"
                "4. **Biosecurity Distinction Safeguard:**\n"
                "   - A lack of a database match indicates **unmapped sequence data** — it does "
                "**NOT** confirm the creation or discovery of an engineered or harmful pathogen.\n\n"
                "**Recommended Safe Next Steps:**\n"
                "- Conduct long-read Sanger / PacBio re-sequencing.\n"
                "- Query comprehensive public repositories (NCBI GenBank / GISAID).\n"
                "- Submit to human-in-the-loop expert review for taxonomic consensus."
            )

        return (
            "🔬 **Interpreting Low-Similarity and Unmapped Genomic Sequences**\n\n"
            "### Differential Diagnostic Hierarchy:\n"
            "```text\n"
            "                [ No Strong Reference Match ]\n"
            "                              │\n"
            "       ┌──────────────────────┼──────────────────────┐\n"
            "       ▼                      ▼                      ▼\n"
            "  [ Poor QC / ]        [ Reference Gap ]     [ Biological ]\n"
            "  [ Fragment  ]        [ Unrepresented ]     [ Divergence ]\n"
            "       │                      │                      │\n"
            "       └──────────────────────┬──────────────────────┘\n"
            "                              ▼\n"
            "               [ Computational Deep Search ]\n"
            "                              ▼\n"
            "               [ Expert Review & Validation ]\n"
            "```\n\n"
            "### Critical Distinctions:\n"
            "1. **Poor Quality / Read Truncation:** Short reads (<100 bp) or excessive "
            "'N's fail alignment thresholds.\n"
            "2. **Database Incompleteness:** Millions of natural viral/bacterial genomes "
            "remain unsequenced.\n"
            "3. **Natural Genetic Drift:** Viral RNA-dependent RNA polymerases introduce "
            "frequent point mutations.\n"
            "4. **Safety Rule:** Never automatically infer that an unmapped sequence "
            "represents an engineered pathogen.\n\n"
            "**Recommended Safe Next Steps:**\n"
            "- Check base call quality scores (Phred Q >= 30).\n"
            "- Perform k-mer frequency analysis and phylogenetic neighbor-joining.\n"
            "- Engage an expert reviewer before public health escalation."
        )

    # ------------------------------------------------------------------
    # Novel Sequence Interpretation (Phase 3 new)
    # ------------------------------------------------------------------

    @classmethod
    def generate_novel_sequence_interpretation(
        cls, context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Generate a multi-hypothesis differential interpretation for low-similarity sequences.

        This method produces a structured reasoning framework covering:
        - Possible novelty
        - Database gap hypothesis
        - Poor quality hypothesis
        - Insufficient evidence hypothesis

        It never automatically claims a new pathogen.
        """
        if not context:
            return cls.generate_novelty_guidance(None)

        nov = context.get("novelty", {})
        sim = context.get("similarity", {})
        qc = context.get("quality_control", {})
        conf = context.get("confidence", {})
        sample_id = context.get("sample_id", "Unknown")

        score = nov.get("novelty_score", 0.0)
        status = nov.get("status", "unknown")
        top_hit = sim.get("top_hit") or {}
        identity = top_hit.get("identity_percentage", 0.0)
        total_len = qc.get("total_length", 0)
        ambig = qc.get("ambiguous_bases", 0)
        qc_passed = qc.get("quality_passed", True)
        conf_score = conf.get("score", 0.0)

        # Determine dominant hypothesis based on metrics
        hypotheses = []

        if not qc_passed or ambig > total_len * 0.05:
            hypotheses.append(
                "⚠️ **Hypothesis A — Poor Quality / Fragment Artifact (HIGH LIKELIHOOD)**\n"
                f"   - QC: {'PASSED' if qc_passed else '**FAILED**'}, "
                f"Ambiguous bases: {ambig} ({(ambig / max(total_len, 1) * 100):.2f}%)\n"
                "   - Short or ambiguous reads frequently produce spurious low-similarity results.\n"
                "   - **Action:** Improve read quality; re-sequence with higher coverage depth."
            )
        else:
            hypotheses.append(
                "✅ **Hypothesis A — Poor Quality / Fragment Artifact (LOW LIKELIHOOD)**\n"
                f"   - QC: PASSED, Ambiguous bases: {ambig} — sequence quality is adequate.\n"
                "   - Quality artifacts are unlikely to explain low similarity in this case."
            )

        if identity < 70.0:
            hypotheses.append(
                "⚠️ **Hypothesis B — Reference Database Gap (MODERATE-HIGH LIKELIHOOD)**\n"
                f"   - Top reference identity: {identity:.1f}% — well below 70% threshold.\n"
                "   - The reference database may lack representatives of this lineage.\n"
                "   - **Action:** Search NCBI GenBank, GISAID, EBI ENA with expanded queries."
            )
        elif identity < 90.0:
            hypotheses.append(
                "⚠️ **Hypothesis B — Reference Database Gap (MODERATE LIKELIHOOD)**\n"
                f"   - Top reference identity: {identity:.1f}% — partial match only.\n"
                "   - Regional isolates or rare variants may be underrepresented.\n"
                "   - **Action:** Run broader metagenomic search."
            )
        else:
            hypotheses.append(
                "✅ **Hypothesis B — Reference Database Gap (LOW LIKELIHOOD)**\n"
                f"   - Top reference identity: {identity:.1f}% — strong reference coverage exists."
            )

        if score > 0.5:
            hypotheses.append(
                f"⚠️ **Hypothesis C — Possible Biological Divergence (Score: {score:.4f})**\n"
                "   - High novelty score suggests substantial evolutionary divergence.\n"
                "   - Could reflect natural mutation accumulation, recombination, or clade shift.\n"
                "   - **Action:** Perform phylogenetic tree placement and ancestral reconstruction."
            )
        else:
            hypotheses.append(
                f"✅ **Hypothesis C — Possible Biological Divergence (Score: {score:.4f})**\n"
                "   - Novelty score is moderate-to-low; strong divergence is less likely."
            )

        if conf_score < 0.5:
            hypotheses.append(
                f"⚠️ **Hypothesis D — Insufficient Evidence (Confidence: {conf_score * 100:.1f}%)**\n"
                "   - Low overall confidence means classification is tentative.\n"
                "   - **Action:** Obtain additional sequencing depth and expert bioinformatician review."
            )

        hypotheses_text = "\n\n".join(hypotheses)

        safety_notice = (
            "\n\n🛡️ **Critical Biosecurity Notice:**\n"
            f"Sample `{sample_id}` has novelty status `{status.upper()}` and "
            f"identity of {identity:.1f}%. "
            "**This does NOT constitute confirmation that a new, engineered, or dangerous "
            "pathogen has been discovered.** "
            "Unmapped sequence data reflects a gap between the query and the current reference "
            "catalog — not a biological threat assessment. "
            "All novel or divergent findings MUST be routed through expert bioinformatician "
            "review and confirmatory wet-lab validation before any public health escalation."
        )

        return (
            f"## Novel Sequence Differential Interpretation — Sample `{sample_id}`\n\n"
            "### Multi-Hypothesis Diagnostic Framework:\n\n"
            f"{hypotheses_text}"
            f"{safety_notice}\n\n"
            "### Recommended Computational Workflow:\n"
            "```text\n"
            "No Strong Reference Match\n"
            "          │\n"
            "          ├─── Evaluate QC / Read Quality\n"
            "          │         └─── If FAILED → Re-sequence\n"
            "          │\n"
            "          ├─── Expand Database Search (GenBank, GISAID, ENA)\n"
            "          │         └─── If hits found → Update classification\n"
            "          │\n"
            "          ├─── Phylogenetic Placement (Neighbor-joining / ML tree)\n"
            "          │         └─── Determine clade membership\n"
            "          │\n"
            "          └─── Expert Review & Consensus Validation\n"
            "                    └─── Sign-off before escalation\n"
            "```"
        )

    # ------------------------------------------------------------------
    # Vaccine Target Discovery & Reverse Vaccinology Framework
    # ------------------------------------------------------------------

    @classmethod
    def generate_vaccine_target_discovery_guide(
        cls, context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Generate a structured in-silico reverse vaccinology and antigen discovery guide for scientists."""
        sample_id = "Global / General Template"
        lineage = "Unspecified Viral Lineage"
        identity = 0.0
        gc_pct = 0.0
        novelty_score = 0.0

        if context:
            sample_id = context.get("sample_id", "Unknown")
            pred = context.get("classification", {})
            lineage = pred.get("predicted_class") or pred.get("prediction", "Unknown Lineage")
            sim = context.get("similarity", {})
            identity = sim.get("identity_percent", 0.0)
            qc = context.get("quality_control", {})
            gc_pct = qc.get("gc_content", 0.0)
            nov = context.get("novelty", {})
            novelty_score = nov.get("novelty_score", 0.0)

        context_summary = (
            f"**Target Sample:** `{sample_id}` | **Predicted Lineage:** `{lineage}` | "
            f"**Identity:** `{identity:.1f}%` | **GC Content:** `{gc_pct:.1f}%` | **Novelty Score:** `{novelty_score:.4f}`\n\n"
            if context
            else "**Mode:** Generalized Computational Reverse Vaccinology Protocol\n\n"
        )

        return (
            "🧬 **In-Silico Vaccine Target Discovery & Reverse Vaccinology Framework**\n\n"
            "> ⚠️ **Non-Clinical Research Notice:** This framework provides computational in-silico bioinformatics "
            "workflows for candidate antigen and epitope identification. It does not provide wet-lab chemical synthesis "
            "recipes, formulation steps, or medical/clinical trial protocols.\n\n"
            f"### Active Sequence Context\n{context_summary}"
            "### 5-Stage Computational Reverse Vaccinology Pipeline\n\n"
            "```text\n"
            "┌────────────────────────────────────────────────────────────────────────┐\n"
            "│ 1. In-Silico Surface Proteome & ORF Mining                             │\n"
            "│    • Translate Open Reading Frames across all 6 reading frames         │\n"
            "│    • Filter for signal peptides (SignalP) & transmembrane helices (TMHMM)│\n"
            "└───────────────────────────────────┬────────────────────────────────────┘\n"
            "                                    ▼\n"
            "┌────────────────────────────────────────────────────────────────────────┐\n"
            "│ 2. Cladal Conservation & Sequence Diversity Profiling                  │\n"
            "│    • Perform multiple sequence alignment (Clustal Omega / MUSCLE)      │\n"
            "│    • Identify conserved invariant domains across diverse reference clades│\n"
            "└───────────────────────────────────┬────────────────────────────────────┘\n"
            "                                    ▼\n"
            "┌────────────────────────────────────────────────────────────────────────┐\n"
            "│ 3. In-Silico Epitope & Immunogenicity Prediction                       │\n"
            "│    • Predict MHC-I & MHC-II binding affinities (NetMHCpan / IEDB tools) │\n"
            "│    • Predict conformational & linear B-cell epitopes (BepiPred / DiscoTope)│\n"
            "└───────────────────────────────────┬────────────────────────────────────┘\n"
            "                                    ▼\n"
            "┌────────────────────────────────────────────────────────────────────────┐\n"
            "│ 4. Safety & Autoimmunity De-Risking Filter                             │\n"
            "│    • Screen candidate peptides via BLASTp against human proteome (GRCh38)│\n"
            "│    • Exclude cross-reactive self-mimic epitopes to avoid autoimmunity  │\n"
            "└───────────────────────────────────┬────────────────────────────────────┘\n"
            "                                    ▼\n"
            "┌────────────────────────────────────────────────────────────────────────┐\n"
            "│ 5. Structural 3D Modeling & Receptor-Binding Domain (RBD) Validation   │\n"
            "│    • Generate 3D structural models (AlphaFold / ESMFold)               │\n"
            "│    • Map solvent-accessible surface areas (SASA) & neutralizing sites  │\n"
            "└────────────────────────────────────────────────────────────────────────┘\n"
            "```\n\n"
            "### Detailed Scientist Research Workflow:\n\n"
            "1. **Antigen Selection Criteria:**\n"
            "   - Prioritize outer membrane/surface glycoproteins (e.g., Spike `S`, Hemagglutinin `HA`, Envelope `E`).\n"
            "   - Ensure target domains exhibit $>85\%$ sequence conservation across circulating variants.\n"
            "2. **Epitope Selection & HLA Population Coverage:**\n"
            "   - Select multi-epitope clusters covering common HLA supertypes (HLA-A*02:01, HLA-A*24:02, HLA-B*07:02, HLA-DRB1).\n"
            "   - Combine helper CD4+ T-cell epitopes with cytotoxic CD8+ T-cell epitopes and neutralizing B-cell patches.\n"
            "3. **In-Silico Structural Validation:**\n"
            "   - Validate that candidate epitopes are solvent-exposed in native trimeric conformations rather than buried in the core.\n"
            "   - Cross-reference with known neutralizing antibody structures in PDB.\n"
            "4. **Recommended Next Steps for Researchers:**\n"
            "   - Download candidate ORF nucleotide/amino-acid sequences from the Analysis Dashboard.\n"
            "   - Run local NetMHCpan / IEDB predictions on the identified surface glycoprotein ORFs.\n"
            "   - Review findings with an expert immunologist and structural biologist."
        )

    # ------------------------------------------------------------------
    # Pathogen Biological Characteristics & Scientist Guide
    # ------------------------------------------------------------------

    @classmethod
    def generate_pathogen_characteristics_guide(
        cls, context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Generate structured biological characteristics and genomic profile for scientists."""
        sample_id = "Global / General Reference"
        lineage = "Coronaviridae / Respiratory Viral Family"
        identity = 98.5
        gc_pct = 38.0
        novelty_score = 0.015
        conf_pct = 95.0

        if context:
            sample_id = context.get("sample_id", "Unknown")
            pred = context.get("classification", {})
            lineage = pred.get("predicted_class") or pred.get("prediction", lineage)
            conf_pct = (pred.get("confidence", 0.95)) * 100
            sim = context.get("similarity", {})
            identity = sim.get("identity_percent", identity)
            qc = context.get("quality_control", {})
            gc_pct = qc.get("gc_content", gc_pct)
            nov = context.get("novelty", {})
            novelty_score = nov.get("novelty_score", novelty_score)

        return (
            f"🔬 **Pathogen Genomic Characteristics & Scientist Research Guide: `{lineage}`**\n\n"
            f"### Sample Profile & Genomic Metrics\n"
            f"- **Sample Identifier:** `{sample_id}`\n"
            f"- **Predicted Taxonomic Lineage:** `{lineage}` (Confidence: `{conf_pct:.1f}%`)\n"
            f"- **Reference Alignment Identity:** `{identity:.1f}%`\n"
            f"- **Genomic GC Content:** `{gc_pct:.1f}%`\n"
            f"- **Novelty / Divergence Score:** `{novelty_score:.4f}`\n\n"
            "### Biological Characteristics & Virion Architecture\n\n"
            "| Feature | Biological Characteristic | Research Implication |\n"
            "| :--- | :--- | :--- |\n"
            "| **Genome Type** | Positive-sense single-stranded RNA (+ssRNA) | Immediate translation upon host entry; RNA-dependent RNA polymerase replication. |\n"
            "| **Genome Size** | ~26–32 kb (among largest RNA genomes) | Complex proofreading exonuclease (ExoN) maintaining genomic fidelity. |\n"
            "| **Primary Antigens** | Surface Spike Glycoprotein (`S`), Envelope (`E`), Membrane (`M`), Nucleocapsid (`N`) | `S` protein mediates cell attachment & membrane fusion; primary target for neutralizing antibodies. |\n"
            "| **Host Receptor** | Angiotensin-Converting Enzyme 2 (`ACE2`) / Sialic Acid / CD209 | Receptor-Binding Domain (`RBD`) engages host surface receptors to trigger endocytosis. |\n"
            "| **GC Composition** | ~38% GC-rich (typical viral range: 35–45%) | Stable secondary RNA structures in 5' and 3' untranslated regions (UTRs). |\n"
            "| **Mutation Profile** | Antigenic drift via point mutations in RBD & NTD | Requires continuous genomic biosurveillance to track immune evasion variants. |\n\n"
            "### Scientist Research & Biosurveillance Roadmap\n\n"
            "1. **Genomic Sequence Verification:**\n"
            "   - Verify read depth and ensure zero ambiguous `N` base clusters across coding domains.\n"
            "2. **ORF Annotation & Domain Mapping:**\n"
            "   - Utilize the ORF Detection tool to locate the full-length Spike glycoprotein gene.\n"
            "   - Map specific amino acid substitutions in the Receptor Binding Motif (RBM).\n"
            "3. **Phylogenetic & Cladal Tracking:**\n"
            "   - Construct maximum-likelihood phylogenetic trees to trace transmission clusters.\n"
            "   - Compare against global lineage repositories (GISAID, GenBank, Nextstrain).\n"
            "4. **Biosafety Governance:**\n"
            "   - Ensure all laboratory handling conforms to BSL-2 / BSL-3 biocontainment standards.\n"
            "   - Record all analytical findings in the immutable sandbox audit trail."
        )
