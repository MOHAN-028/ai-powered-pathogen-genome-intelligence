"""
app/agent/__init__.py
=====================
AI Agent package for Pathogen Genome Intelligence Sandbox — Phases 1, 2, 3 & 4.
"""

from app.agent.context_builder import AnalysisContextBuilder
from app.agent.intent import IntentClassifier
from app.agent.llm_provider import (
    DeterministicFallbackProvider,
    GeminiLLMProvider,
    LocalOllamaLLMProvider,
    LLMProvider,
    MockLLMProvider,
    OpenAILLMProvider,
    get_llm_provider,
)
from app.agent.prompt_defense import PromptDefense
from app.agent.safety import SafetyRouter
from app.agent.schemas import (
    AgentAskRequest,
    AgentAskResponse,
    AgentIntent,
    IntentResult,
    SafetyCheckResult,
    SafetyStatus,
)
from app.agent.service import AgentService
from app.agent.solution_builder import SolutionBuilder
from app.agent.tools import (
    ProhibitedToolError,
    ToolAuthorizationError,
    ToolDefinition,
    ToolExecutionResult,
    ToolNotFoundError,
    ToolParameterError,
    ToolRegistry,
    ToolSecurityError,
)
from app.agent.validator import ResponseValidator

__all__ = [
    "AgentAskRequest",
    "AgentAskResponse",
    "AgentIntent",
    "AgentService",
    "AnalysisContextBuilder",
    "DeterministicFallbackProvider",
    "GeminiLLMProvider",
    "IntentClassifier",
    "IntentResult",
    "LocalOllamaLLMProvider",
    "LLMProvider",
    "MockLLMProvider",
    "OpenAILLMProvider",
    "ProhibitedToolError",
    "PromptDefense",
    "ResponseValidator",
    "SafetyCheckResult",
    "SafetyRouter",
    "SafetyStatus",
    "SolutionBuilder",
    "ToolAuthorizationError",
    "ToolDefinition",
    "ToolExecutionResult",
    "ToolNotFoundError",
    "ToolParameterError",
    "ToolRegistry",
    "ToolSecurityError",
    "get_llm_provider",
]
