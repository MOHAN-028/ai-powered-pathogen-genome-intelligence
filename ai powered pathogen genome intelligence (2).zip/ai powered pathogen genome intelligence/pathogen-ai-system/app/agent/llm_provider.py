"""
app/agent/llm_provider.py
=========================
Phase 3: Configurable LLM Provider abstraction layer.

Providers (configurable via LLM_PROVIDER env var):
  - 'deterministic'  — Zero-hallucination rule-based engine (default / offline fallback)
  - 'openai'         — OpenAI / Azure OpenAI / any OpenAI-compatible REST API
  - 'gemini'         — Google Gemini API
  - 'ollama'         — Local LLM via Ollama REST API (http://localhost:11434)
  - 'mock'           — Controlled test double

All external providers:
  - Inject a strict grounding system prompt that prohibits fabrication
  - Auto-fallback to DeterministicFallbackProvider on API error or missing key
"""

from __future__ import annotations

import abc
import json
import os
import re
from typing import Any, Dict, Optional
from app.agent.schemas import AgentIntent
from app.agent.solution_builder import SolutionBuilder


# ── Shared grounding system prompt injected into all external LLM providers ──
_GROUNDING_SYSTEM_PROMPT = (
    "You are an AI Bioinformatician Assistant for the Pathogen Genome Intelligence Sandbox. "
    "Your responses MUST strictly adhere to the following rules:\n\n"
    "GROUNDING RULES (never violate):\n"
    "1. Never invent, fabricate, or estimate numeric scores (similarity, confidence, novelty, "
    "GC content, coverage, identity percentage, QC metrics) that are not explicitly provided "
    "in the supplied Analysis Context. If a value is missing, say so explicitly.\n"
    "2. Never claim that a sequence IS definitively a new, novel, or engineered pathogen. "
    "Use qualified language: 'possible divergence', 'database gap', 'requires expert review'.\n"
    "3. Never cite database accession IDs (e.g. NC_045512.2) that are not in the supplied context.\n"
    "4. Never provide pathogen engineering, synthesis, virulence/transmission enhancement, "
    "immune-evasion, or gain-of-function protocols under any circumstances.\n"
    "5. Never make clinical medical diagnoses, treatment recommendations, or patient prognoses.\n\n"
    "RESPONSE FORMAT (always use these exact section headers):\n"
    "### Answer\n"
    "[Direct answer grounded in evidence]\n\n"
    "### Evidence\n"
    "[Bullet list of exact values from analysis context]\n\n"
    "### Interpretation\n"
    "[What the evidence means — no invention]\n\n"
    "### Uncertainty\n"
    "[Epistemic limits, database bounds, caveats]\n\n"
    "### Recommended Safe Next Steps\n"
    "[Computational, expert review, or public-health actions only]\n\n"
    "Biosecurity enforcement: If any part of the user question requests prohibited content, "
    "respond only with a safety refusal following the refusal format."
)


class LLMProvider(abc.ABC):
    """Abstract interface for LLM response generation."""

    @abc.abstractmethod
    def generate(
        self,
        prompt: str,
        intent: AgentIntent,
        system_prompt: Optional[str] = None,
        analysis_context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Generate an agent answer given the user prompt, intent, and optional analysis context."""
        raise NotImplementedError


class DeterministicFallbackProvider(LLMProvider):
    """Deterministic, rule-based genomic intelligence and solution-building response engine.

    Guarantees zero-hallucination, evidence-grounded answers formatted into structured sections:
    - Answer
    - Evidence
    - Interpretation
    - Uncertainty
    - Recommended Safe Next Steps
    """

    def generate(
        self,
        prompt: str,
        intent: AgentIntent,
        system_prompt: Optional[str] = None,
        analysis_context: Optional[Dict[str, Any]] = None,
    ) -> str:
        q_lower = prompt.lower().strip()

        # ===================================================================
        # 1. Solution Building Intent
        # ===================================================================
        if intent == AgentIntent.SOLUTION_BUILDING or any(
            k in q_lower for k in ["solution", "architect", "pipeline architecture", "how can i create a solution", "build a platform"]
        ):
            sol_arch = SolutionBuilder.generate_solution_architecture(prompt, analysis_context)
            return (
                f"### Answer\n"
                f"{sol_arch}\n\n"
                f"### Evidence\n"
                f"- Architecture follows established bioinformatics engineering standards (NIST, GA4GH, CDC).\n"
                f"- Integration adheres to the 10-stage sandbox lifecycle (Ingestion → QC → Feature Extraction → Similarity → Novelty → Classification → Uncertainty → Review → Reporting).\n\n"
                f"### Interpretation\n"
                f"A production-grade pathogen genome intelligence platform requires defense-in-depth security, strict multi-user access controls, and auditable human-in-the-loop governance alongside computational sequence models.\n\n"
                f"### Uncertainty\n"
                f"- Model accuracy depends on reference database representativeness and sequence read quality.\n"
                f"- Computational predictions require independent laboratory confirmation and expert sign-off.\n\n"
                f"### Recommended Safe Next Steps\n"
                f"1. Implement containerized sandbox workers with compute resource limits.\n"
                f"2. Configure automated quality control filters (Phred Q >= 30, GC profiling, N-ambiguity bounds).\n"
                f"3. Establish human-in-the-loop expert review protocols for out-of-distribution sequence classifications."
            )

        # ===================================================================
        # 2. Novelty Assessment Intent (when not tied to specific report)
        # ===================================================================
        if intent == AgentIntent.NOVELTY_ASSESSMENT and analysis_context is None:
            novelty_text = SolutionBuilder.generate_novelty_guidance(None)
            return (
                f"### Answer\n"
                f"{novelty_text}\n\n"
                f"### Evidence\n"
                f"- Reference databases represent only a fraction of natural microbial biodiversity.\n"
                f"- Low alignment identity is frequently caused by technical artifacts (short reads, sequencing errors) or unsequenced wild strains rather than artificial manipulation.\n\n"
                f"### Interpretation\n"
                f"When a query exhibits low similarity against reference databases, it indicates unmapped genetic variation. It must never be automatically classified as an engineered or novel high-consequence pathogen without multi-evidence validation.\n\n"
                f"### Uncertainty\n"
                f"- Sequence divergence metrics reflect mathematical distance to reference genomes, not pathogenic phenotype.\n\n"
                f"### Recommended Safe Next Steps\n"
                f"1. Check sequence length and ambiguous base percentage.\n"
                f"2. Conduct expanded similarity searches across public archives (GenBank/GISAID).\n"
                f"3. Route uncharacterized sequences to expert bioinformatician review."
            )

        # ===================================================================
        # 3. Grounded Analysis Report Interpretation (analysis_context is present)
        # ===================================================================
        if analysis_context is not None:
            sample_id = analysis_context.get("sample_id", "Unknown")
            analysis_id = analysis_context.get("analysis_id", "Unknown")
            qc = analysis_context.get("quality_control", {})
            sim = analysis_context.get("similarity", {})
            nov = analysis_context.get("novelty", {})
            clf = analysis_context.get("classification", {})
            conf = analysis_context.get("confidence", {})
            unc = analysis_context.get("uncertainty", {})
            ai_exp = analysis_context.get("ai_explanation", {})
            warnings = analysis_context.get("warnings", [])

            # Check for queries about unavailable/out-of-scope report metrics
            unavailable_keywords = [
                "patient", "clinical outcome", "drug resistance", "treatment protocol",
                "hospital", "prescription", "dosage", "therapeutic", "cure", "prognosis"
            ]
            if any(uk in q_lower for uk in unavailable_keywords):
                return (
                    f"### Answer\n"
                    f"The available analysis does not contain enough evidence to determine this.\n\n"
                    f"### Evidence\n"
                    f"- Report `{analysis_id}` contains computational sequence intelligence metrics only (QC, similarity, novelty, classification, uncertainty).\n"
                    f"- No clinical records, patient outcomes, or pharmacological assay data are present in the analysis context.\n\n"
                    f"### Interpretation\n"
                    f"The platform provides research-grade genomic analysis only and does not store or process clinical medical data.\n\n"
                    f"### Uncertainty\n"
                    f"100% (clinical data is outside the platform's analytical scope).\n\n"
                    f"### Recommended Safe Next Steps\n"
                    f"- Consult qualified medical professionals or accredited clinical diagnostic laboratories for patient health assessments."
                )

            # ── 3A. Topic: Quality Control ──
            if "qc" in q_lower or "quality" in q_lower or "base composition" in q_lower or "ambiguous" in q_lower:
                passed_str = "PASSED" if qc.get("quality_passed") else "WARNING/FAILED"
                bc = qc.get("base_composition", {})
                bc_str = f"A: {bc.get('A', 0)}, T: {bc.get('T', 0)}, G: {bc.get('G', 0)}, C: {bc.get('C', 0)}, N: {bc.get('N', 0)}"
                qc_warnings = qc.get("warnings", [])
                
                return (
                    f"### Answer\n"
                    f"The Quality Control (QC) status for sample `{sample_id}` is **{passed_str}**.\n\n"
                    f"### Evidence\n"
                    f"- **Sequence Length:** {qc.get('total_length', 0):,} bp across {qc.get('num_records', 1)} record(s)\n"
                    f"- **GC Content:** {qc.get('gc_content', 0.0) * 100:.1f}%\n"
                    f"- **Ambiguous Bases:** {qc.get('ambiguous_bases', 0)} ({qc.get('ambiguous_percentage', 0.0):.2f}%)\n"
                    f"- **Base Composition:** {bc_str}\n"
                    f"- **Duplicate Records:** {qc.get('duplicate_records_count', 0)}\n\n"
                    f"### Interpretation\n"
                    f"The input sequence {'passed all quality thresholds without critical ambiguity' if qc.get('quality_passed') else 'triggered quality alerts'}. "
                    f"{'Quality warnings: ' + '; '.join(qc_warnings) if qc_warnings else 'No sequence quality defects were identified.'}\n\n"
                    f"### Uncertainty\n"
                    f"QC metrics reflect the raw submitted text. Sequencing artifacts or unverified sequencing depths may affect downstream confidence.\n\n"
                    f"### Recommended Safe Next Steps\n"
                    f"- Proceed with downstream phylogenetic placement and reference alignment comparison."
                )

            # ── 3B. Topic: Confidence & Uncertainty ──
            if "confidence" in q_lower or "uncertainty" in q_lower or "why is confidence" in q_lower:
                conf_score = conf.get("score", 0.0)
                unc_score = unc.get("score", 0.0)
                lims = unc.get("limitations", [])
                evs = unc.get("evidence_sources", [])
                
                return (
                    f"### Answer\n"
                    f"**Confidence & Uncertainty:** Sample `{sample_id}` has a **Confidence Score of {conf_score * 100:.1f}%** and an **Uncertainty Score of {unc_score * 100:.1f}%**.\n\n"
                    f"### Evidence\n"
                    f"- **Confidence Summary:** {conf.get('summary', 'Derived from alignment identity and k-mer distribution.')}\n"
                    f"- **Evidence Sources:** {'; '.join(evs) if evs else 'Reference alignment and ML classifier'}\n"
                    f"- **Identified Limitations:** {'; '.join(lims) if lims else 'Standard reference database scope limitations'}\n\n"
                    f"### Interpretation\n"
                    f"The confidence score is established through global sequence alignment depth and reference catalog homology. "
                    f"{'High alignment identity against reference records supports high classification certainty.' if conf_score >= 0.8 else 'Lower confidence reflects sequence divergence or limited matching reference records.'}\n\n"
                    f"### Uncertainty\n"
                    f"Uncertainty ({unc_score * 100:.1f}%) is bounded by reference database completeness and query length.\n\n"
                    f"### Recommended Safe Next Steps\n"
                    f"- Review documented limitations and cross-reference with secondary reference datasets."
                )

            # ── 3C. Topic: Similarity ──
            if "similarity" in q_lower or "reference" in q_lower or "match" in q_lower or "hit" in q_lower:
                top_hit = sim.get("top_hit")
                if top_hit:
                    ref_id = top_hit.get("reference_id", "N/A")
                    taxon = top_hit.get("taxon_name", "Unknown Taxon")
                    ident = top_hit.get("identity_percentage", 0.0)
                    cov = top_hit.get("coverage_percentage", 0.0)
                    score = top_hit.get("similarity_score", 0.0)
                    
                    return (
                        f"### Answer\n"
                        f"The query sequence aligns most closely with **{taxon}** (Reference ID: `{ref_id}`).\n\n"
                        f"### Evidence\n"
                        f"- **Reference Accession:** `{ref_id}` ({taxon})\n"
                        f"- **Identity Percentage:** {ident:.1f}%\n"
                        f"- **Query Coverage:** {cov:.1f}%\n"
                        f"- **Normalized Similarity Score:** {score:.4f}\n"
                        f"- **Database Version:** `{sim.get('database_version', 'v1.0')}` (Status: {sim.get('database_status', 'active')})\n\n"
                        f"### Interpretation\n"
                        f"The {ident:.1f}% sequence identity across {cov:.1f}% query coverage indicates "
                        f"{'strong evolutionary homology with known reference genomes' if ident >= 90.0 else 'moderate to distant sequence divergence from catalogued references'}.\n\n"
                        f"### Uncertainty\n"
                        f"Alignment scores reflect pairwise homology to available reference databases and do not capture unsequenced genomic lineages.\n\n"
                        f"### Recommended Safe Next Steps\n"
                        f"- Verify alignment breakpoints and perform multiple sequence alignment with close evolutionary relatives."
                    )
                else:
                    return (
                        f"### Answer\n"
                        f"No significant reference similarity matches were detected for sample `{sample_id}`.\n\n"
                        f"### Evidence\n"
                        f"- Reference database `{sim.get('database_version', 'v1.0')}` yielded 0 significant hits.\n\n"
                        f"### Interpretation\n"
                        f"Lack of a match indicates unmapped sequence data due to database incompleteness or novel genomic divergence.\n\n"
                        f"### Uncertainty\n"
                        f"High uncertainty regarding taxonomic lineage without reference matches.\n\n"
                        f"### Recommended Safe Next Steps\n"
                        f"- Perform broader metagenomic classification and secondary database searches."
                    )

            # ── 3D. Topic: Novelty ──
            if "novelty" in q_lower or "novel" in q_lower or "divergence" in q_lower or "new" in q_lower:
                # Phase 3: use full multi-hypothesis differential interpretation
                nov_interp = SolutionBuilder.generate_novel_sequence_interpretation(analysis_context)
                return (
                    f"### Answer\n"
                    f"{nov_interp}\n\n"
                    f"### Evidence\n"
                    f"- Novelty Status: `{nov.get('status', 'unknown').upper()}` (Score: {nov.get('novelty_score', 0.0):.4f})\n"
                    f"- Rationale: {nov.get('rationale', 'Assessed via nearest reference distance.')}\n\n"
                    f"### Interpretation\n"
                    f"The novelty assessment measures divergence from catalogued reference genomes. "
                    f"Distinction notice: {nov.get('distinction_notice', 'Unmapped sequence data does NOT confirm creation of a new pathogen.')}\n\n"
                    f"### Uncertainty\n"
                    f"Novelty scores quantify database distance, not biological virulence or transmissibility.\n\n"
                    f"### Recommended Safe Next Steps\n"
                    f"- Run broader phylogenetic scans and submit for expert bioinformatician review."
                )

            # ── 3E. Topic: Classification & Taxonomy ──
            if "classification" in q_lower or "taxonomy" in q_lower or "what is this" in q_lower or "species" in q_lower:
                pred_cls = clf.get("classification", "Unclassified")
                cls_conf = clf.get("confidence", 0.0)
                cls_ev = clf.get("evidence", [])
                
                return (
                    f"### Answer\n"
                    f"Sample `{sample_id}` is classified as **{pred_cls}** with **{cls_conf * 100:.1f}% confidence**.\n\n"
                    f"### Evidence\n"
                    f"- **Predicted Class:** {pred_cls}\n"
                    f"- **Confidence Score:** {cls_conf * 100:.1f}%\n"
                    f"- **Supporting Evidence:** {'; '.join(cls_ev) if cls_ev else 'k-mer frequency and reference alignment'}\n"
                    f"- **Model Version:** {clf.get('database_version', 'demo-v1.0')}\n\n"
                    f"### Interpretation\n"
                    f"Classification is supported by sequence feature extraction and supervised reference model scoring.\n\n"
                    f"### Uncertainty\n"
                    f"Classification margin is bounded by training set taxon distribution.\n\n"
                    f"### Recommended Safe Next Steps\n"
                    f"- Validate with secondary phylogenetic tree placement and confirm with expert review."
                )

            # ── 3F. Topic: Limitations & Disclaimers ──
            if "limitation" in q_lower or "disclaimer" in q_lower or "scope" in q_lower:
                lims = unc.get("limitations", [])
                disclaimer = unc.get("medical_disclaimer", "Research sequence analysis only. Not for clinical diagnosis.")
                
                return (
                    f"### Answer\n"
                    f"Key analytical limitations and regulatory disclaimers for sample `{sample_id}`:\n\n"
                    f"### Evidence\n"
                    f"- **Documented Limitations:** {'; '.join(lims) if lims else 'Standard reference database bounds'}\n"
                    f"- **Medical Disclaimer:** {disclaimer}\n\n"
                    f"### Interpretation\n"
                    f"All findings represent in-silico computational sequence intelligence. They do not constitute diagnostic medical evaluations or clinical prescriptions.\n\n"
                    f"### Uncertainty\n"
                    f"Analyses of fragmented reads or incomplete reference databases carry inherent uncertainty.\n\n"
                    f"### Recommended Safe Next Steps\n"
                    f"- Perform full-length whole genome sequencing (WGS) where higher certainty is required."
                )

            # ── 3G. General Report Overview ──
            top_hit = sim.get("top_hit") or {}
            top_name = top_hit.get("taxon_name", clf.get("classification", "Unknown"))
            
            return (
                f"### Answer\n"
                f"Analysis Overview for Sample `{sample_id}` (ID: `{analysis_id}`):\n"
                f"The sequence is classified as **{top_name}** with **{conf.get('score', 0.0) * 100:.1f}% confidence**.\n\n"
                f"### Evidence\n"
                f"- **QC Status:** `{'PASSED' if qc.get('quality_passed') else 'WARNING'}` ({qc.get('total_length', 0):,} bp, {qc.get('gc_content', 0.0) * 100:.1f}% GC)\n"
                f"- **Similarity:** {top_hit.get('identity_percentage', 0.0):.1f}% identity to `{top_hit.get('reference_id', 'N/A')}`\n"
                f"- **Novelty Status:** `{nov.get('status', 'unknown').upper()}` (Score: {nov.get('novelty_score', 0.0):.4f})\n\n"
                f"### Interpretation\n"
                f"{ai_exp.get('finding', 'Homology detected with known reference database.')} {ai_exp.get('interpretation', '')}\n\n"
                f"### Uncertainty\n"
                f"Confidence is {conf.get('score', 0.0) * 100:.1f}%. {ai_exp.get('confidence_summary', '')}\n\n"
                f"### Recommended Safe Next Steps\n"
                f"- {ai_exp.get('recommended_next_step', 'Perform phylogenetic tree placement and peer review.')}"
            )

        # ===================================================================
        # 4. General Bioinformatics, Pipeline & Safety Queries (Phase 1 Domain)
        # ===================================================================
        if intent == AgentIntent.BIOINFORMATICS_CONCEPT:
            if "orf" in q_lower or "reading frame" in q_lower:
                return (
                    "### Answer\n"
                    "An **Open Reading Frame (ORF)** is a continuous stretch of codons beginning with a start codon (typically `ATG`), "
                    "continuing through sense codons, and terminating at a stop codon (`TAA`, `TAG`, or `TGA`) in the same reading frame.\n\n"
                    "### Evidence\n"
                    "- Triplet genetic code across 6 reading frames (3 forward, 3 reverse-complement).\n"
                    "- Minimal peptide length threshold (typically >= 30 amino acids) distinguishes protein-coding potential from stochastic stops.\n\n"
                    "### Interpretation\n"
                    "ORFs highlight prospective protein-coding regions in unannotated pathogen genomes.\n\n"
                    "### Uncertainty\n"
                    "Not all ORFs represent expressed or functional proteins in vivo; transcriptomic confirmation is required.\n\n"
                    "### Recommended Safe Next Steps\n"
                    "- Submit candidate ORFs to homology search (BLASTp / InterPro) for functional domain annotation."
                )
            if "gc" in q_lower or "base composition" in q_lower:
                return (
                    "### Answer\n"
                    "**GC-Content** is the percentage of nitrogenous bases in a DNA or RNA sequence that are either Guanine (G) or Cytosine (C).\n\n"
                    "### Evidence\n"
                    "- Formula: `GC% = (G + C) / (A + T + G + C) * 100`.\n"
                    "- G-C pairs have 3 hydrogen bonds compared to 2 for A-T pairs, increasing thermodynamic stability.\n\n"
                    "### Interpretation\n"
                    "GC content variations across a genome often demarcate lineage signatures, horizontal gene transfer events, or pathogenicity islands.\n\n"
                    "### Uncertainty\n"
                    "GC percentage is a broad statistical indicator and does not replace single-nucleotide resolution taxonomy.\n\n"
                    "### Recommended Safe Next Steps\n"
                    "- Generate a sliding-window GC profile to identify localized compositional anomalies."
                )

        if intent == AgentIntent.PIPELINE_CAPABILITIES:
            return (
                "### Answer\n"
                "The **AI-Powered Pathogen Genome Intelligence Sandbox** provides an end-to-end computational pipeline for sequence analysis.\n\n"
                "### Evidence\n"
                "- **Supported Formats:** FASTA (`.fasta`, `.fa`), FASTQ (`.fastq`, `.fq`), and PDF text extraction.\n"
                "- **Analysis Modules:** Quality Control (QC), GC profiling, ORF detection, Pairwise Alignment, Similarity matching, Novelty scoring, and Taxon classification.\n"
                "- **Modes:** Synchronous real-time analysis (`POST /analyze`) and Asynchronous background jobs (`POST /jobs`).\n\n"
                "### Interpretation\n"
                "The platform allows researchers to safely analyze microbial genomes with full provenance tracking and immutable audit trails.\n\n"
                "### Uncertainty\n"
                "Pipeline outputs are bounded by the completeness of reference catalogs.\n\n"
                "### Recommended Safe Next Steps\n"
                "- Upload a sequence file on the dashboard or submit via the `/analyze` API."
            )

        if intent == AgentIntent.SAFETY_INQUIRY:
            return (
                "### Answer\n"
                "The platform enforces strict **Defensive Biosecurity Guardrails** to prevent misuse while advancing open biosurveillance.\n\n"
                "### Evidence\n"
                "- **Refusal Policies:** Inquiries requesting enhancement of pathogen transmissibility, virulence, immune evasion, or wet-lab synthesis protocols are unconditionally refused.\n"
                "- **Distinction Safeguard:** Lack of a reference match indicates unmapped sequence data, NOT confirmed synthetic creation.\n"
                "- **Audit Logging:** Every refusal and query is logged with SHA-256 integrity hashing.\n\n"
                "### Interpretation\n"
                "Safety guardrails safeguard computational biology research while ensuring defensive public health readiness.\n\n"
                "### Uncertainty\n"
                "Guardrails are evaluated at query time via multi-pattern inspection and intent classification.\n\n"
                "### Recommended Safe Next Steps\n"
                "- Review platform biosafety standards in the documentation or submit defensive surveillance inquiries."
            )

        # General Inquiries (Novelty, QC, General Sandbox overview)
        if "novelty" in q_lower:
            return (
                "### Answer\n"
                "**Novelty Detection** quantifies sequence divergence from catalogued reference genomes using a normalized distance score (0.0 = identical to known reference, 1.0 = highly divergent).\n\n"
                "### Evidence\n"
                "- **Novelty Score Range:** 0.0 to 1.0 based on nearest-neighbor alignment identity and k-mer distance.\n"
                "- **Status Classes:** `known_or_closely_related` (< 0.20), `possibly_novel` (>= 0.20), `insufficient_evidence`.\n"
                "- **Safety Safeguard:** A lack of database match indicates unmapped sequence data, NOT confirmed synthetic creation.\n\n"
                "### Interpretation\n"
                "Novelty detection flags divergent or out-of-distribution sequences for bioinformatician prioritization.\n\n"
                "### Uncertainty\n"
                "Divergence can reflect unrepresented reference lineages, sequencing noise, or natural evolution.\n\n"
                "### Recommended Safe Next Steps\n"
                "- Submit divergent sequences to expert review and broader public database searches."
            )

        if "quality control" in q_lower or "qc" in q_lower or "metrics" in q_lower:
            return (
                "### Answer\n"
                "**Quality Control (QC)** validates the integrity of submitted genomic data before downstream analysis.\n\n"
                "### Evidence\n"
                "- **Metrics Evaluated:** Total sequence length, GC content percentage, base composition (A, T, G, C, N), ambiguous base percentage, and duplicate records.\n"
                "- **Pass Criteria:** Valid nucleotide alphabet, minimal ambiguous 'N' count, and adequate read length.\n\n"
                "### Interpretation\n"
                "Ensures downstream alignment, novelty scoring, and classification operate on high-fidelity sequences.\n\n"
                "### Uncertainty\n"
                "QC operates on digital sequence records and does not assess wet-lab sample preparation artifacts.\n\n"
                "### Recommended Safe Next Steps\n"
                "- Review QC summary metrics on the report dashboard before interpreting taxonomic classification."
            )

        # Fallback General Response
        return (
            "### Answer\n"
            "Welcome to the **AI-Powered Pathogen Genome Intelligence Sandbox**.\n"
            "I provide grounded bioinformatics guidance, pipeline capability explanations, and evidence-based analysis report interpretations.\n\n"
            "### Evidence\n"
            "- Operating in verified grounded research mode.\n"
            "- All assertions are backed by computational pipeline standards.\n\n"
            "### Interpretation\n"
            "You can ask about bioinformatics concepts, request a computational solution architecture, or attach an Analysis ID to review specific findings.\n\n"
            "### Uncertainty\n"
            "General inquiries without an attached analysis report carry broad context.\n\n"
            "### Recommended Safe Next Steps\n"
            "- Enter an Analysis ID above to explore report-specific metrics, or ask a pipeline design question."
        )


class MockLLMProvider(LLMProvider):
    """Mock LLM Provider for unit testing external model interfaces and prompt flows."""

    def __init__(self, canned_response: Optional[str] = None) -> None:
        self.canned_response = canned_response

    def generate(
        self,
        prompt: str,
        intent: AgentIntent,
        system_prompt: Optional[str] = None,
        analysis_context: Optional[Dict[str, Any]] = None,
    ) -> str:
        if self.canned_response:
            return self.canned_response
        return (
            f"### Answer\n"
            f"[Mock LLM Response for intent '{intent.value}']: Processed prompt '{prompt[:50]}...'\n\n"
            f"### Evidence\n"
            f"- Grounded context provided: {bool(analysis_context)}\n\n"
            f"### Interpretation\n"
            f"Mock interpretation demonstrating pluggable LLM interface.\n\n"
            f"### Uncertainty\n"
            f"Controlled test environment.\n\n"
            f"### Recommended Safe Next Steps\n"
            f"- Verify mock output structure."
        )


class OpenAILLMProvider(LLMProvider):
    """OpenAI / Azure / Ollama compatible API LLM Provider."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gpt-4o",
        base_url: Optional[str] = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.model = model or os.environ.get("OPENAI_MODEL", "gpt-4o")
        self.base_url = base_url or os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1")
        self.fallback = DeterministicFallbackProvider()

    def generate(
        self,
        prompt: str,
        intent: AgentIntent,
        system_prompt: Optional[str] = None,
        analysis_context: Optional[Dict[str, Any]] = None,
    ) -> str:
        if not self.api_key:
            return self.fallback.generate(prompt, intent, system_prompt, analysis_context)

        try:
            import urllib.request
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            }
            # Phase 3: use the shared grounding system prompt
            system_msg = system_prompt or _GROUNDING_SYSTEM_PROMPT
            context_str = (
                f"\nAnalysis Context (use ONLY these values — do not invent any metrics):\n"
                f"{json.dumps(analysis_context, indent=2)}"
            ) if analysis_context else ""
            messages = [
                {"role": "system", "content": system_msg},
                {"role": "user", "content": f"{prompt}{context_str}"},
            ]
            payload = json.dumps({"model": self.model, "messages": messages, "temperature": 0.05}).encode("utf-8")
            url = f"{self.base_url.rstrip('/')}/chat/completions"
            req = urllib.request.Request(url, data=payload, headers=headers)
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data["choices"][0]["message"]["content"]
        except Exception:
            return self.fallback.generate(prompt, intent, system_prompt, analysis_context)


class GeminiLLMProvider(LLMProvider):
    """Google Gemini API LLM Provider."""

    def __init__(self, api_key: Optional[str] = None, model: str = "gemini-1.5-flash") -> None:
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY", "")
        self.model = model or os.environ.get("GEMINI_MODEL", "gemini-1.5-flash")
        self.fallback = DeterministicFallbackProvider()

    def generate(
        self,
        prompt: str,
        intent: AgentIntent,
        system_prompt: Optional[str] = None,
        analysis_context: Optional[Dict[str, Any]] = None,
    ) -> str:
        if not self.api_key:
            return self.fallback.generate(prompt, intent, system_prompt, analysis_context)

        try:
            import urllib.request
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
            headers = {"Content-Type": "application/json"}
            # Phase 3: inject grounding system prompt and context label
            system_msg = system_prompt or _GROUNDING_SYSTEM_PROMPT
            context_str = (
                f"\nAnalysis Context (use ONLY these values — do not invent any metrics):\n"
                f"{json.dumps(analysis_context, indent=2)}"
            ) if analysis_context else ""
            full_prompt = f"{system_msg}\n\nUser Question: {prompt}{context_str}"
            payload = json.dumps({
                "contents": [{"parts": [{"text": full_prompt}]}],
                "generationConfig": {"temperature": 0.05},
            }).encode("utf-8")
            req = urllib.request.Request(url, data=payload, headers=headers)
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data["candidates"][0]["content"]["parts"][0]["text"]
        except Exception:
            return self.fallback.generate(prompt, intent, system_prompt, analysis_context)


class LocalOllamaLLMProvider(LLMProvider):
    """Local LLM Provider using Ollama REST API (http://localhost:11434).

    Ollama runs open-source models (llama3, mistral, phi3, etc.) entirely
    on the local machine — no internet or API key required.

    Configure via environment variables:
      OLLAMA_BASE_URL  — default: http://localhost:11434
      OLLAMA_MODEL     — default: llama3
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        model: str = "llama3",
    ) -> None:
        self.base_url = (base_url or os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")).rstrip("/")
        self.model = model or os.environ.get("OLLAMA_MODEL", "llama3")
        self.fallback = DeterministicFallbackProvider()

    def generate(
        self,
        prompt: str,
        intent: AgentIntent,
        system_prompt: Optional[str] = None,
        analysis_context: Optional[Dict[str, Any]] = None,
    ) -> str:
        try:
            import urllib.request
            system_msg = system_prompt or _GROUNDING_SYSTEM_PROMPT
            context_str = (
                f"\nAnalysis Context (use ONLY these values — do not invent any metrics):\n"
                f"{json.dumps(analysis_context, indent=2)}"
            ) if analysis_context else ""
            full_prompt = f"{system_msg}\n\nUser Question: {prompt}{context_str}"
            payload = json.dumps({
                "model": self.model,
                "prompt": full_prompt,
                "stream": False,
                "options": {"temperature": 0.05},
            }).encode("utf-8")
            url = f"{self.base_url}/api/generate"
            req = urllib.request.Request(
                url, data=payload, headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data.get("response", "").strip()
        except Exception:
            # Ollama not running or model not pulled → silent fallback
            return self.fallback.generate(prompt, intent, system_prompt, analysis_context)


def get_llm_provider(provider_type: Optional[str] = None) -> LLMProvider:
    """Factory creating the configured LLM provider.

    Configuration hierarchy:
    1. Explicit provider_type argument
    2. LLM_PROVIDER environment variable:
       'deterministic' | 'openai' | 'gemini' | 'ollama' | 'mock'
    3. Default to DeterministicFallbackProvider (zero-hallucination, offline)
    """
    provider_name = (provider_type or os.environ.get("LLM_PROVIDER", "deterministic")).lower().strip()

    if provider_name == "openai":
        return OpenAILLMProvider()
    elif provider_name == "gemini":
        return GeminiLLMProvider()
    elif provider_name == "ollama":
        return LocalOllamaLLMProvider()
    elif provider_name == "mock":
        return MockLLMProvider()
    return DeterministicFallbackProvider()
