"""
app/agent/intent.py
===================
Intent Classifier for categorizing user inquiries into domain-specific intents.
"""

from __future__ import annotations

import re
from typing import List, Tuple
from app.agent.schemas import AgentIntent, IntentResult

# Intent detection rule tables (regex/keywords, intent, base_confidence)
_INTENT_RULES: List[Tuple[List[str], AgentIntent, float]] = [
    # 1. Vaccine Target Discovery & Reverse Vaccinology
    (
        [
            r"\b(vaccine|vaccine target|find vaccine|reverse vaccinology|antigen|epitope|mhc|b-cell epitope)\b",
            r"\b(neutralizing antibody|immunogenic|subunit vaccine|epitope prediction|target discovery)\b",
            r"\b(surface glycoprotein|protective antigen|cross-reactive epitope)\b",
        ],
        AgentIntent.VACCINE_TARGET_DISCOVERY,
        0.97,
    ),
    # 2. Pathogen Characteristics & Scientist Guidance
    (
        [
            r"\b(characteristics|pathogen characteristics|viral characteristics|pathogen profile|viral genome)\b",
            r"\b(surface protein|host receptor|ace2|spike glycoprotein|hemagglutinin|neuraminidase|envelope protein)\b",
            r"\b(guide scientist|scientist guidance|research guidance|biological features|pathogen biology)\b",
        ],
        AgentIntent.PATHOGEN_CHARACTERISTICS,
        0.96,
    ),
    # 3. Solution Building (Computational architecture, pipeline design, ML platform)
    (
        [
            r"\b(solution|architect|architecture|design a solution|create a solution|build a solution|how can i create|how to build)\b",
            r"\b(system design|platform architecture|pipeline architecture|computational pipeline|software architecture)\b",
            r"\b(deployment|infrastructure|monitoring|explainability|evaluation framework|surveillance platform)\b",
        ],
        AgentIntent.SOLUTION_BUILDING,
        0.96,
    ),
    # 2. Safety Inquiry
    (
        [
            r"\b(safety|biosecurity|guardrail|policy|dual[- ]use|disclaimer|medical disclaimer|refusal|harmful)\b",
            r"\b(rule|restrictions|defense|defensive)\b",
        ],
        AgentIntent.SAFETY_INQUIRY,
        0.95,
    ),
    # 3. Novelty Assessment (Specific questions about sequence novelty, divergence vs database gap)
    (
        [
            r"\b(novel pathogen|new pathogen|unmapped sequence|database gap|novelty score|possibly_novel|known_or_closely_related)\b",
            r"\b(is this a new|no strong match|no reference match|assess novelty)\b",
        ],
        AgentIntent.NOVELTY_ASSESSMENT,
        0.94,
    ),
    # 4. Bioinformatics Concepts
    (
        [
            r"\b(orf|open reading frame|reading frame)\b",
            r"\b(gc[- ]content|gc profile|base composition|nucleotide|atgc)\b",
            r"\b(k[- ]?mer|kmers|kmer)\b",
            r"\b(alignment|smith[- ]waterman|needleman|levenshtein|blast)\b",
            r"\b(mutation|snps|variant|indel)\b",
            r"\b(taxonomy|phylogenetic|lineage|clade)\b",
        ],
        AgentIntent.BIOINFORMATICS_CONCEPT,
        0.92,
    ),
    # 5. Pipeline Capabilities
    (
        [
            r"\b(upload|fasta|fastq|pdf|file format|supported format)\b",
            r"\b(pipeline|workflow|async|background job|queue|worker)\b",
            r"\b(api|endpoint|mcp|server|capabilities|features)\b",
        ],
        AgentIntent.PIPELINE_CAPABILITIES,
        0.90,
    ),
    # 6. System Guidance
    (
        [
            r"\b(expert review|reviewer|approval|portal|dashboard|audit log|audit event)\b",
            r"\b(how do i use|where do i find|how to navigate|login|role|rbac|admin|researcher)\b",
        ],
        AgentIntent.SYSTEM_GUIDANCE,
        0.88,
    ),
    # 7. General Genomic Information & Core Pipeline Steps
    (
        [
            r"\b(novelty detection|novelty|what is novelty)\b",
            r"\b(quality control|qc|ambiguous bases|duplicate records)\b",
            r"\b(similarity|similarity search|reference database|top hit)\b",
            r"\b(classification|taxonomic classification|functional classification)\b",
            r"\b(uncertainty|confidence score|limitations|risk)\b",
            r"\b(what is|explain|tell me about|how does)\b",
        ],
        AgentIntent.GENERAL_INFORMATION,
        0.85,
    ),
]


class IntentClassifier:
    """Classifies user queries into structured agent intent categories."""

    def classify(self, question: str, is_safe: bool = True) -> IntentResult:
        """Classify question into an AgentIntent.

        If the request was already flagged as unsafe by the SafetyRouter,
        it is directly classified as UNSAFE_REQUEST.
        """
        if not is_safe:
            return IntentResult(
                intent=AgentIntent.UNSAFE_REQUEST,
                confidence=1.0,
                matched_keywords=["safety_refusal"],
            )

        q_clean = question.strip().lower()

        # Score matching rules
        for patterns, intent, confidence in _INTENT_RULES:
            matched: List[str] = []
            for pat in patterns:
                found = re.findall(pat, q_clean)
                if found:
                    matched.extend(found if isinstance(found[0], str) else [str(x) for x in found])

            if matched:
                return IntentResult(
                    intent=intent,
                    confidence=confidence,
                    matched_keywords=list(set(matched)),
                )

        # Fallback default intent
        if len(q_clean) > 0:
            return IntentResult(
                intent=AgentIntent.GENERAL_INFORMATION,
                confidence=0.60,
                matched_keywords=["fallback_general"],
            )

        return IntentResult(
            intent=AgentIntent.OUT_OF_SCOPE,
            confidence=0.50,
            matched_keywords=[],
        )
