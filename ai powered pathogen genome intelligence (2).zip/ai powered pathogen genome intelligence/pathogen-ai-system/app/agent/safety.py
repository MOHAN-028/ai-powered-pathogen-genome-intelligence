"""
app/agent/safety.py
===================
Safety Router for biosecurity guardrails, dual-use hazard detection,
and prompt injection defense.
"""

from __future__ import annotations

import re
from typing import List, Tuple
from app.agent.schemas import SafetyCheckResult, SafetyStatus

# ── Dual-Use Biosecurity Hazard Patterns ──
# Prohibited: Pathogen engineering, genome modification, virulence enhancement/optimization,
# transmission enhancement/optimization, immune-evasion optimization, synthesis, experimental construction,
# biological-agent production.
_BIOSECURITY_HAZARDS: List[Tuple[str, str]] = [
    (r"\b(engineer|engineering|design|optimize|optimization)\b.*\b(pathogen|virus|bacteria|toxin|microbe|agent)\b", "Pathogen engineering/design/optimization"),
    (r"\b(modify|modifying|modification)\b.*\b(genome|pathogen|virus|virulence|transmissibility)\b", "Genome/pathogen modification"),
    (r"\b(enhance|enhancing|increase|boost|optimize|optimizing|optimization)\b.*\b(virulence|lethality|pathogenicity|mortality)\b", "Virulence enhancement/optimization"),
    (r"\b(enhance|enhancing|increase|boost|optimize|optimizing|optimization)\b.*\b(transmission|transmissibility|contagion|airborne|spread)\b", "Transmission enhancement/optimization"),
    (r"\b(immune[- ]evasion|evade immunity|bypass vaccine|antibody escape)\b.*\b(optimiz|design|enhance|engineer)\b", "Immune-evasion optimization"),
    (r"\b(optimiz|design|enhance|engineer)\b.*\b(immune[- ]evasion|evade immunity|bypass vaccine|antibody escape)\b", "Immune-evasion optimization"),
    (r"\b(synthesize|synthesis|synthesizing|create|reconstruct)\b.*\b(pathogen|virus|bacterium|smallpox|ebola|anthrax|polio|influenza|toxin|sequence)\b", "Pathogen/sequence synthesis / reconstruction"),
    (r"\b(protocol|recipe|guide|instructions|steps)\b.*\b(to (create|make|build|assemble|synthesize)|for (creating|making|building|assembling|synthesizing))\b.*\b(pathogen|virus|biological weapon|toxin|agent)\b", "Experimental pathogen construction protocol"),
    (r"\b(weaponiz|weaponize|biological weapon|bioweapon|gain[- ]of[- ]function)\b", "Bioweapon / Gain-of-function inquiry"),
    (r"\b(clone|cloning|express|expression)\b.*\b(toxin|botulinum|ricin|saxitoxin|aerosol)\b", "Toxin cloning / aerosolization"),
    (r"\b(biological[- ]agent|biological agent)\s+(production|culture|manufacturing|synthesis)\b", "Biological-agent production"),
    (r"\b(produce|producing|culture|culturing|grow|growing)\b.*\b(biological[- ]agent|pathogen|toxin|bioweapon)\b", "Biological-agent production"),
]

# ── Direct Hazard Keywords ──
_HAZARD_KEYWORDS = [
    "pathogen engineering",
    "genome modification",
    "virulence enhancement",
    "virulence optimization",
    "transmission enhancement",
    "transmission optimization",
    "immune-evasion optimization",
    "immune evasion",
    "pathogen synthesis",
    "synthesize pathogen",
    "synthesize sequence",
    "create pathogen",
    "design pathogen",
    "optimize pathogen",
    "increase virulence",
    "increase transmission",
    "experimental construction",
    "biological-agent production",
    "biological agent production",
    "weaponize",
    "gain of function",
    "gain-of-function",
    "enhance lethality",
    "enhance virulence",
    "enhance transmission",
    "increase transmissibility",
    "evade immune system",
    "bypass antibodies",
    "experimental pathogen construction",
    "biological weapon",
    "bioweapon",
    "aerosolize pathogen",
]

# ── Prompt Injection & Jailbreak Patterns ──
_INJECTION_PATTERNS = [
    r"ignore\s+(all\s+)?(previous|prior|above|safety|security|system)?\s*(instructions|prompts|rules|guidelines|restrictions|guardrails)",
    r"disregard\s+(all\s+)?(safety|security|system|previous|prior)?\s*(rules|prompts|instructions|policies|guardrails|restrictions)",
    r"you\s+are\s+now\s+in\s+(developer|dan|jailbreak|unrestricted|god|evil)\s+mode",
    r"override\s+(all\s+)?([a-z]+\s+)*(filters|guardrails|policies|rules|restrictions|safety|security)",
    r"pretend\s+you\s+(have\s+no|do\s+not\s+have)\s+(safety|rules|restrictions)",
    r"system\s*prompt\s*:\s*(ignore|disregard|override|reveal)",
    r"act\s+as\s+an\s+unrestricted\s+ai",
    r"bypass\s+(the\s+)?(content\s+filter|guardrails|safety\s+checks|filters)",
    r"jailbreak",
]

# ── Safe Defensive Alternatives ──
_SAFE_ALTERNATIVES = [
    "Sequence quality control & composition analysis (GC content, ambiguity checks)",
    "Reference-guided similarity search and taxonomic alignment",
    "Novelty detection and genomic divergence scoring",
    "Taxonomic and functional classification",
    "Transparent uncertainty and limitation assessment",
    "Computational biosurveillance and pathogen monitoring",
]


class SafetyRouter:
    """Evaluates incoming agent requests for biosecurity hazards and prompt injection."""

    def __init__(self, safe_alternatives: List[str] | None = None) -> None:
        self.safe_alternatives = safe_alternatives or _SAFE_ALTERNATIVES

    def evaluate(self, question: str) -> SafetyCheckResult:
        """Scan input question against biosecurity guardrails and injection defenses.

        Returns:
            SafetyCheckResult indicating whether the prompt is allowed, refused, or flagged.
        """
        q_lower = question.lower().strip()

        # 1. Prompt Injection / Jailbreak Check
        for pattern in _INJECTION_PATTERNS:
            if re.search(pattern, q_lower):
                return SafetyCheckResult(
                    is_safe=False,
                    safety_status=SafetyStatus.REFUSED,
                    reason="Request contains prompt injection or safety bypass patterns.",
                    matched_hazard="Prompt Injection Attempt",
                    safe_alternatives=self.safe_alternatives,
                )

        # 2. Direct Keyword Match
        for kw in _HAZARD_KEYWORDS:
            if kw in q_lower:
                return SafetyCheckResult(
                    is_safe=False,
                    safety_status=SafetyStatus.REFUSED,
                    reason=(
                        f"Request violates biosecurity policy regarding {kw}. "
                        "This platform strictly prohibits instructions for pathogen engineering, "
                        "synthesis, or enhancement."
                    ),
                    matched_hazard=kw,
                    safe_alternatives=self.safe_alternatives,
                )

        # 3. Regex Pattern Match for Dual-Use Biosecurity Hazards
        for pattern, label in _BIOSECURITY_HAZARDS:
            if re.search(pattern, q_lower):
                return SafetyCheckResult(
                    is_safe=False,
                    safety_status=SafetyStatus.REFUSED,
                    reason=(
                        f"Request triggers defensive biosecurity filter: {label}. "
                        "Generation of actionable modification or synthesis protocols is strictly blocked."
                    ),
                    matched_hazard=label,
                    safe_alternatives=self.safe_alternatives,
                )

        # Passed all safety checks
        return SafetyCheckResult(
            is_safe=True,
            safety_status=SafetyStatus.ALLOWED,
            reason=None,
            matched_hazard=None,
            safe_alternatives=[],
        )

    def build_refusal_response(self, result: SafetyCheckResult) -> str:
        """Generate a professional, policy-grounded refusal message with safe alternatives."""
        lines = [
            "🛡️ **Defensive Biosecurity Safety Refusal**",
            "",
            "I cannot fulfill this request. The Pathogen Genome Intelligence Sandbox operates strictly as a defensive, analytical platform.",
            f"**Reason:** {result.reason or 'Request involves dual-use biological hazards or prohibited engineering.'}",
            "",
            "**Policy Guidance:**",
            "This system prohibits assistance with pathogen engineering, genome modification, virulence/transmission enhancement, immune-evasion optimization, synthesis, or experimental pathogen construction.",
            "",
            "**Safe Analytical Alternatives Available:**",
        ]
        for alt in self.safe_alternatives:
            lines.append(f"- {alt}")

        return "\n".join(lines)
