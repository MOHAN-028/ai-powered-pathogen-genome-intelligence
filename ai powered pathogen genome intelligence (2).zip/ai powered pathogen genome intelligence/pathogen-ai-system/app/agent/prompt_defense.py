"""
app/agent/prompt_defense.py
===========================
Phase 4: Prompt Injection Defense, Untrusted Data Sandboxing, and
Conversational Log Sequence Redaction.

Untrusted Data Sources Handled:
  - FASTA metadata (headers, organism names, strain descriptions)
  - Sequence names / Sample IDs
  - Uploaded files & PDF-extracted text
  - Analysis reports & database fields
  - User-provided conversational text

Defenses Implemented:
  1. Delimiter-Based Data Sandboxing: Wraps untrusted data in explicit tags.
  2. Injection Pattern Neutralization: Neutralizes instruction overrides.
  3. Strict Hierarchy Enforcement: System safety rules always override untrusted data.
  4. Sequence Log Redaction: Automatically strips raw nucleotide sequences from audit logs.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple


# ── Known Prompt Injection & Jailbreak Override Signatures ──
_INJECTION_OVERRIDE_PATTERNS: List[re.Pattern] = [
    re.compile(r"ignore\s+(all\s+)?(previous|prior|above|safety|security|system)?\s*(instructions|prompts|rules|guidelines|restrictions|guardrails)", re.IGNORECASE),
    re.compile(r"disregard\s+(all\s+)?(safety|security|system|previous|prior)?\s*(rules|prompts|instructions|policies|guardrails|restrictions)", re.IGNORECASE),
    re.compile(r"you\s+are\s+now\s+in\s+(developer|dan|jailbreak|unrestricted|god|evil)\s+mode", re.IGNORECASE),
    re.compile(r"override\s+(all\s+)?([a-z]+\s+)*(filters|guardrails|policies|rules|restrictions|safety|security)", re.IGNORECASE),
    re.compile(r"pretend\s+you\s+(have\s+no|do\s+not\s+have)\s+(safety|rules|restrictions)", re.IGNORECASE),
    re.compile(r"system\s*prompt\s*:\s*(ignore|disregard|override|reveal)", re.IGNORECASE),
    re.compile(r"act\s+as\s+an\s+unrestricted\s+ai", re.IGNORECASE),
    re.compile(r"bypass\s+(the\s+)?(content\s+filter|guardrails|safety\s+checks|filters)", re.IGNORECASE),
    re.compile(r"<\s*script\s*>", re.IGNORECASE),
    re.compile(r"```\s*(system|admin|root)", re.IGNORECASE),
]

# Pattern detecting raw nucleotide sequence strings (>25 bp of A, C, G, T, N, U)
_NUCLEOTIDE_SEQUENCE_PATTERN = re.compile(
    r"\b([ACGTUNacgtun]{25,})\b"
)


class PromptDefense:
    """Defensive pre-processing and untrusted data sandboxing engine."""

    # ------------------------------------------------------------------
    # 1. Injection Pattern Scanning & Neutralization
    # ------------------------------------------------------------------

    @classmethod
    def detect_injection_attempt(cls, text: str) -> Tuple[bool, Optional[str]]:
        """Scan text for known prompt injection and jailbreak override attempts.

        Returns:
            Tuple of (is_injection, matched_pattern_description)
        """
        if not text:
            return False, None

        for pattern in _INJECTION_OVERRIDE_PATTERNS:
            match = pattern.search(text)
            if match:
                return True, match.group(0)

        return False, None

    @classmethod
    def neutralize_injection_patterns(cls, text: str) -> str:
        """Replace active injection instructions with harmless contained text markers."""
        if not text:
            return ""

        sanitized = text
        for pattern in _INJECTION_OVERRIDE_PATTERNS:
            sanitized = pattern.sub("[UNTRUSTED_INSTRUCTION_CONTAINED]", sanitized)

        return sanitized

    # ------------------------------------------------------------------
    # 2. Untrusted Data Delimiter Sandboxing
    # ------------------------------------------------------------------

    @classmethod
    def sandbox_untrusted_data(
        cls,
        data: Any,
        data_type: str = "untrusted_input",
    ) -> str:
        """Encapsulate untrusted data inside explicit, unescapable boundary tags.

        The enclosing tags inform LLMs and downstream parsers that the enclosed
        content is passive, unverified data that cannot execute commands or
        override system guardrails.
        """
        if data is None:
            return ""

        # If data is a dictionary or list, convert to formatted JSON string
        if isinstance(data, (dict, list)):
            import json
            raw_text = json.dumps(data, indent=2)
        else:
            raw_text = str(data)

        # Neutralize any injection instructions embedded within the data
        neutralized_text = cls.neutralize_injection_patterns(raw_text)

        return (
            f"<untrusted_data type=\"{data_type}\">\n"
            f"{neutralized_text}\n"
            f"</untrusted_data>"
        )

    @classmethod
    def sandbox_analysis_context(cls, context: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Deep-sanitize analysis context fields (sample IDs, notes, rationale).

        Ensures malicious metadata embedded in FASTA headers or analysis notes
        cannot escape into active prompt execution.
        """
        if not context:
            return None

        import copy
        sanitized = copy.deepcopy(context)

        def _walk_sanitize(obj: Any) -> Any:
            if isinstance(obj, str):
                return cls.neutralize_injection_patterns(obj)
            elif isinstance(obj, dict):
                return {k: _walk_sanitize(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [_walk_sanitize(item) for item in obj]
            return obj

        return _walk_sanitize(sanitized)

    # ------------------------------------------------------------------
    # 3. Conversational Log Sequence Redaction (Privacy & Data Hygiene)
    # ------------------------------------------------------------------

    @classmethod
    def redact_sequences_from_log(cls, text: str) -> str:
        """Redact raw nucleotide sequences (>25 bp) from text before audit persistence.

        Preserves sequence length and GC content summary without leaking raw bases.
        """
        if not text:
            return ""

        def _replace_seq(match: re.Match) -> str:
            seq = match.group(1).upper()
            length = len(seq)
            g_count = seq.count("G")
            c_count = seq.count("C")
            gc_pct = round((g_count + c_count) / max(length, 1) * 100, 1)
            return f"[REDACTED_SEQUENCE length={length}bp GC={gc_pct}%]"

        return _NUCLEOTIDE_SEQUENCE_PATTERN.sub(_replace_seq, text)

    @classmethod
    def redact_sequences_from_dict(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        """Recursively redact raw nucleotide sequences from dictionaries before logging."""
        import copy
        sanitized = copy.deepcopy(data)

        def _walk(obj: Any) -> Any:
            if isinstance(obj, str):
                return cls.redact_sequences_from_log(obj)
            elif isinstance(obj, dict):
                return {k: _walk(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [_walk(item) for item in obj]
            return obj

        return _walk(sanitized)
