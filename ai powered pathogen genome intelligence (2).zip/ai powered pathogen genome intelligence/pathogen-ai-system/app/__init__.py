"""
app package for Phase 2 AI-Powered Pathogen Genome Intelligence System.
"""
__version__ = "0.2.0"
