"""
app/review/expert_review.py
============================
Expert review workflow state machine.
"""

from __future__ import annotations

import json
import uuid
from typing import Literal, Optional
from app.db.database import DatabaseStore
from app.db.models import DBExpertReview
from app.models.schemas import GenomeIntelligenceReport


class ExpertReviewManager:
    """Manages expert review approvals, rejections, and re-analysis requests."""

    def __init__(self, db_store: DatabaseStore) -> None:
        self.db = db_store

    def submit_review(
        self,
        analysis_id: str,
        reviewer_id: str,
        decision: Literal["approved", "rejected", "reanalysis_requested"],
        notes: str,
    ) -> Optional[GenomeIntelligenceReport]:
        """Submit expert review decision and update report state."""
        db_res = self.db.get_analysis_result(analysis_id)
        if not db_res:
            return None

        review_id = f"rev_{uuid.uuid4().hex[:8]}"
        review = DBExpertReview(
            review_id=review_id,
            analysis_id=analysis_id,
            reviewer_id=reviewer_id,
            decision=decision,
            notes=notes,
        )
        self.db.save_expert_review(review)

        # Deserialize report, update review status, and save back
        report_dict = json.loads(db_res.report_json)
        if decision == "approved":
            report_dict["expert_review_status"] = "reviewed"
        elif decision == "rejected":
            report_dict["expert_review_status"] = "under_review"
            report_dict["warnings"].append(f"Expert Reviewer Rejected Finding: {notes}")
        elif decision == "reanalysis_requested":
            report_dict["expert_review_status"] = "under_review"
            report_dict["warnings"].append(f"Re-analysis Requested by Expert: {notes}")

        updated_report = GenomeIntelligenceReport(**report_dict)
        db_res.report_json = updated_report.model_dump_json(indent=2)
        self.db.save_analysis_result(db_res)

        return updated_report

    def get_review_history(self, analysis_id: str) -> list[DBExpertReview]:
        return self.db.get_expert_reviews(analysis_id)
