"""
app/services/pipeline.py
========================
Pipeline orchestrator connecting QC, similarity, novelty, classification,
uncertainty assessment, and report generation.
"""

from __future__ import annotations

import uuid
from typing import Dict, Optional, Sequence
from src.bioinformatics_tools import SequenceRecord
from src.genomic_ai_model import PathogenClassifier

from app.models.schemas import GenomeIntelligenceReport
from app.analysis.qc import run_qc
from app.analysis.similarity import LocalReferenceDatabase, ReferenceDatabase, analyze_similarity
from app.analysis.novelty import detect_novelty
from app.analysis.classification import classify_sequence
from app.analysis.uncertainty import evaluate_uncertainty
from app.analysis.report import build_report, render_html_report


class GenomeIntelligencePipeline:
    """End-to-end defensive biological sequence analysis pipeline."""

    def __init__(
        self,
        reference_db: Optional[ReferenceDatabase] = None,
        ml_classifier: Optional[PathogenClassifier] = None,
    ) -> None:
        if reference_db is None:
            # Default reference database with safe reference sequences
            default_refs = [
                SequenceRecord(id="REF-EC-01", description="[label=Escherichia_coli] K-12 MG1655", sequence="ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAGGTAACGGTGCGGGCTGA" * 5),
                SequenceRecord(id="REF-SE-02", description="[label=Salmonella_enterica] LT2 reference", sequence="ATGTTTCAACCTCCTGCCGATATCACCACCATTACCACCACCATCACCATTACCACAGGTAACGGT" * 5),
                SequenceRecord(id="REF-SA-03", description="[label=Staphylococcus_aureus] N315 reference", sequence="ATGGCAATTACAAAACGTTATCGTCACCACCATCACCATTACCACAGGTAACGGTGCGGGCTGA" * 5),
            ]
            self.reference_db: ReferenceDatabase = LocalReferenceDatabase(default_refs)
        else:
            self.reference_db = reference_db

        self.ml_classifier = ml_classifier
        self._reports_store: Dict[str, GenomeIntelligenceReport] = {}

    def run(
        self,
        records: Sequence[SequenceRecord],
        sample_id: Optional[str] = None,
    ) -> GenomeIntelligenceReport:
        """Run complete Phase 2 analysis pipeline on input records.

        Steps
        -----
        1. QC
        2. Similarity
        3. Novelty
        4. Classification
        5. Uncertainty
        6. Report Generation
        """
        analysis_id = str(uuid.uuid4())[:8]
        s_id = sample_id or (records[0].id if records else f"sample_{analysis_id}")

        # Step 1: Quality Control
        qc_result = run_qc(records)

        # Extract sequence string for downstream analysis
        primary_seq = records[0].sequence if records else ""

        # Step 2: Similarity Analysis
        sim_result = analyze_similarity(
            query_id=s_id,
            sequence=primary_seq,
            db=self.reference_db,
            top_k=5,
        )

        # Step 3: Novelty Detection
        novelty_result = detect_novelty(sim_result)

        # Step 4: Taxonomic / Functional Classification
        cls_result = classify_sequence(
            sequence=primary_seq,
            similarity=sim_result,
            ml_classifier=self.ml_classifier,
        )

        # Step 5: Risk & Uncertainty Assessment
        unc_result = evaluate_uncertainty(
            qc=qc_result,
            similarity=sim_result,
            novelty=novelty_result,
            classification=cls_result,
        )

        # Step 6: Report Generation
        report = build_report(
            analysis_id=analysis_id,
            sample_id=s_id,
            qc=qc_result,
            similarity=sim_result,
            novelty=novelty_result,
            classification=cls_result,
            uncertainty=unc_result,
        )

        # Store in memory store for retrieval
        self._reports_store[analysis_id] = report
        return report

    def get_report(self, analysis_id: str) -> Optional[GenomeIntelligenceReport]:
        """Fetch report JSON by analysis ID."""
        return self._reports_store.get(analysis_id)

    def get_report_html(self, analysis_id: str) -> Optional[str]:
        """Fetch rendered HTML report by analysis ID."""
        report = self.get_report(analysis_id)
        if not report:
            return None
        return render_html_report(report)
