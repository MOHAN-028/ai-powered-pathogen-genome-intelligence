"""
app/models/schemas.py
=====================
Data models and Pydantic schemas for the Phase 2 Genome Intelligence pipeline.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal, Optional
from pydantic import BaseModel, Field


class BaseComposition(BaseModel):
    A: int = 0
    T: int = 0
    G: int = 0
    C: int = 0
    N: int = 0
    other: int = 0


class QCResult(BaseModel):
    """Quality control metrics for sequence(s)."""
    num_records: int
    total_length: int
    gc_content: float
    base_composition: BaseComposition
    ambiguous_bases: int
    ambiguous_percentage: float
    duplicate_records_count: int
    quality_passed: bool
    warnings: list[str] = Field(default_factory=list)


class SimilarityHit(BaseModel):
    """A single reference similarity match."""
    reference_id: str
    taxon_name: str
    similarity_score: float = Field(..., ge=0.0, le=1.0)
    alignment_length: int
    identity_percentage: float
    coverage_percentage: float
    confidence: float
    notes: Optional[str] = None


class SimilarityResult(BaseModel):
    """Outcome of comparing query against reference database."""
    query_id: str
    top_hit: Optional[SimilarityHit] = None
    all_hits: list[SimilarityHit] = Field(default_factory=list)
    max_similarity: float = 0.0
    database_version: str
    database_status: Literal["active", "empty", "unavailable"] = "active"
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class NoveltyResult(BaseModel):
    """Novelty classification and safety safeguards."""
    status: Literal["known_or_closely_related", "possibly_novel", "insufficient_evidence"]
    novelty_score: float = Field(..., ge=0.0, le=1.0, description="0.0 = identical to known reference, 1.0 = highly divergent")
    rationale: str
    distinction_notice: str = Field(
        default="A lack of a database match indicates unmapped sequence data, NOT confirmed creation or discovery of a new pathogen.",
        description="Explicit safety disclaimer"
    )


class ClassificationResult(BaseModel):
    """Taxonomic or functional classification result."""
    classification: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    evidence: list[str] = Field(default_factory=list)
    database_version: str = "demo-ref-v1.0"


class UncertaintyResult(BaseModel):
    """Transparent risk and uncertainty assessment."""
    confidence: float = Field(..., ge=0.0, le=1.0)
    uncertainty: float = Field(..., ge=0.0, le=1.0)
    evidence_sources: list[str] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)
    reason_for_alert: Optional[str] = None
    medical_disclaimer: str = Field(
        default="This platform provides research sequence analysis only. It does NOT diagnose clinical infection or determine medical treatment.",
        description="Non-clinical disclaimer"
    )


class AIExplanation(BaseModel):
    """Human-understandable explanation layer."""
    finding: str
    interpretation: str
    confidence_summary: str
    recommended_next_step: str


class GenomeIntelligenceReport(BaseModel):
    """Complete Phase 2 Research Intelligence Report."""
    analysis_id: str
    sample_id: str
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    sequence_statistics: QCResult
    similarity: SimilarityResult
    novelty: NoveltyResult
    classification: ClassificationResult
    risk_and_uncertainty: UncertaintyResult
    ai_explanation: AIExplanation
    database_versions: dict[str, str]
    warnings: list[str] = Field(default_factory=list)
    expert_review_status: Literal["pending_expert_review", "under_review", "reviewed"] = "pending_expert_review"
    safety_compliance: str = "Strict defensive sequence analysis. No pathogen engineering or synthesis guidance."
