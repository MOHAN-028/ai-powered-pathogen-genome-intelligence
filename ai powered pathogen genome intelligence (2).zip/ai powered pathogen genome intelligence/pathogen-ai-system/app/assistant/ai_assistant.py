"""
app/assistant/ai_assistant.py
==============================
Report-grounded AI Explanation Assistant for answering researcher questions.
"""

from __future__ import annotations

import re
from typing import Optional
from app.models.schemas import GenomeIntelligenceReport


_HAZARD_KEYWORDS = [
    "engineer", "modify", "synthesize", "create pathogen", "enhance transmissibility",
    "weaponize", "protocol to create", "increase resistance", "clinical treatment",
]


class ReportExplanationAssistant:
    """Report-grounded AI assistant for interactive Q&A on sequence analysis reports."""

    def answer_question(self, report: GenomeIntelligenceReport, question: str) -> dict:
        """Answer researcher questions strictly grounded in report evidence.

        Refusal Rule:
        -------------
        Requests attempting to generate pathogen engineering, synthesis protocols, or
        harmful modifications are rejected with an explicit biological safety notice.
        """
        q_clean = question.strip().lower()

        # 1. Biological Safety check
        for kw in _HAZARD_KEYWORDS:
            if kw in q_clean:
                return {
                    "question": question,
                    "answer": (
                        "SAFETY REFUSAL: This system is a defensive intelligence platform. "
                        "I cannot generate pathogen modification, synthesis, engineering instructions, "
                        "or clinical treatment protocols."
                    ),
                    "grounded_evidence": ["Defensive Biological Safety Policy"],
                    "evidence": ["Defensive Biological Safety Policy"],
                    "confidence": 1.0,
                }

        # 2. Topic: What does the result mean?
        if "result" in q_clean or "mean" in q_clean or "summary" in q_clean:
            ans = (
                f"For Sample '{report.sample_id}', the sequence is classified as "
                f"'{report.classification.classification}' with a novelty assessment of "
                f"'{report.novelty.status.upper()}'. {report.ai_explanation.interpretation}"
            )
            return {
                "question": question,
                "answer": ans,
                "grounded_evidence": [report.ai_explanation.finding],
                "evidence": [report.ai_explanation.finding],
                "confidence": report.risk_and_uncertainty.confidence,
            }

        # 3. Topic: Why is confidence high or low?
        if "confidence" in q_clean or "uncertainty" in q_clean:
            ans = (
                f"Confidence is {report.risk_and_uncertainty.confidence * 100:.1f}% "
                f"(Uncertainty: {report.risk_and_uncertainty.uncertainty * 100:.1f}%). "
                f"Key factors: {'; '.join(report.risk_and_uncertainty.evidence_sources if report.risk_and_uncertainty.evidence_sources else ['No DB hit'])}. "
                f"Limitations: {'; '.join(report.risk_and_uncertainty.limitations if report.risk_and_uncertainty.limitations else ['None'])}."
            )
            return {
                "question": question,
                "answer": ans,
                "grounded_evidence": report.risk_and_uncertainty.evidence_sources,
                "evidence": report.risk_and_uncertainty.evidence_sources,
                "confidence": report.risk_and_uncertainty.confidence,
            }

        # 4. Topic: Evidence used
        if "evidence" in q_clean or "database" in q_clean or "match" in q_clean:
            ev_list = report.classification.evidence
            ans = (
                f"Classification evidence used ({report.similarity.database_version}): "
                f"{'; '.join(ev_list) if ev_list else 'No direct reference hits'}. "
                f"Top similarity score was {report.similarity.max_similarity:.4f}."
            )
            return {
                "question": question,
                "answer": ans,
                "grounded_evidence": ev_list,
                "evidence": ev_list,
                "confidence": report.classification.confidence,
            }

        # 5. Topic: Why sequence is unusual or novel
        if "unusual" in q_clean or "novel" in q_clean or "divergent" in q_clean:
            ans = (
                f"Novelty score is {report.novelty.novelty_score} ({report.novelty.status}). "
                f"{report.novelty.rationale} Note: {report.novelty.distinction_notice}"
            )
            return {
                "question": question,
                "answer": ans,
                "grounded_evidence": [report.novelty.rationale],
                "evidence": [report.novelty.rationale],
                "confidence": report.classification.confidence,
            }

        # General Fallback grounded response
        ans = (
            f"Based on Report '{report.analysis_id}': Finding: {report.ai_explanation.finding} "
            f"Recommended Next Step: {report.ai_explanation.recommended_next_step}"
        )
        return {
            "question": question,
            "answer": ans,
            "grounded_evidence": [report.ai_explanation.finding],
            "evidence": [report.ai_explanation.finding],
            "confidence": report.risk_and_uncertainty.confidence,
        }

