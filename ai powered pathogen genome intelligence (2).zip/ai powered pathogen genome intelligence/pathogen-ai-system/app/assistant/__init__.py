"""
app.assistant package.
"""
