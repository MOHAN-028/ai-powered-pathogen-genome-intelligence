"""
app/security/auth.py
====================
Authentication, password hashing, and role-based access control (RBAC).
"""

from __future__ import annotations

import hashlib
import secrets
from typing import Optional
from app.db.database import DatabaseStore
from app.db.models import DBUser


def hash_password(password: str) -> str:
    """Hash password using SHA-256 with salt."""
    salt = "pathogen_zero_g_salt_"
    return hashlib.sha256((salt + password).encode("utf-8")).hexdigest()


def verify_password(password: str, hashed: str) -> bool:
    return hash_password(password) == hashed


def create_demo_users(db: DatabaseStore) -> None:
    """Seed initial demo users if not present."""
    if not db.get_user_by_username("researcher1"):
        db.create_user(
            DBUser(
                user_id="user_res_01",
                username="researcher1",
                role="researcher",
                hashed_password=hash_password("researcher123"),
            )
        )
    if not db.get_user_by_username("expert1"):
        db.create_user(
            DBUser(
                user_id="user_exp_01",
                username="expert1",
                role="expert_reviewer",
                hashed_password=hash_password("expert123"),
            )
        )
    if not db.get_user_by_username("admin1"):
        db.create_user(
            DBUser(
                user_id="user_adm_01",
                username="admin1",
                role="admin",
                hashed_password=hash_password("admin123"),
            )
        )


def check_role_access(user_role: str, required_roles: list[str]) -> bool:
    """Verify if user_role satisfies required_roles."""
    if "admin" == user_role:
        return True
    return user_role in required_roles
