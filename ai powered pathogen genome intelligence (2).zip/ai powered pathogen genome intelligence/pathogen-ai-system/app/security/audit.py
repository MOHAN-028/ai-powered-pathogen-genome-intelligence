"""
app/security/audit.py
=====================
Audit logging, rate limiting, and security header management.
"""

from __future__ import annotations

import time
import uuid
from typing import Dict
from app.db.database import DatabaseStore
from app.db.models import DBAuditEvent


class AuditLogger:
    """Audit logger for tracking security-sensitive system actions with raw sequence redaction."""

    def __init__(self, db_store: DatabaseStore) -> None:
        self.db = db_store

    def log(
        self,
        user_id: str,
        action: str,
        resource: str,
        ip_address: str = "127.0.0.1",
        details: str | None = None,
    ) -> DBAuditEvent:
        # Phase 4 Sequence Redaction: strip raw genome sequence characters from conversational logs
        from app.agent.prompt_defense import PromptDefense
        sanitized_resource = PromptDefense.redact_sequences_from_log(resource)
        sanitized_details = PromptDefense.redact_sequences_from_log(details) if details else None

        event = DBAuditEvent(
            event_id=f"audit_{uuid.uuid4().hex[:8]}",
            user_id=user_id,
            action=action,
            resource=sanitized_resource,
            ip_address=ip_address,
            details=sanitized_details,
        )
        return self.db.log_audit_event(event)


class SimpleRateLimiter:
    """In-memory sliding window rate limiter."""

    def __init__(self, max_requests: int = 100, window_seconds: int = 60) -> None:
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.records: Dict[str, list[float]] = {}

    def is_allowed(self, client_ip: str) -> bool:
        now = time.time()
        cutoff = now - self.window_seconds
        timestamps = self.records.get(client_ip, [])

        # Filter out expired timestamps
        valid = [t for t in timestamps if t > cutoff]
        if len(valid) >= self.max_requests:
            return False

        valid.append(now)
        self.records[client_ip] = valid
        return True


def get_security_headers() -> dict[str, str]:
    """Return standard defensive HTTP security response headers."""
    return {
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "X-XSS-Protection": "1; mode=block",
        "Content-Security-Policy": "default-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://fonts.gstatic.com;",
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    }
