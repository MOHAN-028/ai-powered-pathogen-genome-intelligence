"""
app/queue/job_queue.py
======================
Asynchronous Job Queue Worker for background analysis execution.
"""

from __future__ import annotations

import json
import logging
import queue
import threading
import time
import uuid
from datetime import datetime, timezone
from typing import Callable, Optional

from app.db.database import DatabaseStore
from app.db.models import DBAnalysisResult, DBJob
from src.bioinformatics_tools import SequenceRecord
from app.services.pipeline import GenomeIntelligencePipeline

logger = logging.getLogger(__name__)


class JobQueueWorker:
    """Background worker executing computational sequence analysis jobs asynchronously."""

    def __init__(
        self,
        db_store: DatabaseStore,
        pipeline: GenomeIntelligencePipeline,
        num_workers: int = 2,
    ) -> None:
        self.db = db_store
        self.pipeline = pipeline
        self.task_queue: queue.Queue[dict] = queue.Queue()
        self.num_workers = num_workers
        self.cancelled_jobs: set[str] = set()
        self._running = False
        self._threads: list[threading.Thread] = []

    def start(self) -> None:
        """Start worker thread pool."""
        if self._running:
            return
        self._running = True
        for i in range(self.num_workers):
            t = threading.Thread(target=self._worker_loop, name=f"SandboxWorker-{i+1}", daemon=True)
            t.start()
            self._threads.append(t)
        logger.info("Sandbox Job Queue Worker started with %d threads.", self.num_workers)

    def stop(self) -> None:
        """Stop worker thread pool."""
        self._running = False
        for _ in self._threads:
            self.task_queue.put({})

    def submit_job(
        self,
        records: list[SequenceRecord],
        sample_id: str = "sample_001",
        user_id: str = "anonymous",
    ) -> DBJob:
        """Enqueue new sequence analysis task."""
        job_id = f"job_{uuid.uuid4().hex[:8]}"
        job = DBJob(
            job_id=job_id,
            sample_id=sample_id,
            user_id=user_id,
            status="queued",
            progress=0,
            retries=0,
            max_retries=3,
        )
        self.db.create_job(job)
        self.task_queue.put({"job_id": job_id, "sample_id": sample_id, "records": records, "user_id": user_id})
        return job

    def cancel_job(self, job_id: str) -> bool:
        """Cancel a queued or running job."""
        job = self.db.get_job(job_id)
        if not job or job.status in ("completed", "failed", "cancelled"):
            return False

        self.cancelled_jobs.add(job_id)
        job.status = "cancelled"
        job.error_message = "Job cancelled by user request."
        job.updated_at = datetime.now(timezone.utc).isoformat()
        self.db.update_job(job)
        return True

    def _worker_loop(self) -> None:
        while self._running:
            try:
                task = self.task_queue.get(timeout=1.0)
            except queue.Empty:
                continue

            if not task or "job_id" not in task:
                continue

            job_id = task["job_id"]
            if job_id in self.cancelled_jobs:
                logger.info("Job %s was cancelled before processing.", job_id)
                self.task_queue.task_done()
                continue

            self._process_job(task)
            self.task_queue.task_done()

    def _process_job(self, task: dict) -> None:
        job_id = task["job_id"]
        records: list[SequenceRecord] = task["records"]
        sample_id = task["sample_id"]

        job = self.db.get_job(job_id)
        if not job or job.status == "cancelled":
            return

        job.status = "processing"
        job.progress = 10
        job.updated_at = datetime.now(timezone.utc).isoformat()
        self.db.update_job(job)

        try:
            # Simulate progressive computational steps for UI status tracker
            time.sleep(0.1)
            job.progress = 40
            self.db.update_job(job)

            # Run Phase 2 Pipeline inside sandbox environment
            report = self.pipeline.run(records, sample_id=sample_id)
            job.progress = 80
            self.db.update_job(job)

            # Persist report JSON in Database
            report_json = report.model_dump_json(indent=2)
            db_res = DBAnalysisResult(
                analysis_id=report.analysis_id,
                job_id=job_id,
                sample_id=sample_id,
                report_json=report_json,
            )
            self.db.save_analysis_result(db_res)

            # Mark job complete
            job.status = "completed"
            job.progress = 100
            job.analysis_id = report.analysis_id
            job.updated_at = datetime.now(timezone.utc).isoformat()
            self.db.update_job(job)
            logger.info("Job %s completed successfully (Analysis ID: %s).", job_id, report.analysis_id)

        except Exception as exc:
            logger.error("Job %s failed: %s", job_id, str(exc))
            if job.retries < job.max_retries:
                job.retries += 1
                job.status = "queued"
                job.progress = 0
                job.updated_at = datetime.now(timezone.utc).isoformat()
                self.db.update_job(job)
                # Re-queue task
                self.task_queue.put(task)
            else:
                job.status = "failed"
                job.error_message = str(exc)
                job.updated_at = datetime.now(timezone.utc).isoformat()
                self.db.update_job(job)
