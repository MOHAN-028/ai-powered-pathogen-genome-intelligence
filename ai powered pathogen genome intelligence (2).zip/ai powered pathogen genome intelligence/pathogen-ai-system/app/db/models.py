"""
app/db/models.py
================
Database entities and Pydantic record models for Phase 3 storage.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal, Optional
from pydantic import BaseModel, Field


class DBUser(BaseModel):
    user_id: str
    username: str
    role: Literal["researcher", "expert_reviewer", "admin"] = "researcher"
    hashed_password: str
    is_active: bool = True
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class DBJob(BaseModel):
    job_id: str
    sample_id: str
    user_id: str = "anonymous"
    status: Literal["queued", "processing", "completed", "failed", "cancelled"] = "queued"
    progress: int = 0
    analysis_id: Optional[str] = None
    error_message: Optional[str] = None
    retries: int = 0
    max_retries: int = 3
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class DBAnalysisResult(BaseModel):
    analysis_id: str
    job_id: str
    sample_id: str
    report_json: str  # Serialized GenomeIntelligenceReport
    user_id: str = "anonymous"
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class DBExpertReview(BaseModel):
    review_id: str
    analysis_id: str
    reviewer_id: str
    decision: Literal["approved", "rejected", "reanalysis_requested"]
    notes: str
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class DBAuditEvent(BaseModel):
    event_id: str
    user_id: str
    action: str
    resource: str
    ip_address: str = "127.0.0.1"
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    details: Optional[str] = None


class DBReferenceVersion(BaseModel):
    version_id: str
    version_name: str
    release_date: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    num_records: int = 0
    description: Optional[str] = None

