"""
app/db/database.py
==================
Thread-safe persistent storage interface for users, jobs, results, reviews, and audit events.
"""

from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Dict, List, Optional

from app.db.models import DBAuditEvent, DBAnalysisResult, DBExpertReview, DBJob, DBReferenceVersion, DBUser


class DatabaseStore:
    """Thread-safe SQLite persistent database store."""

    def __init__(self, db_path: str | Path = "data/platform_db.sqlite") -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._lock, self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                role TEXT NOT NULL,
                hashed_password TEXT NOT NULL,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            """)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                job_id TEXT PRIMARY KEY,
                sample_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                status TEXT NOT NULL,
                progress INTEGER NOT NULL DEFAULT 0,
                analysis_id TEXT,
                error_message TEXT,
                retries INTEGER NOT NULL DEFAULT 0,
                max_retries INTEGER NOT NULL DEFAULT 3,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            """)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS analysis_results (
                analysis_id TEXT PRIMARY KEY,
                job_id TEXT NOT NULL,
                sample_id TEXT NOT NULL,
                report_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                user_id TEXT DEFAULT 'anonymous'
            );
            """)
            # Ensure user_id column exists if table was created in earlier phase
            try:
                cursor.execute("ALTER TABLE analysis_results ADD COLUMN user_id TEXT DEFAULT 'anonymous'")
            except sqlite3.OperationalError:
                pass
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS expert_reviews (
                review_id TEXT PRIMARY KEY,
                analysis_id TEXT NOT NULL,
                reviewer_id TEXT NOT NULL,
                decision TEXT NOT NULL,
                notes TEXT NOT NULL,
                timestamp TEXT NOT NULL
            );
            """)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS audit_events (
                event_id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                action TEXT NOT NULL,
                resource TEXT NOT NULL,
                ip_address TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                details TEXT
            );
            """)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS reference_db_versions (
                version_id TEXT PRIMARY KEY,
                version_name TEXT NOT NULL,
                release_date TEXT NOT NULL,
                num_records INTEGER NOT NULL,
                description TEXT
            );
            """)
            conn.commit()


    # -- User methods --------------------------------------------------------

    def create_user(self, user: DBUser) -> DBUser:
        with self._lock, self._get_connection() as conn:
            conn.execute(
                "INSERT INTO users VALUES (?, ?, ?, ?, ?, ?)",
                (user.user_id, user.username, user.role, user.hashed_password, 1 if user.is_active else 0, user.created_at),
            )
            conn.commit()
        return user

    def get_user_by_username(self, username: str) -> Optional[DBUser]:
        with self._lock, self._get_connection() as conn:
            row = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
            if row:
                return DBUser(
                    user_id=row["user_id"],
                    username=row["username"],
                    role=row["role"],
                    hashed_password=row["hashed_password"],
                    is_active=bool(row["is_active"]),
                    created_at=row["created_at"],
                )
        return None

    def get_user_by_id(self, user_id: str) -> Optional[DBUser]:
        with self._lock, self._get_connection() as conn:
            row = conn.execute("SELECT * FROM users WHERE user_id = ? OR username = ?", (user_id, user_id)).fetchone()
            if row:
                return DBUser(
                    user_id=row["user_id"],
                    username=row["username"],
                    role=row["role"],
                    hashed_password=row["hashed_password"],
                    is_active=bool(row["is_active"]),
                    created_at=row["created_at"],
                )
        return None

    # -- Job methods ---------------------------------------------------------

    def create_job(self, job: DBJob) -> DBJob:
        with self._lock, self._get_connection() as conn:
            conn.execute(
                "INSERT INTO jobs VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    job.job_id, job.sample_id, job.user_id, job.status, job.progress,
                    job.analysis_id, job.error_message, job.retries, job.max_retries,
                    job.created_at, job.updated_at,
                ),
            )
            conn.commit()
        return job

    def update_job(self, job: DBJob) -> DBJob:
        with self._lock, self._get_connection() as conn:
            conn.execute(
                """
                UPDATE jobs SET
                    status = ?, progress = ?, analysis_id = ?, error_message = ?,
                    retries = ?, updated_at = ?
                WHERE job_id = ?
                """,
                (job.status, job.progress, job.analysis_id, job.error_message, job.retries, job.updated_at, job.job_id),
            )
            conn.commit()
        return job

    def get_job(self, job_id: str) -> Optional[DBJob]:
        with self._lock, self._get_connection() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
            if row:
                return DBJob(
                    job_id=row["job_id"],
                    sample_id=row["sample_id"],
                    user_id=row["user_id"],
                    status=row["status"],
                    progress=row["progress"],
                    analysis_id=row["analysis_id"],
                    error_message=row["error_message"],
                    retries=row["retries"],
                    max_retries=row["max_retries"],
                    created_at=row["created_at"],
                    updated_at=row["updated_at"],
                )
        return None

    def list_jobs(self, limit: int = 50) -> List[DBJob]:
        with self._lock, self._get_connection() as conn:
            rows = conn.execute("SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
            return [
                DBJob(
                    job_id=r["job_id"], sample_id=r["sample_id"], user_id=r["user_id"],
                    status=r["status"], progress=r["progress"], analysis_id=r["analysis_id"],
                    error_message=r["error_message"], retries=r["retries"], max_retries=r["max_retries"],
                    created_at=r["created_at"], updated_at=r["updated_at"],
                )
                for r in rows
            ]

    # -- Result methods ------------------------------------------------------

    def save_analysis_result(self, result: DBAnalysisResult) -> DBAnalysisResult:
        with self._lock, self._get_connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO analysis_results (analysis_id, job_id, sample_id, report_json, created_at, user_id)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (result.analysis_id, result.job_id, result.sample_id, result.report_json, result.created_at, result.user_id),
            )
            conn.commit()
        return result

    def get_analysis_result(self, analysis_id: str) -> Optional[DBAnalysisResult]:
        with self._lock, self._get_connection() as conn:
            row = conn.execute("SELECT * FROM analysis_results WHERE analysis_id = ?", (analysis_id,)).fetchone()
            if row:
                user_id = "anonymous"
                if "user_id" in row.keys() and row["user_id"]:
                    user_id = row["user_id"]
                elif row["job_id"] != "sync":
                    job_row = conn.execute("SELECT user_id FROM jobs WHERE job_id = ?", (row["job_id"],)).fetchone()
                    if job_row and job_row["user_id"]:
                        user_id = job_row["user_id"]

                return DBAnalysisResult(
                    analysis_id=row["analysis_id"],
                    job_id=row["job_id"],
                    sample_id=row["sample_id"],
                    report_json=row["report_json"],
                    user_id=user_id,
                    created_at=row["created_at"],
                )
        return None

    def is_user_authorized_for_analysis(self, user_id: str, analysis_id: str) -> bool:
        """Verify if user_id is authorized to view analysis_id.

        Rules:
        - Admin or expert reviewer roles have global access.
        - Owner of the analysis has access.
        - Anonymous analyses can be viewed if no owner is designated.
        - Otherwise, access is rejected.
        """
        if not user_id:
            user_id = "anonymous"

        # Check role-based global permissions
        db_user = self.get_user_by_id(user_id)
        if db_user and db_user.role in ("admin", "expert_reviewer"):
            return True
        if user_id in ("admin", "admin1", "expert1", "expert_reviewer"):
            return True

        result = self.get_analysis_result(analysis_id)
        if not result:
            return False

        owner = result.user_id
        if owner == "anonymous":
            return True
        if owner == user_id:
            return True
        if db_user and (db_user.user_id == owner or db_user.username == owner):
            return True

        return False

    # -- Expert Review methods -----------------------------------------------

    def save_expert_review(self, review: DBExpertReview) -> DBExpertReview:
        with self._lock, self._get_connection() as conn:
            conn.execute(
                "INSERT INTO expert_reviews VALUES (?, ?, ?, ?, ?, ?)",
                (review.review_id, review.analysis_id, review.reviewer_id, review.decision, review.notes, review.timestamp),
            )
            conn.commit()
        return review

    def get_expert_reviews(self, analysis_id: str) -> List[DBExpertReview]:
        with self._lock, self._get_connection() as conn:
            rows = conn.execute("SELECT * FROM expert_reviews WHERE analysis_id = ? ORDER BY timestamp DESC", (analysis_id,)).fetchall()
            return [
                DBExpertReview(
                    review_id=r["review_id"], analysis_id=r["analysis_id"], reviewer_id=r["reviewer_id"],
                    decision=r["decision"], notes=r["notes"], timestamp=r["timestamp"],
                )
                for r in rows
            ]

    # -- Audit Event methods -------------------------------------------------

    def log_audit_event(self, event: DBAuditEvent) -> DBAuditEvent:
        with self._lock, self._get_connection() as conn:
            conn.execute(
                "INSERT INTO audit_events VALUES (?, ?, ?, ?, ?, ?, ?)",
                (event.event_id, event.user_id, event.action, event.resource, event.ip_address, event.timestamp, event.details),
            )
            conn.commit()
        return event

    def list_audit_events(self, limit: int = 50) -> List[DBAuditEvent]:
        with self._lock, self._get_connection() as conn:
            rows = conn.execute("SELECT * FROM audit_events ORDER BY timestamp DESC LIMIT ?", (limit,)).fetchall()
            return [
                DBAuditEvent(
                    event_id=r["event_id"], user_id=r["user_id"], action=r["action"],
                    resource=r["resource"], ip_address=r["ip_address"], timestamp=r["timestamp"],
                    details=r["details"],
                )
                for r in rows
            ]

    # -- Metrics & Stats -----------------------------------------------------

    def get_platform_stats(self) -> dict:
        with self._lock, self._get_connection() as conn:
            total_jobs = conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
            completed = conn.execute("SELECT COUNT(*) FROM jobs WHERE status = 'completed'").fetchone()[0]
            total_results = conn.execute("SELECT COUNT(*) FROM analysis_results").fetchone()[0]

            novelty_count = 0
            rows = conn.execute("SELECT report_json FROM analysis_results").fetchall()
            for r in rows:
                try:
                    data = json.loads(r["report_json"])
                    if data.get("novelty", {}).get("status") in ("novel", "unusual", "high_divergence"):
                        novelty_count += 1
                except Exception:
                    pass

            pending_reviews = conn.execute("SELECT COUNT(*) FROM jobs WHERE status IN ('queued', 'processing')").fetchone()[0]

            return {
                "total_analyses": max(total_jobs, total_results),
                "completed_analyses": completed,
                "pending_reviews": pending_reviews,
                "novelty_alerts": novelty_count,
                "system_health": "operational",
                "database_version": "ref-db-v2.0-prod",
            }

    # -- Reference DB Versions -----------------------------------------------

    def save_db_version(self, version: DBReferenceVersion) -> DBReferenceVersion:
        with self._lock, self._get_connection() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO reference_db_versions VALUES (?, ?, ?, ?, ?)",
                (version.version_id, version.version_name, version.release_date, version.num_records, version.description),
            )
            conn.commit()
        return version

    def list_db_versions(self) -> List[DBReferenceVersion]:
        with self._lock, self._get_connection() as conn:
            rows = conn.execute("SELECT * FROM reference_db_versions ORDER BY release_date DESC").fetchall()
            return [
                DBReferenceVersion(
                    version_id=r["version_id"], version_name=r["version_name"],
                    release_date=r["release_date"], num_records=r["num_records"],
                    description=r["description"],
                )
                for r in rows
            ]

