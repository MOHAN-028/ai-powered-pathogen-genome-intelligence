"""
app/analysis/novelty.py
========================
Novelty detection module with strict safety safeguards.
"""

from __future__ import annotations

from app.models.schemas import NoveltyResult, SimilarityResult


def detect_novelty(similarity: SimilarityResult) -> NoveltyResult:
    """Evaluate sequence novelty based on reference database similarity results.

    Safety Rule
    -----------
    A lack of a database match ('No database match') MUST NEVER be interpreted
    as a confirmed new pathogen. It indicates unmapped or unindexed reference data.
    """
    if similarity.database_status != "active" or not similarity.all_hits:
        return NoveltyResult(
            status="insufficient_evidence",
            novelty_score=0.5,
            rationale=(
                "No reference database matches were found (database status: "
                f"'{similarity.database_status}'). Lack of a match indicates unmapped sequence "
                "data, NOT a confirmed new organism."
            ),
            distinction_notice=(
                "No database match found. This status reflects database coverage limitations "
                "and MUST NOT be interpreted as confirmation of a new pathogen."
            ),
        )

    max_sim = similarity.max_similarity
    novelty_score = round(1.0 - max_sim, 4)

    if max_sim >= 0.70:
        status = "known_or_closely_related"
        top_name = similarity.top_hit.taxon_name if similarity.top_hit else "known reference"
        rationale = (
            f"High sequence similarity ({max_sim * 100:.1f}%) to reference target '{top_name}'. "
            "Sequence is classified as known or closely related."
        )
    elif max_sim >= 0.30:
        status = "possibly_novel"
        rationale = (
            f"Moderate sequence similarity ({max_sim * 100:.1f}%) to existing database entries. "
            "Sequence exhibits divergence from available reference genomes."
        )
    else:
        status = "insufficient_evidence"
        rationale = (
            f"Low similarity score ({max_sim * 100:.1f}%) to current reference database entries. "
            "The available database does not contain a close match; further expert bioinformatic "
            "review is required."
        )

    return NoveltyResult(
        status=status,
        novelty_score=novelty_score,
        rationale=rationale,
        distinction_notice=(
            "Safety Protocol: Divergence or absence of database matches indicates unmapped "
            "genomic data requiring reference expansion, NOT confirmation of an engineered or "
            "new pathogenic agent."
        ),
    )
