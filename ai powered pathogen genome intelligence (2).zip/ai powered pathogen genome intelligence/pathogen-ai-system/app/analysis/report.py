"""
app/analysis/report.py
======================
AI Explanation layer and JSON / HTML Research Intelligence Report generation.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from app.models.schemas import (
    AIExplanation,
    ClassificationResult,
    GenomeIntelligenceReport,
    NoveltyResult,
    QCResult,
    SimilarityResult,
    UncertaintyResult,
)


def generate_ai_explanation(
    qc: QCResult,
    similarity: SimilarityResult,
    novelty: NoveltyResult,
    classification: ClassificationResult,
    uncertainty: UncertaintyResult,
) -> AIExplanation:
    """Generate human-understandable AI explanation layer.

    Safety Guarantee: The AI converts analytical findings strictly based on
    factual metrics without fabricating claims or protocols.
    """
    # 1. Finding
    if similarity.top_hit:
        finding = (
            f"The submitted sequence matched reference identifier '{similarity.top_hit.reference_id}' "
            f"({similarity.top_hit.taxon_name}) with {similarity.top_hit.identity_percentage}% identity "
            f"and similarity score {similarity.top_hit.similarity_score}."
        )
    else:
        finding = (
            "The submitted sequence has limited similarity to the current reference database entries "
            f"(max similarity: {similarity.max_similarity})."
        )

    # 2. Interpretation
    if novelty.status == "known_or_closely_related":
        interpretation = (
            "The analytical evidence indicates the sequence aligns closely with known reference genomes "
            "in the database."
        )
    elif novelty.status == "possibly_novel":
        interpretation = (
            "The sequence exhibits moderate divergence from indexed reference strains. This may represent "
            "natural sequence variation or an unindexed strain variant."
        )
    else:
        interpretation = (
            "The available database does not contain a sufficiently close reference sequence for this record."
        )

    # 3. Confidence Summary
    conf_summary = (
        f"Overall analytical confidence is {uncertainty.confidence * 100:.1f}% "
        f"(Uncertainty: {uncertainty.uncertainty * 100:.1f}%)."
    )

    # 4. Recommended Next Step
    if uncertainty.uncertainty > 0.40 or novelty.status != "known_or_closely_related":
        next_step = (
            "Review the sequence quality and have the result evaluated by an appropriate "
            "bioinformatics or public-health domain expert."
        )
    else:
        next_step = "Proceed with routine comparative genomic workflow and sequence logging."

    return AIExplanation(
        finding=finding,
        interpretation=interpretation,
        confidence_summary=conf_summary,
        recommended_next_step=next_step,
    )


def build_report(
    analysis_id: str,
    sample_id: str,
    qc: QCResult,
    similarity: SimilarityResult,
    novelty: NoveltyResult,
    classification: ClassificationResult,
    uncertainty: UncertaintyResult,
) -> GenomeIntelligenceReport:
    """Assemble a complete GenomeIntelligenceReport instance."""
    ai_exp = generate_ai_explanation(qc, similarity, novelty, classification, uncertainty)
    warnings = list(qc.warnings)
    if uncertainty.reason_for_alert:
        warnings.append(uncertainty.reason_for_alert)

    db_versions = {
        "reference_database": similarity.database_version,
        "classification_model": classification.database_version,
    }

    return GenomeIntelligenceReport(
        analysis_id=analysis_id,
        sample_id=sample_id,
        timestamp=datetime.now(timezone.utc).isoformat(),
        sequence_statistics=qc,
        similarity=similarity,
        novelty=novelty,
        classification=classification,
        risk_and_uncertainty=uncertainty,
        ai_explanation=ai_exp,
        database_versions=db_versions,
        warnings=warnings,
        expert_review_status="pending_expert_review",
    )


def render_html_report(report: GenomeIntelligenceReport) -> str:
    """Render a standalone, beautifully styled HTML Research Intelligence Report."""
    r = report
    qc = r.sequence_statistics
    sim = r.similarity
    nov = r.novelty
    cls = r.classification
    unc = r.risk_and_uncertainty
    exp = r.ai_explanation

    status_color = "#10b981" if nov.status == "known_or_closely_related" else ("#f59e0b" if nov.status == "possibly_novel" else "#f43f5e")

    warnings_html = "".join([f"<li>⚠️ {w}</li>" for w in r.warnings]) if r.warnings else "<li>None</li>"
    hits_html = ""
    if sim.all_hits:
        for hit in sim.all_hits:
            hits_html += f"""
            <tr>
                <td style="font-family: monospace;">{hit.reference_id}</td>
                <td>{hit.taxon_name}</td>
                <td>{hit.similarity_score}</td>
                <td>{hit.identity_percentage}%</td>
                <td>{hit.coverage_percentage}%</td>
            </tr>
            """
    else:
        hits_html = '<tr><td colspan="5" style="text-align: center; color: #94a3b8;">No similarity hits recorded.</td></tr>'

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Research Intelligence Report - {r.sample_id}</title>
    <style>
        body {{
            background-color: #07090e;
            color: #f8fafc;
            font-family: system-ui, -apple-system, sans-serif;
            margin: 0;
            padding: 2rem;
            line-height: 1.5;
        }}
        .report-card {{
            max-width: 900px;
            margin: 0 auto;
            background: rgba(15, 23, 42, 0.9);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }}
        .header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding-bottom: 1rem;
            margin-bottom: 1.5rem;
        }}
        .badge {{
            background: {status_color}22;
            color: {status_color};
            border: 1px solid {status_color};
            padding: 0.4rem 0.8rem;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.85rem;
            text-transform: uppercase;
        }}
        .grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }}
        .panel {{
            background: rgba(7, 9, 14, 0.6);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 12px;
            padding: 1.25rem;
        }}
        h3 {{ margin-top: 0; font-size: 1rem; color: #00f2fe; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 0.5rem; }}
        table {{ width: 100%; border-collapse: collapse; font-size: 0.85rem; margin-top: 0.5rem; }}
        th, td {{ padding: 0.5rem; text-align: left; border-bottom: 1px solid rgba(255,255,255,0.05); }}
        th {{ color: #94a3b8; font-size: 0.75rem; text-transform: uppercase; }}
        .disclaimer {{
            background: rgba(244, 63, 94, 0.1);
            border-left: 4px solid #f43f5e;
            padding: 1rem;
            border-radius: 6px;
            font-size: 0.8rem;
            color: #fda4af;
            margin-top: 1.5rem;
        }}
    </style>
</head>
<body>
    <div class="report-card">
        <div class="header">
            <div>
                <h1 style="margin: 0; font-size: 1.5rem; color: #ffffff;">GENOME INTELLIGENCE REPORT</h1>
                <div style="font-size: 0.85rem; color: #94a3b8;">Sample ID: {r.sample_id} | Analysis ID: {r.analysis_id}</div>
            </div>
            <div class="badge">{nov.status.replace('_', ' ')}</div>
        </div>

        <div class="grid">
            <div class="panel">
                <h3>📊 Sequence Quality Control</h3>
                <div>Records: <strong>{qc.num_records}</strong></div>
                <div>Total Length: <strong>{qc.total_length} bp</strong></div>
                <div>GC Content: <strong>{(qc.gc_content * 100):.1f}%</strong></div>
                <div>Ambiguous Bases (N%): <strong>{qc.ambiguous_percentage:.2f}%</strong></div>
                <div>Quality Status: <strong>{"Passed" if qc.quality_passed else "Flagged"}</strong></div>
            </div>

            <div class="panel">
                <h3>🏷️ Classification & Risk Metrics</h3>
                <div>Taxonomic Class: <strong style="color: #00f2fe;">{cls.classification}</strong></div>
                <div>Classification Confidence: <strong>{(cls.confidence * 100):.1f}%</strong></div>
                <div>Analytical Uncertainty: <strong>{(unc.uncertainty * 100):.1f}%</strong></div>
                <div>Novelty Score: <strong>{nov.novelty_score}</strong></div>
                <div>Expert Review Status: <strong>{r.expert_review_status}</strong></div>
            </div>
        </div>

        <div class="panel" style="margin-bottom: 1.5rem;">
            <h3>🤖 AI Research Explanation</h3>
            <p><strong>Finding:</strong> {exp.finding}</p>
            <p><strong>Interpretation:</strong> {exp.interpretation}</p>
            <p><strong>Confidence Summary:</strong> {exp.confidence_summary}</p>
            <p><strong>Recommended Next Step:</strong> {exp.recommended_next_step}</p>
        </div>

        <div class="panel" style="margin-bottom: 1.5rem;">
            <h3>🔬 Reference Database Similarity Hits</h3>
            <table>
                <thead>
                    <tr>
                        <th>Ref ID</th>
                        <th>Taxon Name</th>
                        <th>Score</th>
                        <th>Identity</th>
                        <th>Coverage</th>
                    </tr>
                </thead>
                <tbody>
                    {hits_html}
                </tbody>
            </table>
        </div>

        <div class="panel">
            <h3>⚠️ Warnings & System Notes</h3>
            <ul>
                {warnings_html}
            </ul>
        </div>

        <div class="disclaimer">
            <strong>SAFETY & COMPLIANCE DISCLAIMER:</strong> {unc.medical_disclaimer}<br>
            <em>Notice:</em> {nov.distinction_notice}
        </div>
    </div>
</body>
</html>
"""
    return html
