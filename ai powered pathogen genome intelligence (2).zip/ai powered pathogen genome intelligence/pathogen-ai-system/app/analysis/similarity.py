"""
app/analysis/similarity.py
===========================
Similarity analysis module and ReferenceDatabase abstraction interface.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Optional, Sequence

from Bio.Align import PairwiseAligner
from src.bioinformatics_tools import SequenceRecord
from app.models.schemas import SimilarityHit, SimilarityResult


class ReferenceDatabase(ABC):
    """Abstract base interface for pathogen reference databases."""

    @property
    @abstractmethod
    def version(self) -> str:
        """Database version string."""
        pass

    @property
    @abstractmethod
    def status(self) -> str:
        """Database status ('active', 'empty', 'unavailable')."""
        pass

    @abstractmethod
    def search(self, sequence: str, top_k: int = 5) -> list[SimilarityHit]:
        """Search query sequence against reference database.

        Returns list of SimilarityHit sorted by similarity score descending.
        """
        pass


class LocalReferenceDatabase(ReferenceDatabase):
    """Local in-memory / FASTA file reference database implementation."""

    def __init__(
        self,
        reference_records: Optional[Sequence[SequenceRecord]] = None,
        version: str = "ref-db-v1.0-demo",
    ) -> None:
        self._version = version
        self._records: list[tuple[str, str, str]] = []  # (ref_id, taxon_name, sequence)

        if reference_records:
            for rec in reference_records:
                parts = rec.description.split()
                taxon = parts[1] if len(parts) > 1 else rec.id
                if "[label=" in rec.description:
                    start = rec.description.index("[label=") + len("[label=")
                    end = rec.description.index("]", start)
                    taxon = rec.description[start:end]
                self._records.append((rec.id, taxon, rec.sequence.upper()))

    @property
    def version(self) -> str:
        return self._version

    @property
    def status(self) -> str:
        return "active" if self._records else "empty"

    def search(self, sequence: str, top_k: int = 5) -> list[SimilarityHit]:
        if not self._records or not sequence:
            return []

        query = sequence.upper()
        hits: list[SimilarityHit] = []

        aligner = PairwiseAligner()
        aligner.mode = "global"
        aligner.match_score = 2
        aligner.mismatch_score = -1
        aligner.open_gap_score = -4
        aligner.extend_gap_score = -0.5

        for ref_id, taxon_name, ref_seq in self._records:
            # Subsample for long sequences to maintain rapid responsive execution
            q_sub = query[:1000]
            r_sub = ref_seq[:1000]

            alignments = aligner.align(q_sub, r_sub)
            if not alignments:
                continue

            best_aln = alignments[0]
            score = float(best_aln.score)
            aln_len = len(best_aln[0])
            identical = sum(a == b for a, b in zip(str(best_aln[0]), str(best_aln[1])))
            identity_pct = (identical / max(1, aln_len)) * 100.0
            coverage_pct = (min(len(q_sub), len(r_sub)) / max(len(q_sub), len(r_sub))) * 100.0

            # Normalized similarity score (0.0 to 1.0)
            norm_score = max(0.0, min(1.0, identity_pct / 100.0))
            confidence = round(max(0.0, min(1.0, norm_score * (coverage_pct / 100.0))), 4)

            hits.append(
                SimilarityHit(
                    reference_id=ref_id,
                    taxon_name=taxon_name,
                    similarity_score=round(norm_score, 4),
                    alignment_length=aln_len,
                    identity_percentage=round(identity_pct, 2),
                    coverage_percentage=round(coverage_pct, 2),
                    confidence=confidence,
                    notes=f"Global alignment score {score:.1f} against reference {ref_id}",
                )
            )

        hits.sort(key=lambda h: h.similarity_score, reverse=True)
        return hits[:top_k]


class UnavailableReferenceDatabase(ReferenceDatabase):
    """Fallback reference database representing an offline/unavailable connection."""

    @property
    def version(self) -> str:
        return "offline-v0"

    @property
    def status(self) -> str:
        return "unavailable"

    def search(self, sequence: str, top_k: int = 5) -> list[SimilarityHit]:
        return []


def analyze_similarity(
    query_id: str,
    sequence: str,
    db: ReferenceDatabase,
    top_k: int = 5,
) -> SimilarityResult:
    """Analyze query sequence similarity against reference database."""
    if db.status != "active":
        return SimilarityResult(
            query_id=query_id,
            top_hit=None,
            all_hits=[],
            max_similarity=0.0,
            database_version=db.version,
            database_status=db.status,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    hits = db.search(sequence, top_k=top_k)
    top_hit = hits[0] if hits else None
    max_sim = top_hit.similarity_score if top_hit else 0.0

    return SimilarityResult(
        query_id=query_id,
        top_hit=top_hit,
        all_hits=hits,
        max_similarity=max_sim,
        database_version=db.version,
        database_status=db.status,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )
