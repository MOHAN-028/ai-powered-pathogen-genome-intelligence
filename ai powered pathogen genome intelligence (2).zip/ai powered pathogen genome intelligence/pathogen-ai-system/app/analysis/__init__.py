"""
app.analysis package.
"""
