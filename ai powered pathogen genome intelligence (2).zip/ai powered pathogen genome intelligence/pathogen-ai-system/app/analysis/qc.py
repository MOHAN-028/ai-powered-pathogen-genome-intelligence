"""
app/analysis/qc.py
==================
Quality Control module for analyzing genomic sequences.
"""

from __future__ import annotations

import hashlib
from typing import Sequence
from src.bioinformatics_tools import SequenceRecord, base_composition, compute_gc_content
from app.models.schemas import BaseComposition, QCResult


def run_qc(records: Sequence[SequenceRecord]) -> QCResult:
    """Compute comprehensive Quality Control statistics for input records.

    Parameters
    ----------
    records : list[SequenceRecord]

    Returns
    -------
    QCResult
    """
    if not records:
        return QCResult(
            num_records=0,
            total_length=0,
            gc_content=0.0,
            base_composition=BaseComposition(),
            ambiguous_bases=0,
            ambiguous_percentage=0.0,
            duplicate_records_count=0,
            quality_passed=False,
            warnings=["Empty sequence input provided."],
        )

    num_records = len(records)
    total_len = sum(r.length for r in records)
    total_a = 0
    total_t = 0
    total_g = 0
    total_c = 0
    total_n = 0
    total_other = 0

    seen_hashes: set[str] = set()
    duplicate_count = 0
    warnings: list[str] = []

    for r in records:
        comp = base_composition(r.sequence)
        total_a += comp["A"]
        total_t += comp["T"]
        total_g += comp["G"]
        total_c += comp["C"]
        total_n += comp["N"]
        total_other += comp["other"]

        # Duplicate check by hashing sequence content
        seq_hash = hashlib.sha256(r.sequence.upper().encode("utf-8")).hexdigest()
        if seq_hash in seen_hashes:
            duplicate_count += 1
        else:
            seen_hashes.add(seq_hash)

        # Warning checks
        if r.length < 50:
            warnings.append(f"Short sequence record detected ({r.id}: {r.length} bp).")

    ambiguous_pct = (total_n / total_len * 100.0) if total_len > 0 else 0.0
    if ambiguous_pct > 5.0:
        warnings.append(f"High ambiguous base percentage ({ambiguous_pct:.2f}% Ns).")

    if duplicate_count > 0:
        warnings.append(f"Detected {duplicate_count} duplicate sequence records.")

    gc_content = ((total_g + total_c) / total_len) if total_len > 0 else 0.0
    quality_passed = total_len > 0 and ambiguous_pct <= 10.0

    return QCResult(
        num_records=num_records,
        total_length=total_len,
        gc_content=round(gc_content, 4),
        base_composition=BaseComposition(
            A=total_a, T=total_t, G=total_g, C=total_c, N=total_n, other=total_other
        ),
        ambiguous_bases=total_n,
        ambiguous_percentage=round(ambiguous_pct, 4),
        duplicate_records_count=duplicate_count,
        quality_passed=quality_passed,
        warnings=warnings,
    )
