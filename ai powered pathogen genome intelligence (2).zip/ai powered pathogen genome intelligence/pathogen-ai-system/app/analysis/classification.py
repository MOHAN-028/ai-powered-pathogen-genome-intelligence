"""
app/analysis/classification.py
===============================
Taxonomic and functional classification service.
"""

from __future__ import annotations

from typing import Optional
from app.models.schemas import ClassificationResult, SimilarityResult
from src.genomic_ai_model import PathogenClassifier


def classify_sequence(
    sequence: str,
    similarity: SimilarityResult,
    ml_classifier: Optional[PathogenClassifier] = None,
) -> ClassificationResult:
    """Classify input sequence combining ML predictions and similarity hits.

    Uses confidence metrics rather than presenting unsupported claims.
    """
    db_version = similarity.database_version
    evidence: list[str] = []

    # 1. Similarity-based classification evidence
    if similarity.top_hit and similarity.top_hit.similarity_score >= 0.60:
        sim_class = similarity.top_hit.taxon_name
        sim_conf = similarity.top_hit.confidence
        evidence.append(
            f"Similarity match: {sim_class} (identity: {similarity.top_hit.identity_percentage}%, score: {similarity.top_hit.similarity_score})"
        )
    else:
        sim_class = "unclassified_genus"
        sim_conf = 0.20
        if similarity.top_hit:
            evidence.append(
                f"Weak similarity hit: {similarity.top_hit.taxon_name} (identity: {similarity.top_hit.identity_percentage}%)"
            )
        else:
            evidence.append("No database similarity hits found.")

    # 2. Machine Learning classifier evidence (if trained model available)
    ml_class: Optional[str] = None
    ml_conf: float = 0.0
    if ml_classifier and hasattr(ml_classifier, "_is_fitted") and ml_classifier._is_fitted:
        try:
            pred = ml_classifier.predict(sequence)
            ml_class = pred.label
            ml_conf = pred.confidence
            evidence.append(f"K-mer TF-IDF ML prediction: {ml_class} (confidence: {ml_conf:.2f})")
        except Exception as err:
            evidence.append(f"ML classification bypassed: {err}")

    # 3. Consensus determination
    if sim_class != "unclassified_genus" and ml_class:
        if sim_class.lower() == ml_class.lower():
            final_class = sim_class
            final_conf = round(min(1.0, (sim_conf + ml_conf) / 1.5), 4)
            evidence.append("Consensus agreement between DB similarity and ML classifier.")
        else:
            final_class = sim_class if sim_conf >= ml_conf else ml_class
            final_conf = round(max(sim_conf, ml_conf) * 0.8, 4)
            evidence.append(f"Divergence between DB similarity ({sim_class}) and ML ({ml_class}).")
    elif sim_class != "unclassified_genus":
        final_class = sim_class
        final_conf = round(sim_conf, 4)
    elif ml_class:
        final_class = ml_class
        final_conf = round(ml_conf * 0.7, 4)
    else:
        final_class = "unknown"
        final_conf = 0.10
        evidence.append("Insufficient data to establish high-confidence taxonomy.")

    return ClassificationResult(
        classification=final_class,
        confidence=final_conf,
        evidence=evidence,
        database_version=db_version,
    )
