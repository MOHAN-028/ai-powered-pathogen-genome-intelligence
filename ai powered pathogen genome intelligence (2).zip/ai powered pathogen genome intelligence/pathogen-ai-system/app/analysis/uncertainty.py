"""
app/analysis/uncertainty.py
===========================
Risk and uncertainty assessment scoring framework.
"""

from __future__ import annotations

from typing import Optional
from app.models.schemas import (
    ClassificationResult,
    NoveltyResult,
    QCResult,
    SimilarityResult,
    UncertaintyResult,
)


def evaluate_uncertainty(
    qc: QCResult,
    similarity: SimilarityResult,
    novelty: NoveltyResult,
    classification: ClassificationResult,
) -> UncertaintyResult:
    """Calculate analytical confidence and uncertainty metrics.

    Safety Notice
    -------------
    This function measures analytical alignment and data coverage only.
    It does NOT provide clinical diagnostic claims or medical advice.
    """
    evidence_sources: list[str] = []
    limitations: list[str] = []
    reason_for_alert: Optional[str] = None

    # Base confidence from classification and similarity
    conf_factors = [classification.confidence]

    if similarity.top_hit:
        conf_factors.append(similarity.top_hit.confidence)
        evidence_sources.append(
            f"Reference Database ({similarity.database_version}): {similarity.top_hit.reference_id}"
        )
    else:
        limitations.append("Reference database query yielded no matching targets.")

    if qc.quality_passed:
        evidence_sources.append(f"Sequence QC passed ({qc.total_length} bp, {qc.ambiguous_percentage}% Ns)")
    else:
        limitations.append(f"Sequence quality flags raised: {', '.join(qc.warnings)}")

    # Compute overall confidence and uncertainty
    raw_conf = sum(conf_factors) / len(conf_factors)
    # Penalize for ambiguous bases or low reference coverage
    if qc.ambiguous_percentage > 2.0:
        raw_conf *= (1.0 - (qc.ambiguous_percentage / 100.0))
        limitations.append(f"Ambiguous nucleotide bases reduce confidence (-{qc.ambiguous_percentage:.1f}%).")

    final_conf = round(max(0.05, min(1.0, raw_conf)), 4)
    uncertainty = round(1.0 - final_conf, 4)

    # Determine alert triggers based purely on analytical data quality/novelty
    if novelty.status == "possibly_novel":
        reason_for_alert = (
            "Analytical Alert: Moderate sequence divergence detected relative to reference database. "
            "Expert bioinformatic review recommended."
        )
    elif novelty.status == "insufficient_evidence":
        reason_for_alert = (
            "Data Coverage Alert: Unmapped sequence region with insufficient reference coverage. "
            "Requires database expansion and manual verification."
        )
    elif uncertainty > 0.50:
        reason_for_alert = (
            "Uncertainty Alert: Analytical uncertainty score exceeds 50%. Results should be "
            "evaluated by a bioinformatics domain expert."
        )

    return UncertaintyResult(
        confidence=final_conf,
        uncertainty=uncertainty,
        evidence_sources=evidence_sources,
        limitations=limitations,
        reason_for_alert=reason_for_alert,
    )
