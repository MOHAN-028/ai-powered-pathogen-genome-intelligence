# Pathogen AI System

AI-Powered Pathogen Genome Intelligence — classify and analyse pathogen genomes using machine learning inside a Docker-isolated sandbox.

## Features

- **K-mer classification** — Convert DNA sequences into overlapping k-mer tokens, vectorise with TF-IDF, and classify with Logistic Regression or Random Forest.
- **Genome embeddings** — Generate fixed-length numerical representations of genomes for similarity search and clustering.
- **Bioinformatics toolkit** — Parse FASTA/FASTQ files, compute GC content, find Open Reading Frames, run local BLAST, and perform pairwise alignment.
- **REST API** — FastAPI server with endpoints for prediction, file analysis, and model management.
- **Docker sandbox** — Network-isolated container with resource limits for safe genomic code execution.

## Quick Start

### 1. Install dependencies

```powershell
cd pathogen-ai-system
pip install -r requirements.txt
```

### 2. Train a model

```powershell
python -m src.train_model --data data/sample_pathogen_sequences.fasta
```

This will:
- Parse the labelled FASTA sample data
- Train a k-mer classifier
- Save the model to `models/saved_models/`
- Generate embeddings in `results/embeddings.npy`

### 3. Start the API server

```powershell
python -m uvicorn src.mcp_server:app --host 0.0.0.0 --port 8000
```

### 4. Use the API

**Health check:**
```powershell
curl http://localhost:8000/health
```

**Classify a sequence:**
```powershell
curl -X POST http://localhost:8000/predict `
  -H "Content-Type: application/json" `
  -d '{"sequence": "ATGAAACGCATTAGCACCACCATTACCACCACCATCACCATTACCACAG"}'
```

**Upload a FASTA file for analysis:**
```powershell
curl -X POST http://localhost:8000/analyze -F "file=@data/sample_pathogen_sequences.fasta"
```

**List saved models:**
```powershell
curl http://localhost:8000/models
```

## Docker Deployment

```powershell
# From the project root
docker compose -f docker-compose.yml build
docker compose -f docker-compose.yml up -d
```

The API will be available at `http://localhost:8000`.

## Project Structure

```
pathogen-ai-system/
├── data/
│   └── sample_pathogen_sequences.fasta   # Labelled training data
├── models/
│   └── saved_models/                     # Trained model files (.joblib)
├── results/
│   ├── analysis_results.json             # Training metrics
│   └── embeddings.npy                    # Genome embedding vectors
├── src/
│   ├── __init__.py
│   ├── genomic_ai_model.py               # K-mer classifier & embedder
│   ├── bioinformatics_tools.py           # FASTA/FASTQ parsing, GC, ORFs, BLAST
│   ├── mcp_server.py                     # FastAPI REST server
│   ├── train_model.py                    # CLI training script
│   └── model_persistence.py             # Save / load models
├── tests/
│   ├── test_genomic_model.py
│   └── test_bioinformatics.py
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── setup.py
└── README.md
```

## Running Tests

```powershell
python -m pytest tests/ -v
```

## Security

- Docker container runs with limited CPU (2 cores) and memory (4 GiB).
- Network mode is set to `none` for the sandbox — no outbound access.
- The API server exposes port 8000 for local access only.

---

Built with BioPython, scikit-learn, and FastAPI.
