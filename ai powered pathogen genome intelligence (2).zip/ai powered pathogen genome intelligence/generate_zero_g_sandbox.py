import os
import time
from pathlib import Path
import platform
import logging

# Configure zero-G mission logging
logging.basicConfig(
    level=logging.INFO,
    format='[SANDBOX ZERO-G] %(message)s'
)

# The exact blueprint you requested
PROJECT_TREE = {
    ".vscode": ["settings.json", "launch.json"],
    "data": {
        "__files__": ["pathogen_sequences.fasta"],
        "reference_genomes": []
    },
    "src": [
        "genomic_ai_model.py",
        "bioinformatics_tools.py",
        "mcp_server.py",
        "train_model.py",
        "model_persistence.py"
    ],
    "models": {
        "__files__": [],
        "saved_models": []
    },
    "results": [
        "analysis_results.json",
        "embeddings.npy"
    ],
    "tests": [
        "test_genomic_model.py",
        "test_bioinformatics.py"
    ],
    "notebooks": [
        "exploration.ipynb"
    ]
}

ROOT_FILES = ["requirements.txt", "setup.py", "README.md", "Dockerfile", "docker-compose.yml"]

def verify_zero_g_environment():
    """Ensure the physical environment is safe for sandbox generation."""
    logging.info("Verifying microgravity environment constraints for sandbox...")
    
    # 1. Check for Mechanical Hard Drives
    if platform.system() == "Linux":
        logging.info("Linux OS detected. Confirming NVMe SSD mount for container storage...")
    else:
        logging.warning("Ensure Docker is using a volume on an SSD. Mechanical HDDs will fail.")
    
    # 2. Check Physical Anchoring
    anchored = input("Is the host machine secured to the station wall? (y/n): ")
    if anchored.lower() != 'y':
        raise EnvironmentError("HALT: Workstation not anchored. Sandbox container inertia could cause drift.")
    
    logging.info("Environment verified. Safe to proceed with sandbox construction.")

def create_directory_structure(base_path: Path, tree_dict: dict):
    """Recursively create directories and files with inertia damping."""
    
    for name, contents in tree_dict.items():
        dir_path = base_path / name
        
        # Create the directory
        dir_path.mkdir(parents=True, exist_ok=True)
        logging.info(f"Directory anchored: {dir_path}")
        
        # Damping delay to prevent sudden mass allocation in RAM
        time.sleep(0.1)
        
        # Create files inside the directory
        if isinstance(contents, list):
            for file_name in contents:
                file_path = dir_path / file_name
                if not file_path.exists():
                    file_path.touch()
                    logging.info(f"  -> File created: {file_name}")
                    time.sleep(0.05)  # Micro-delay to prevent thermal spikes
        elif isinstance(contents, dict):
            create_directory_structure(dir_path, contents)

def create_root_files(base_path: Path):
    """Create root-level files including Docker sandbox configs."""
    for file_name in ROOT_FILES:
        file_path = base_path / file_name
        if not file_path.exists():
            file_path.touch()
            logging.info(f"Root file created: {file_name}")
            time.sleep(0.1)

def write_docker_files(base_path: Path):
    """Write the Docker isolation configurations."""
    
    # 1. Dockerfile
    dockerfile_path = base_path / "Dockerfile"
    with open(dockerfile_path, 'w') as f:
        f.write("""# Zero-G Bioinformatics Sandbox
FROM python:3.11-slim

# Install system dependencies and bioinformatics tools
RUN apt-get update && apt-get install -y \
    build-essential \
    git \
    blast2 \
    bwa \
    samtools \
    && rm -rf /var/lib/apt/lists/*

# Set working directory
WORKDIR /app

# Copy requirements and install
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy project files
COPY . .

# Create non-root user
RUN useradd -m sandbox && chown -R sandbox:sandbox /app
USER sandbox

# Default command (will be overridden by docker-compose)
CMD ["python", "-c", "print('Zero-G Sandbox Ready')"]
""")
    
    # 2. docker-compose.yml
    compose_path = base_path / "docker-compose.yml"
    with open(compose_path, 'w') as f:
        f.write("""version: '3.8'

services:
  pathogen-sandbox:
    build: .
    user: "1000:1000"
    volumes:
      - ./sandbox/app:/app
      - ./data/uploads:/data/uploads:rw
      - ./data/quarantine:/data/quarantine:rw
      - ./data/results:/data/results:rw
    mem_limit: 2g
    cpus: 1.0
    pids_limit: 100
    network_mode: \"none\"
    read_only: true
    tmpfs:
      - /tmp:rw,size=100M
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
""")
    
    # 3. .dockerignore
    dockerignore_path = base_path / ".dockerignore"
    with open(dockerignore_path, 'w') as f:
        f.write("""venv/
__pycache__/
*.pyc
.git/
""")

def main():
    project_name = "ai-powered-pathogen-genome-intelligence"
    base_dir = Path(project_name)
    try:
        verify_zero_g_environment()
        logging.info(f"Initializing zero-G sandbox workspace: {base_dir.resolve()}")
        base_dir.mkdir(exist_ok=True)
        # Generate the tree (now using the new layout)
        # Create required directories
        for sub in ["sandbox/app", "data/uploads", "data/quarantine", "data/results", "tests"]:
            (base_dir / sub).mkdir(parents=True, exist_ok=True)
        # Create placeholder files for config, API, etc.
        (base_dir / "sandbox/app" / "__init__.py").touch()
        (base_dir / "sandbox/app" / "main.py").touch()
        (base_dir / "sandbox/app" / "config.py").touch()
        (base_dir / "sandbox/app" / "security.py").touch()
        (base_dir / "sandbox/app" / "sequence_validator.py").touch()
        (base_dir / "sandbox/app" / "health.py").touch()
        (base_dir / "tests" / "test_sequence_validator.py").touch()
        (base_dir / "tests" / "test_health.py").touch()
        # Create root files
        create_root_files(base_dir)
        write_docker_files(base_dir)
        logging.info("✅ ZERO-G SANDBOX GENERATION COMPLETE.")
    except Exception as e:
        logging.error(f"MISSION ABORTED: {str(e)}")

if __name__ == "__main__":
    main()
